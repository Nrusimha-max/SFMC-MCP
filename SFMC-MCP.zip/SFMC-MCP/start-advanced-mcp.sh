#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export SFMC_USE_SAVED_CONFIG=1
export MCP_COMPACT=1
export MCP_MAX_RESPONSE_BYTES="${MCP_MAX_RESPONSE_BYTES:-32000}"
export SFMC_PLAN_DIRECTORY="$SCRIPT_DIR/.sfmc-plans"
NODE_BIN="$(command -v node)"
exec "$NODE_BIN" "$SCRIPT_DIR/dist/index.js"
