# Healthcare Practice Journey

Status: design only; no SFMC objects created or activated.

## Purpose

Practise patient onboarding and appointment reminders using fictional records.

## Proposed objects

- Journey: Healthcare_Practice_Patient_Onboarding
- Sendable entry Data Extension: HC_Practice_Appointment_Entry
- Current appointment Data Extension: HC_Practice_Appointment_Current
- Email content: HC_Practice_Welcome and HC_Practice_Appointment_Reminder

## Data design

Entry fields: ContactKey (Text 50), AppointmentID (Text 50), EmailAddress (EmailAddress), FirstName (Text 50), AppointmentDateTime (Date), ReminderDateTime (Date), CommunicationOptIn (Boolean).

Use a unique entry record key per appointment. Map ContactKey to the subscriber key. Configure the journey's email-address source explicitly. Link current appointment data by contact and appointment ID so that multiple appointments cannot select an unrelated appointment's status.

Current appointment fields: AppointmentID (primary key), ContactKey, AppointmentStatus, AppointmentDateTime, CommunicationOptIn, LastUpdated.

## Proposed flow

1. Admit eligible fictional appointment records with communication permission and a future reminder date.
2. Send a welcome email.
3. Wait until ReminderDateTime.
4. Evaluate linked current contact/appointment data: permission is still granted, the same appointment is confirmed, and the date still matches the original booking.
5. Send a reminder for eligible records; exit all other paths. Rescheduled appointments need a separately defined re-entry policy.
6. Exit.

Cancellation and rescheduling checks must use updated Contact Data, not the entry snapshot. Define and validate the data relationship before adding the split. The practice scope assumes one active appointment per fictional contact until multi-appointment routing is verified.

## Email copy

Welcome subject: Welcome to our appointment service

Hello [FirstName], your appointment has been registered. Please use the appointment portal to review or change your booking.

Reminder subject: Your upcoming appointment

Hello [FirstName], this is a reminder about your appointment on [AppointmentDateTime]. Please use the appointment portal if you need to change your booking.

Portal URLs, sender identity, approved sending classification, publication preferences, and required footer links must be supplied and verified before send activities can be completed.

## Verification and approval

Resolve the target business unit, existing assets and permissions through SFMC API reads. Prepare exact individual SFMC changes for review. Human approval is required before each approved change is invoked. Initial creation should remain Draft. Activation and sending require separately reviewed explicit approval.

Use only fictional records; no recipient records or test sends are part of this proposal. Verify wait timing, consent withdrawal, cancellations, rescheduling, duplicate entry and subscriber mapping before proposing activation.
