const fs=require('fs'),vm=require('vm'),assert=require('assert/strict'),crypto=require('crypto'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'sfmc-builder-retention-duplicate.html'),'utf8'),blocks=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(m=>m[1]);const copy=x=>JSON.parse(JSON.stringify(x));
const ctx=vm.createContext({Stringify:JSON.stringify,hash:s=>crypto.createHash('sha256').update(s).digest('hex'),Platform:{Load(){},Response:{SetResponseHeader(){}},Request:{GetQueryStringParameter(){return '0'}}}});
vm.runInContext(blocks[0].replace(/\}\)\(\);\s*$/,'globalThis.test={h_listActivities,cpActivityId,h_attachActivity,h_createAutomation,cpAutomationTopology,setRest:function(fn){rest=fn;}};sbHash=hash;cpVerifyAutomation=function(){return {ProgramID:"auto",Name:"Automation",Status:"2"};};})();'),ctx);const api=ctx.test;
const cases=[['query','queries','queryDefinitionId',300],['import','imports','importDefinitionId',43],['script','scripts','ssjsActivityId',423],['extract','dataextracts','dataExtractDefinitionId',73],['filetransfer','filetransfers','id',53]];
let definition,collectionMode='normal',calls=[],active;
api.setRest((method,url,body)=>{
 calls.push({method,url,body:copy(body||null)});
 if(url==='automation/v1/automations/auto'){if(method==='GET')return copy(definition);assert.equal(method,'PATCH');definition.steps=copy(body.steps);return {};}
 if(url==='automation/v1/automations'){assert.equal(method,'POST');return {id:'created',name:body.name};}
 if(url.includes('?$page=')){
  assert.equal(method,'GET');assert.match(url,new RegExp('automation/v1/'+active[1]+'\\?'));
  if(collectionMode==='malformed')return {items:[{name:'Missing ID'}],count:1};
  if(collectionMode==='noCollection')return {unexpected:[]};
  if(collectionMode==='array')return [{[active[2]]:'saved-'+active[0],name:'Saved'}];
  if(collectionMode==='partial')return {items:[{[active[2]]:'saved-'+active[0],name:'Saved'},{name:'Bad'}],count:4,pageSize:2};
  return {items:[{[active[2]]:'saved-'+active[0],name:'Saved '+active[0],customerKey:'KEY'}],count:2,page:1,pageSize:1};
 }
 assert.equal(method,'GET');assert.equal(url,'automation/v1/'+active[1]+'/saved-'+active[0]);return {[active[2]]:'saved-'+active[0],name:'Verified saved activity'};
});
for(const test of cases){
 active=test;let r=api.h_listActivities({type:test[0],page:1});assert.equal(r.items[0].id,'saved-'+test[0]);assert.equal(r.items[0].key,'KEY');assert.equal(r.more,true);
 definition={id:'auto',steps:[{id:'step',name:'Step',activities:[]}]};const hash=api.cpAutomationTopology(definition);
 api.h_attachActivity({id:'auto',name:'Automation',definitionHash:hash,stepId:'step',activity:{type:test[0],id:r.items[0].id,name:r.items[0].name}});assert.equal(definition.steps[0].activities[0].objectTypeId,test[3]);assert.equal(definition.steps[0].activities[0].activityObjectId,'saved-'+test[0]);
 api.h_createAutomation({name:'Draft',steps:[{name:'Step',activities:[{type:test[0],id:'saved-'+test[0],name:'Saved'}]}]});assert.equal(calls.at(-1).body.steps[0].activities[0].objectTypeId,test[3]);
 collectionMode='array';assert.equal(api.h_listActivities({type:test[0]}).items.length,1);collectionMode='partial';r=api.h_listActivities({type:test[0]});assert.match(r.warning,/omitted/);assert.equal(r.more,true);
 collectionMode='malformed';assert.throws(()=>api.h_listActivities({type:test[0]}),/without usable/);collectionMode='noCollection';assert.throws(()=>api.h_listActivities({type:test[0]}),/did not return/);collectionMode='normal';
}
assert.equal(api.cpActivityId('filetransfer',{fileTransferActivityId:'transfer-id'}),'transfer-id');assert.equal(api.cpActivityId('script',{scriptActivityId:'script-id'}),'script-id');assert.equal(api.cpActivityId('import',{queryDefinitionId:'wrong',importDefinitionId:'correct'}),'correct');
const nodes={};function node(id){return nodes[id]||(nodes[id]={value:'',innerHTML:'',textContent:'',disabled:false,style:{},classList:{contains(){return false}},querySelectorAll(){return []},setAttribute(){}});}
const browser=vm.createContext({URL,URLSearchParams,document:{getElementById:node,querySelectorAll(){return []}},location:{href:'https://test/',protocol:'https:'}});vm.runInContext(blocks[1].slice(0,blocks[1].indexOf('/* ---------- init ---------- */')),browser);const run=s=>vm.runInContext(s,browser);
run('busy=async function(btn,fn){return fn();};renderSteps=function(){};globalThis.requests=[];api=async function(action,data){requests.push({action,data});return {items:[{id:"saved-"+data.type,name:"Saved"}],count:1,more:false};};state.steps=[{name:"Step",activities:[]}];');node('pick-step').value='0';
(async()=>{for(const [type] of cases){node('pick-type').value=type;run('pickerReset()');await run('loadActivities(false)');run('pickAdd(0)');assert.equal(run('state.steps[0].activities.at(-1).type'),type);assert.equal(run('state.steps[0].activities.at(-1).id'),'saved-'+type);assert.equal(node('pick-more').disabled,true);}assert.match(html,/onchange="pickerReset\(\);loadActivities\(false\)"/);console.log('PASS: all five types list, normalize, paginate, populate draft steps, create correct type IDs, and attach to saved steps; alternate IDs and malformed collections handled; dropdown type changes auto-load. All SFMC mutations mocked.');})().catch(e=>{console.error(e.message);process.exitCode=1});
