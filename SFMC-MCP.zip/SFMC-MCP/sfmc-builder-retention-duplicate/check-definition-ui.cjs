const fs=require('fs'),vm=require('vm'),assert=require('assert/strict'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'sfmc-builder-retention-duplicate.html'),'utf8'),script=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)][1][1];
const nodes={},alerts=[],listeners={},timers=new Map();let nextTimer=0,allowConfirm=true;
function node(id){return nodes[id]||(nodes[id]={id,value:'',checked:false,disabled:false,hidden:false,innerHTML:'',textContent:'',style:{},options:[],parentNode:{parentNode:{insertBefore(){}},insertBefore(){}},classList:{contains(){return false},add(){},remove(){}},querySelector(){return null},querySelectorAll(){return this.controls || []},setAttribute(){},appendChild(){},focus(){}});}
const doc={body:{style:{}},getElementById:node,querySelectorAll(){return []},createElement(){return {appendChild(){},setAttribute(){},remove(){},click(){}};},addEventListener(type,fn){listeners[type]=fn;}};
const ctx=vm.createContext({URL,URLSearchParams,document:doc,window:{confirm(){return allowConfirm},alert(text){alerts.push(text)},addEventListener(type,fn){listeners[type]=fn}},location:{href:'https://test/',protocol:'https:'},setTimeout(fn){const id=++nextTimer;timers.set(id,fn);return id},clearTimeout(id){timers.delete(id)}});
vm.runInContext(script.slice(0,script.indexOf('/* ---------- init ---------- */')),ctx);const run=s=>vm.runInContext(s,ctx),plain=x=>JSON.parse(JSON.stringify(x));
const de={format:'sfmc-builder-definition',version:1,kind:'de',data:{name:'Imported',key:'K',fields:[{name:'ID',type:'Text',maxLength:50,pk:true},{name:'Email',type:'EmailAddress'}],isSendable:true,isTestable:true,sendableField:'ID',subscriberField:'Subscriber Key'}};
ctx.input=de;assert.equal(run('cleanDefinition(input).data.fields[0].maxLength'),50);
ctx.invalid={...de,data:{...de.data,subscriberField:'Unknown'}};assert.throws(()=>run('cleanDefinition(invalid)'),/relationship/);
ctx.invalid={...de,version:2};assert.throws(()=>run('cleanDefinition(invalid)'),/version/);
ctx.invalid={...de,kind:'automation',data:{name:'Bad',steps:[{name:'Step',activities:[{type:'constructor',id:'x'}]}]}};assert.throws(()=>run('cleanDefinition(invalid)'),/Unsupported/);
ctx.input={format:'sfmc-builder-definition',version:1,kind:'automation',data:{name:'Flow',steps:[{name:'Step',activities:[{type:'query',id:'Q',name:'Query'}]}]}};
assert.equal(run('cleanDefinition(input).data.steps[0].activities[0].id'),'Q');
run("globalThis.writes=[];api=async function(action,data){writes.push({action,data});return {};};activateWorkspaceTab=function(){};setDEView=function(){};renderSteps=function(){};");
(async()=>{
 await ctx.importDefinitionFile({size:50,text:async()=>JSON.stringify(ctx.input)});assert.equal(run('state.steps[0].activities[0].id'),'Q');assert.equal(ctx.writes.length,0);
 const current=run('state.steps[0].name');await ctx.importDefinitionFile({size:131073,text:async()=>{throw new Error('must not read')}});assert.equal(run('state.steps[0].name'),current);assert.match(alerts.at(-1),/128 KB/);
 const control={id:'field',value:'original',type:'text'};node('newq-wrap').controls=[control];run("markClean('newq-wrap')");control.value='changed';assert.equal(run("isDirty('newq-wrap')"),true);allowConfirm=false;assert.equal(run("confirmDiscard('newq-wrap')"),false);allowConfirm=true;
 // Install local folder filtering, discard guards, and unload handling.
 run('initializeDefinitionTools()');control.value='changed again';let prevented=false;listeners.beforeunload({preventDefault(){prevented=true}});assert.equal(prevented,true);
 run("folderCatalog['q-folder']=[{value:'1',text:'SQL / Sales'},{value:'2',text:'SQL / Service'}]");node('q-folder').value='1';node('q-folder-filter').value='service';run("filterFolders('q-folder')");assert.match(node('q-folder').innerHTML,/Sales/);assert.match(node('q-folder').innerHTML,/Service/);assert.equal(node('q-folder').value,'1');
 // Retained instance identity survives local reorder/move; replacements are new library references.
 run("flowEditor={steps:[{id:'s1',name:'One',activities:[{instanceId:'a1',name:'Old',activityObjectId:'Q1',objectTypeId:300}]},{id:'s2',name:'Two',activities:[]}]};flowMoveStep(0,1)");assert.equal(run('flowEditor.steps[1].activities[0].instanceId'),'a1');run('flowMoveActivity(1,0,0)');assert.equal(run('flowEditor.steps[0].activities[0].instanceId'),'a1');
 run("flowLibrary=[{type:'query',id:'Q2',name:'Replacement'}]");node('flow-library').value='0';run('flowReplace(0,0)');assert.equal(run('flowEditor.steps[0].activities[0].id'),'Q2');assert.equal(run('flowEditor.steps[0].activities[0].instanceId'),undefined);
 // Monitoring refreshes are read-only, bounded, and cancelled when the modal is closed.
 run("api=async function(action){writes.push({action});return {status:'3',updatedAt:1,runs:[{id:'r1',status:'3',start:'now',end:'',message:'Running'}],activities:[],warnings:[]};};monitorContext={id:'auto',name:'Flow',version:modalVersion,request:0,polls:0};");node('monitor-auto').checked=true;node('monitor-run').value='';await run('refreshMonitor()');assert.equal(timers.size,1);assert.equal(ctx.writes.at(-1).action,'automationMonitor');run('closeModal()');assert.equal(timers.size,0);
 run("monitorContext={id:'auto',name:'Flow',version:modalVersion,request:0,polls:39};");node('monitor-auto').checked=true;await run('refreshMonitor()');assert.equal(timers.size,0);assert.equal(node('monitor-auto').checked,false);
 assert.equal(run("historyState({status:'-1',end:'2026-01-01'})"),'Failed');assert.equal(run("historyState({status:'2',end:'2026-01-01'})"),'Completed');
 // Schedule approval captures the chosen automation rather than a mutable results index.
 run("scheduleEditorTarget={ProgramID:'original-id',Name:'Original',CustomerKey:'original-key'};state.autos=[{ProgramID:'other',Name:'Other'}];api=async function(action,data){writes.push({action,data});return {};};");node('s-start').value='2026-11-01T10:00';node('s-type').value='Daily';node('s-range').value='EndAfter';node('s-occ').value='1';node('s-int').value='1';await run('saveSchedule(0)');assert.equal(ctx.writes.at(-1).data.id,'original-id');assert.equal(ctx.writes.at(-1).data.name,'Original');
 console.log('PASS: import validation and local-only draft load; prototype-key rejection; size limits; unsaved/discard/unload guards; folder selection preservation; step ID-preserving moves and replacement; read-only bounded/cancelled monitoring; stable schedule target. Mock DOM and APIs; no browser or live writes.');
})().catch(e=>{console.error(e.stack);process.exitCode=1});
