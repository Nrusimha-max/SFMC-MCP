# SFMC Builder E9 — Activity picker, retention, and DE duplication

Publish the entire `sfmc-builder-retention-duplicate.html` source to the existing CloudPage. Browser/server build identifiers must both be `SFMC-BUILDER-E9`. This release includes all earlier E7 features and fixes. The existing Installed Package configuration and three review/audit support DEs are unchanged. Login, roles, and credential-store replacement remain deferred.

## Activity picker

Choose SQL Query, Import File, Script, Data Extract, or File Transfer. Changing the type now loads that collection automatically. All pickers share type-specific ID normalization, including File Transfer ID variants; paged results use API pagination metadata. Missing/invalid IDs are reported instead of silently generating unusable rows. Draft creation, saved-step attachment, and saved-step replacement use the same mapping.

Read-only checks against configured **Primary / MID 518005762** returned HTTP 200 for each request below. Only one record per collection was requested to inspect response keys; no activity was executed or modified.

| Method | Endpoint | Status |
|---|---|---|
| GET | `/automation/v1/queries?$page=1&$pageSize=1` | 200 |
| GET | `/automation/v1/imports?$page=1&$pageSize=1` | 200 |
| GET | `/automation/v1/scripts?$page=1&$pageSize=1` | 200 |
| GET | `/automation/v1/dataextracts?$page=1&$pageSize=1` | 200 |
| GET | `/automation/v1/filetransfers?$page=1&$pageSize=1` | 200 |

`activity-read-verification.json` contains actual request metadata and response-field names, without script bodies, names, record IDs, credentials, or tokens. These reads do not verify the page's intended MID 100010552; that BU is not currently exposed by the configured MCP accounts.

## Data retention

The DE create form includes an optional duration policy:

- Days, Weeks, Months, or Years.
- Delete individual expired records; delete all records while keeping the DE; or delete the DE and all its records.
- Reset the period on import for whole-DE policies.

New drafts default to retention off. Enabling retention creates the DE and its policy together through SOAP DataExtension Create, rather than attempting to change its row-based scope afterward. The policy is read back before success is reported. A failed or ambiguous create is not retried automatically.

The DE editor shows the existing policy. It changes retention only when **Change retention policy** is checked. Unknown metadata disables policy changes and preserves existing settings. Duration, units, reset behavior, whole-DE deletion behavior, and disabling retention are supported within the existing row-based scope. Salesforce documents that `RowBasedRetention` cannot be changed through this API, so the editor does not attempt that change. Duplicate the DE to choose another scope.

Existing fixed-date retention is displayed and preserved. It can be explicitly replaced with a duration within the existing scope, but fixed-date policies are not copied or imported automatically. Duration policies with a derived expiration date are recognized as duration policies.

Expired records or DEs are permanently deleted by SFMC's retention processing. Reviews show the exact requested settings and current/proposed policy. The API account needs the Manage Data Extension Retention permission for policy writes. This task made no live retention changes.

Official references: [DataExtension properties and permission](https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/dataextension.html), [supported retention updates](https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/changing_the_retention_period_for_a_data_extension.html).

## Duplicate DE

Find & manage Data Extensions → Search → **Duplicate**.

1. Enter the new name and external key. The source external key cannot be reused.
2. Optionally copy a readable, supported source duration policy. Otherwise the new draft has retention off.
3. Open the duplicate draft, choose the destination folder, adjust settings if needed, then review **Create Data Extension**.

Fields, types, lengths, decimal scale, defaults, primary/required flags, send relationship, and testable setting populate the draft. **No records are copied.** The source remains unchanged. Missing send/test metadata or an unsupported subscriber mapping blocks exact duplication instead of silently changing those settings. Unavailable or fixed-date retention cannot be automatically copied, but schema-only duplication with retention off remains possible.

## Earlier features retained

- Create/find/edit DEs; explicit send relationships; Is Testable checkbox.
- Independent saved SQL activities; edit SQL, target, folder, and data action with conflict/readback checks.
- Automation step rename/reorder, activity moves/removal/replacement; retained instance IDs and unknown properties preserved.
- Run monitoring, actual activity messages, manual refresh and bounded opt-in polling. History availability depends on tenant SOAP support and permission.
- Current/proposed DE schema/settings comparison in change reviews.
- Unsaved-change guards for reset, editor replacement/close, and leaving the page.
- Versioned JSON export/import into local drafts. Imports do not write or execute anything; no DE rows are exported. Duration retention is included when supported/readable. Destination folders and target references need review in the destination BU.
- Local folder-path filtering.
- Single-use, expiring, session-bound reviewed mutations, MID guard, and audit trail. A browser session is not an authenticated identity.
- REST-only Run once, with no automatic mutation retries.

The support DE schemas remain in `data-extension-schemas.json`. No new support DE or migration is required for E9.

## Verification

Run `node run-checks.cjs` in this directory. Eleven local suites cover the earlier functionality, all activity types, retention create/update/off/readback and validation, immutable row scope, unknown-policy preservation, and duplicate drafts/unique keys/no record-copy requests.

SFMC writes and DOM interactions in these tests are mocked. No browser automation, publishing, live writes, sends, or execution occurred. Live read-only collection probes succeeded on Primary; end-to-end write validation in MID 100010552 remains pending. Successful local tests do not guarantee every tenant supports every SOAP property or has the required permissions.
