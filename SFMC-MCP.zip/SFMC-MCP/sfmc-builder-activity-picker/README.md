# SFMC Builder — Complete E7

This is the complete single-file CloudPage source. It preserves the existing Installed Package configuration, DE builder, finder, testable/sendable settings, reusable activities, and REST Run once behavior. Login, roles, and replacement credential storage remain deferred.

## Included features

| Feature | Where to use it |
|---|---|
| Edit saved SQL | SQL Activities → load the library → **Edit SQL**. Edit SQL, name, description, target DE external key, folder, and data action. The external key of the saved query stays fixed. |
| Run monitoring | Automation operations → search → More → **Run monitoring**. Select a run to inspect activity status and messages/errors. Refresh manually or enable bounded 15-second refresh. |
| Edit saved steps | Automation operations → More → **Edit saved steps**. Rename/reorder steps, move/remove activities, and load saved library activities to add or replace them. |
| DE comparison | Find a DE → Edit → **Save changes**. The change review shows current/proposed fields, lengths, and requested settings alongside the exact request. |
| Unsaved protection | Reset, close/replace an editor, or leave the page. Unsaved drafts prompt before discard; tab changes retain draft values. |
| Export/import | Export a DE schema, SQL definition, or automation draft. Use **Definition files** at the bottom to import a version-1 JSON file into a local draft. |
| Folder search | Use **Filter folder paths** above DE, SQL, and automation folder selectors. Existing selection is preserved while filtering. |

Retained automation step and activity instance IDs and unrecognized server properties are preserved during saved-step edits. Replacing an activity creates a new assignment to the selected saved activity; removing an assignment does not delete that activity from SFMC's library. Existing/new empty steps cannot be saved.

## Deployment prerequisites

1. Publish the **entire** `sfmc-builder-activity-picker.html` file into the existing CloudPage. Server and browser build identifiers must both be `SFMC-BUILDER-E8`.
2. Use the intended business unit. The page still checks its hosting MID against the existing CONFIG.
3. The same three support DEs are required: `SFMC_Builder_Plans`, `SFMC_Builder_Payloads`, and `SFMC_Builder_Audit`. Their schemas are in `data-extension-schemas.json`; no additional support DEs or schema changes are introduced by E7.
4. Installed Package permissions must permit the specific reads/updates/execution you choose. Publishing, provisioning DEs, and executing automations were not performed by this task.

Every server mutation still goes through the session-bound, expiring, single-use change review and audit path. A browser session is not an authenticated person. Existing credentials are not included in definition exports.

## API behavior and limits

- SQL reads/updates use SOAP `QueryDefinition` Retrieve/Update via WSProxy. The target DE is resolved by exact external key in the hosting BU. Updates compare the definition before writing and verify the resulting editable values after writing.
- Saved step editing reads `GET automation/v1/automations/{id}`, verifies the selected automation through SOAP, and submits `PATCH automation/v1/automations/{id}` with steps only. It checks for intervening changes and verifies step/activity order and retained IDs afterward. The API provides no atomic transaction across these separate reads and writes.
- Monitoring reads SOAP `Automation`, `AutomationInstance`, and `AutomationActivityInstance`. It shows raw returned status codes alongside labels and actual messages. An ended status-2 instance is labelled Completed; unknown/other ended codes remain explicit. Missing history permission/object support produces an unavailable message, not a fabricated successful run. Each history scan is bounded to ten pages and partial results are labelled. Opt-in polling stops on dialog close/replacement, its time limit, or forty refreshes.
- Run once remains the existing single REST POST start request, without automatic mutation retries.
- Imports are limited to 128 KB and an explicit versioned allowlist. They populate new drafts only; they never update existing records, save definitions, or run activities by themselves. DE imports use the default destination; SQL/automation folder selection is reset. Imported SQL targets must be resolved in the current BU. Automation activity IDs remain BU-specific and need to be checked/replaced before saving in another BU.
- JSON exports contain schemas/definitions, not DE rows, schedules, credentials, approval state, or audit records. Unknown automation activity types cannot be silently exported into an unsupported import format.
- Conflicts or uncertain write readback require inspection and a fresh review; no write is automatically replayed.

Official API references: [QueryDefinition](https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/querydefinition), [AutomationInstance](https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/automationinstance.html), [AutomationActivityInstance](https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/automationactivityinstance.html).

## Verification

Run:

```sh
node run-checks.cjs
```

Nine local suites cover syntax and static UI wiring; session/MID/approval/audit controls; standalone SQL and activity assignment; testable/sendable settings; dialog and search races; saved SQL conflict/readback; saved step identity/property preservation and replacement; schema review; versioned imports and their size/allowlist checks; unsaved-change guards; folder filtering; monitoring cancellation/limits; and stable schedule targeting.

All SFMC requests and DOM interactions in these tests are mocked. No browser automation, live publishing, sending, or execution was used. The MCP server currently exposes Primary MID 518005762 and CAN-MIK MID 100010553, while this page's intended MID is 100010552. Live end-to-end validation in the intended BU remains outstanding. The packaged code is not a guarantee that every tenant supports every SOAP object/property or that every API permission is present.
