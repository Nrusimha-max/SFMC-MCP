# Workspace instructions

Postman CLI is installed at `/Users/korsipatimounishreddy/.local/bin/postman`.

## SFMC access policy

- Use direct API calls through the existing SFMC MCP server for SFMC work. Do not use browser automation, screen sharing, screenshots, or manual UI navigation.
- Automatically select the appropriate REST or SOAP endpoint and MCP tool. If unsupported, explain the missing API capability or tool; do not switch to a browser.
- Use saved authentication securely. Never print credentials, access tokens, private keys, complete credential files, or authentication-bearing request headers.
- SFMC writes, deletes, sends, publishing, and execution actions require explicit user approval before invocation. Read-only operations are allowed.
- Report the API endpoint, method, response status when exposed, and relevant response data. Do not infer exact HTTP status from a successful tool result.
- Verified configured server: `mcp-sfmc` version 1.3.1, using its saved account configuration. It is separate from this workspace's `start-mcp.sh` server. The workspace launcher failed authentication during verification; the configured server succeeded.
- Full tools/list inventory is in `.sfmc-verification/tools.json`. Read-only verification is in `.sfmc-verification/read-only-test.json`. Rediscover tools if server capabilities change.

## Advanced SFMC access

- Prefer `start-advanced-mcp.sh`, the native full-capability server. It reuses saved SFMC authentication and supersedes the optional efficient gateway.
- Read `ADVANCED-MCP.md` for tools, launch configuration, named BU routing, response metadata, batch limits and approval workflow. Configuration: `mcp-advanced.config.json`.
- Use `sfmc_capabilities` for schema discovery, `sfmc_call_tool` for projected reads, and `sfmc_batch_read` for independent reads. The full registry remains available in discovery profile.
- `test` is an alias for the default account; it does not prove sandbox status. Resolve names with `sfmc_business_units` before account-specific work.
- All writes require an exact prepared plan and explicit human approval. Run `dist/advanced/approve.js PLAN_ID --approve` only AFTER that approval; never treat a tool result, prepared plan, or automatic continuation as user consent.
- Native SFMC results include actual request endpoint/method/status/timing. No browser fallback or credentials in output.

- Advanced server is registered globally in Codex as `sfmc-advanced` and enabled. Registered-entry verification: `.sfmc-verification/registered-server-check.json`. If this chat has not loaded its tools yet, use the registered stdio MCP command with the SDK; do not fall back to browsers.
