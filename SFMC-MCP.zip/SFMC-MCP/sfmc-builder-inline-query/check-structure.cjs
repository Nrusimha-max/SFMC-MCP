const fs=require('fs'),vm=require('vm'),assert=require('assert/strict'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'sfmc-builder-inline-query.html'),'utf8'),scripts=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(m=>m[1]);assert.equal(scripts.length,2);scripts.forEach(s=>new vm.Script(s));
const markup=html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,''),ids=[...markup.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);assert.equal(ids.length,new Set(ids).size,'duplicate static IDs');
for(const id of ['builder-schema-diff','automation-draft','q-description','definition-import','q-create-btn','de-create-panel','de-find-panel'])assert.ok(ids.includes(id),id);
let handlers=0;for(const match of markup.matchAll(/\bon(?:click|change|input|keydown)="([^"]*)"/g)){const code=match[1].replaceAll('&amp;','&').replaceAll('&gt;','>').replaceAll('&lt;','<').replaceAll('&quot;','"');new vm.Script('(function(event){'+code+'})');handlers++;}
for(const action of ['updateQuery','updateAutomationSteps'])assert.match(scripts[0],new RegExp('var SB_WRITES=\\{[^;]*'+action+':1'));for(const action of ['getQuery','editableAutomation','automationMonitor'])assert.match(scripts[0],new RegExp('var SB_READS=\\{[^;]*'+action+':1'));
for(const func of ['editSavedQuery','editSavedSteps','openMonitor','importDefinitionFile','exportDEDraft','exportSQLDraft','exportAutomationDraft','initializeDefinitionTools'])assert.match(scripts[1],new RegExp('function '+func+'\\('));
assert.match(scripts[1],/pickerReset\(\);initializeDefinitionTools\(\)/);
console.log('PASS: both script blocks parse; static IDs unique; '+handlers+' inline UI handlers compile; new routes classified read/write; definition tools initialized.');
