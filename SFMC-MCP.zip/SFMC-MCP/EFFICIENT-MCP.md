# Efficient SFMC MCP gateway

Superseded for this workspace by the full native server in `ADVANCED-MCP.md`. This remains an optional read-only gateway.

This gateway reuses the working installed `mcp-sfmc` server and its saved authentication. No extra packages, cloud services, new credentials, or browser access are required. The workspace's separate SFMC/Datorama launcher is not used.

## Connection

Build with `npm run build`. Use the `sfmc-efficient` entry in `mcp-efficient.config.json` as the MCP connection configuration, then restart that connection. The launch script is `start-efficient-mcp.sh`. The upstream executable can be selected with `SFMC_UPSTREAM_COMMAND`; its default is `mcp-sfmc` on PATH. Node.js must also be on the MCP launch environment's PATH.

The configuration file is a ready-to-use example, not an automatic registration. Existing app connections have not been changed. To get the context savings, use the gateway instead of also exposing the full upstream tool catalog in the same chat.

## Use

1. Call `sfmc_find_tools` with a short query such as `journey list`. It returns matching read-only tools, descriptions, and argument schemas. Default: five matches, with offset pagination.
2. Call `sfmc_read` with the chosen `tool` name and its `arguments`. Set `maxItems` (default 10) and optional `fields` such as `["id", "name", "status"]` to limit array records in the result.

A journey example:

```json
{"tool":"sfmc_journey_list","arguments":{"page":1,"pageSize":1},"maxItems":1,"fields":["id","name","status"]}
```

Use API filters and API pagination first: output trimming reduces model context, not SFMC's network response size. This upstream version returned 50 journeys despite receiving `pageSize: 1`; the gateway clearly marks records omitted from its output.

## Performance and limits

- Two model-facing tools replace the initial 126-tool catalog. Tool schemas are discovered only when needed.
- One persistent upstream process per gateway connection reuses the server's existing token cache and authenticated API clients.
- Concurrent identical requests share an in-flight result. There is no response cache, so subsequent reads request fresh data.
- Read output is compact JSON with a 12,000-byte cap. Discovery has a 24,000-byte cap. Truncation is explicit and remains valid JSON.
- Requests time out after 30 seconds. No claim of lower Salesforce processing latency or a particular billing reduction is made.
- An explicit allowlist exposes 46 known read-only tools. Unknown tools, writes, execution actions, and access-token retrieval fail closed. For an explicitly approved write, use the original connection; this gateway deliberately cannot perform it.
- Sensitive property names are redacted. Upstream stderr is suppressed and transport errors are generalized to avoid leaking authentication details. Continue to use API field selection to avoid retrieving unnecessary personal data.
- The upstream server discards successful HTTP status codes and endpoint metadata. The gateway reports that limitation rather than inventing status codes. It adds no generic arbitrary-request capability.

## Validation

`npm run build` and `npx vitest run tests/efficient-response.test.ts` validate compilation, the read-only allowlist, redaction, field projection, and bounded UTF-8 output. A live MCP read verified the upstream connection and compact journey output; a blocked write name was checked without forwarding it upstream.

The earlier eight failures in outdated SFMC/Datorama test fixtures were corrected during the advanced server upgrade. See `ADVANCED-MCP.md` for current validation.
