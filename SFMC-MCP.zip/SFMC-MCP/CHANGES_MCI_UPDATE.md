# MCP server update — MCI dashboard automation

## What changed
1. **datorama_create_dashboard — FIXED "jsonConfig must not be null".**
   - Now generates a minimal valid one-page layout automatically (was sending `'{}'`, which Datorama rejects).
   - New optional inputs:
     - `pageName` — name of the default page (default "Page 1").
     - `jsonConfig` — pass a full dashboard layout (object or JSON string) to replicate an exact page. Capture it from an existing dashboard's create/update network POST and pass it here for a pixel-exact page.

2. **datorama_create_widget — now supports Custom Widgets + raw payload passthrough.**
   - `widgetType` gained `"custom"` (in addition to chart/table/metric/filter).
   - `measurements` is now optional (custom widgets don't need them).
   - New `custom` input: `{ html, css, javascript }` → creates a Custom Widget from HTML/CSS/JS panes (so the Vendor Table / Patient Records / Roster / Timeline widgets can be pushed via API).
   - New `config` input: an object merged verbatim into the widget POST body — supply the exact Datorama widget payload when the typed fields aren't enough.

## Verification note (important)
Datorama's dashboard/widget **layout schema is internal/undocumented**. The generated defaults are best-effort and compile/validate, but the *exact* field names Datorama expects for a page layout or a custom-widget config can vary by tenant/version. The reliable way to get a 100%-faithful payload:
  1. Create one dashboard/custom-widget in the Datorama UI.
  2. In the browser Network tab, copy the POST request body (the `jsonConfig` / widget config).
  3. Pass that object to `jsonConfig` (dashboard) or `config` (widget) — the tools now forward it verbatim.

Everything else (list/get/run_query, calculated measurements, data streams, SFMC tools) is unchanged.

## Build
`npm install && npm run build` (already compiled into /dist in this package).
