import axios from 'axios';
import { readFileSync, renameSync, writeFileSync } from 'node:fs';
import type { Logger } from '../logger.js';
import { UpstreamApiError } from '../types.js';

export interface SfmcAuthConfig {
  subdomain: string;
  clientId: string;
  clientSecret: string;
  /** MID — passed as account_id in the token request. */
  accountId: string;
  logger: Logger;
  /** Override for tests. */
  authBaseUrl?: string;
  /**
   * User-context (Web App) auth: path to a 0600 file holding the current refresh token.
   * When set, tokens are obtained with grant_type=refresh_token and act as the authorizing
   * user, so SFMC records that user as creator/modifier. Each refresh rotates the token file.
   */
  refreshTokenPath?: string;
}

interface TokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
  scope?: string;
  soap_instance_url?: string;
  rest_instance_url?: string;
  refresh_token?: string;
}

/** Atomically replace the refresh-token file, keeping it readable only by the owner. */
export function writeRefreshToken(path: string, token: string): void {
  const tmp = `${path}.tmp`;
  writeFileSync(tmp, token, { mode: 0o600 });
  renameSync(tmp, path);
}

interface CachedToken {
  accessToken: string;
  /** Epoch ms when the token should be considered stale (60s safety margin). */
  expiresAtMs: number;
  soapInstanceUrl?: string;
  restInstanceUrl?: string;
}

const REFRESH_SAFETY_MS = 60_000;

/**
 * OAuth client_credentials manager for SFMC.
 *
 * Caches the access token in memory and proactively refreshes 60s before
 * the upstream `expires_in` deadline. Concurrent callers share a single
 * in-flight refresh promise.
 */
export class SfmcAuth {
  private readonly cfg: SfmcAuthConfig;
  private readonly logger: Logger;
  private readonly tokenCache = new Map<string, CachedToken>();
  private readonly inFlightCache = new Map<string, Promise<CachedToken>>();

  constructor(cfg: SfmcAuthConfig) {
    this.cfg = cfg;
    this.logger = cfg.logger.child('auth');
  }

  /** Tenant auth base — e.g. https://mc6abcdef.auth.marketingcloudapis.com */
  get authBaseUrl(): string {
    return this.cfg.authBaseUrl ?? `https://${this.cfg.subdomain}.auth.marketingcloudapis.com`;
  }

  /** Currently cached REST instance URL for the default account, if any. */
  get restInstanceUrl(): string | undefined {
    return this.tokenCache.get(this.cfg.accountId)?.restInstanceUrl;
  }

  /** Currently cached SOAP instance URL for the default account, if any. */
  get soapInstanceUrl(): string | undefined {
    return this.tokenCache.get(this.cfg.accountId)?.soapInstanceUrl;
  }

  /**
   * Return a valid access token, fetching or refreshing as needed.
   * Pass accountId to obtain a token scoped to a specific Business Unit.
   */
  async getAccessToken(accountId?: string): Promise<string> {
    const tok = await this.getToken(accountId);
    return tok.accessToken;
  }

  /**
   * Force a token refresh on the next call. Use when a 401 is observed.
   * Pass accountId to invalidate only that BU's cached token.
   */
  invalidate(accountId?: string): void {
    const key = accountId ?? this.cfg.accountId;
    this.logger.debug('token invalidated', key);
    this.tokenCache.delete(key);
  }

  private async getToken(accountId?: string): Promise<CachedToken> {
    const key = accountId ?? this.cfg.accountId;
    const now = Date.now();
    const cached = this.tokenCache.get(key);
    if (cached && cached.expiresAtMs > now) return cached;
    const existing = this.inFlightCache.get(key);
    if (existing) return existing;
    const promise = this.fetchToken(accountId)
      .then((tok) => {
        this.tokenCache.set(key, tok);
        return tok;
      })
      .finally(() => {
        this.inFlightCache.delete(key);
      });
    this.inFlightCache.set(key, promise);
    return promise;
  }

  private async fetchToken(accountId?: string): Promise<CachedToken> {
    const targetAccountId = accountId ?? this.cfg.accountId;
    const url = `${this.authBaseUrl}/v2/token`;
    this.logger.debug('requesting new token from', url);
    const userContext = this.cfg.refreshTokenPath !== undefined;
    try {
      const res = await axios.post<TokenResponse>(
        url,
        userContext
          ? {
              grant_type: 'refresh_token',
              client_id: this.cfg.clientId,
              client_secret: this.cfg.clientSecret,
              refresh_token: readFileSync(this.cfg.refreshTokenPath!, 'utf8').trim()
            }
          : {
              grant_type: 'client_credentials',
              client_id: this.cfg.clientId,
              client_secret: this.cfg.clientSecret,
              account_id: targetAccountId
            },
        {
          headers: { 'Content-Type': 'application/json' },
          timeout: 15_000
        }
      );
      const body = res.data;
      // SFMC rotates refresh tokens; the previous one is invalid once a new one is issued.
      if (userContext && body.refresh_token) writeRefreshToken(this.cfg.refreshTokenPath!, body.refresh_token);
      const expiresInMs = (body.expires_in ?? 1080) * 1000;
      const expiresAtMs = Date.now() + Math.max(0, expiresInMs - REFRESH_SAFETY_MS);
      this.logger.info(
        `token acquired for ${targetAccountId} (expires in ${Math.round(expiresInMs / 1000)}s, rest=${body.rest_instance_url ?? 'n/a'})`
      );
      return {
        accessToken: body.access_token,
        expiresAtMs,
        soapInstanceUrl: body.soap_instance_url,
        restInstanceUrl: body.rest_instance_url
      };
    } catch (err) {
      const ax = err as { response?: { status?: number; data?: unknown }; message?: string };
      const status = ax.response?.status ?? 0;
      const data = ax.response?.data as Record<string, unknown> | undefined;
      const message =
        (typeof data?.error_description === 'string' && data.error_description) ||
        (typeof data?.message === 'string' && data.message) ||
        ax.message ||
        'SFMC token request failed';
      this.logger.error('token request failed', status, message);
      throw new UpstreamApiError({
        status: status || 0,
        message: `SFMC auth failed: ${message}`,
        details: data
      });
    }
  }
}
