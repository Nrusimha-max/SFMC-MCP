import axios from 'axios';
import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import type { Logger } from '../logger.js';

export type DatoramaRegion = 'us' | 'eu' | 'ap';

export interface DatoramaAuthConfig {
  apiToken?: string;
  serviceAccountId?: string;
  privateKey?: string;
  discoveryEndpoint?: string;
  region: DatoramaRegion;
  logger: Logger;
  baseUrl?: string;
}

const REGION_HOSTS: Record<DatoramaRegion, string> = {
  us: 'https://api.datorama.com',
  eu: 'https://api.eu.datorama.com',
  ap: 'https://api.ap.datorama.com'
};

export class DatoramaAuth {
  private readonly cfg: DatoramaAuthConfig;
  private readonly logger: Logger;
  private accessToken?: string;
  private accessTokenExpiresAt = 0;

  constructor(cfg: DatoramaAuthConfig) {
    this.cfg = cfg;
    this.logger = cfg.logger.child('auth');
  }

  get baseUrl(): string {
    return this.cfg.baseUrl ?? REGION_HOSTS[this.cfg.region];
  }

  async authHeader(): Promise<{ Authorization: string }> {
    if (this.cfg.apiToken && this.cfg.apiToken.trim() !== '') {
      return { Authorization: `Token ${this.cfg.apiToken}` };
    }

    const token = await this.getOAuthAccessToken();
    return { Authorization: `Bearer ${token}` };
  }

  async handleUnauthorized(): Promise<void> {
    this.accessToken = undefined;
    this.accessTokenExpiresAt = 0;
    this.logger.error('Datorama returned 401 — OAuth token was cleared and will be refreshed');
  }

  private async getOAuthAccessToken(): Promise<string> {
    if (this.accessToken && Date.now() < this.accessTokenExpiresAt) {
      return this.accessToken;
    }

    const serviceAccountId = this.cfg.serviceAccountId;
    const privateKey = this.cfg.privateKey?.replace(/\\n/g, '\n');
    const discoveryEndpoint = this.cfg.discoveryEndpoint;

    if (!serviceAccountId || !privateKey || !discoveryEndpoint) {
      throw new Error(
        'Missing Datorama auth config. Provide either DATORAMA_API_TOKEN or DATORAMA_SERVICE_ACCOUNT_ID, DATORAMA_PRIVATE_KEY, and DATORAMA_DISCOVERY_ENDPOINT.'
      );
    }

    const discoveryRes = await axios.get<{ token_endpoint: string; issuer?: string }>(discoveryEndpoint);
    const tokenEndpoint = discoveryRes.data.token_endpoint;
    // aud must be the issuer (not the token endpoint) for this IDP
    const issuer = discoveryRes.data.issuer ?? tokenEndpoint;

    const now = Math.floor(Date.now() / 1000);

    const assertion = jwt.sign(
      {
        iss: serviceAccountId,
        sub: serviceAccountId,
        aud: issuer,
        iat: now,
        exp: now + 300,
        jti: crypto.randomUUID()
      },
      privateKey,
      { algorithm: 'RS256' }
    );

    let tokenRes: Awaited<ReturnType<typeof axios.post<{ access_token: string; expires_in?: number; token_type?: string }>>>;
    try {
      tokenRes = await axios.post<{
        access_token: string;
        expires_in?: number;
        token_type?: string;
      }>(
        tokenEndpoint,
        new URLSearchParams({
          grant_type: 'client_credentials',
          client_id: serviceAccountId,
          client_assertion_type: 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer',
          client_assertion: assertion
        }),
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );
    } catch (err) {
      const axErr = err as import('axios').AxiosError;
      const status = axErr.response?.status;
      const body = JSON.stringify(axErr.response?.data);
      this.logger.error(`Datorama token exchange failed — status=${status} body=${body} endpoint=${tokenEndpoint} serviceAccountId=${serviceAccountId}`);
      throw new Error(`Datorama token exchange failed (${status}): ${body ?? axErr.message}`);
    }

    this.accessToken = tokenRes.data.access_token;
    this.accessTokenExpiresAt =
      Date.now() + ((tokenRes.data.expires_in ?? 3600) - 60) * 1000;

    return this.accessToken;
  }
}