import { boundedJson, compactPayload } from './efficient-response.js';
import type { ApiErrorShape, ToolHandlerResult } from '../types.js';
import { UpstreamApiError } from '../types.js';

const DEFAULT_MAX_BYTES = 100_000;

function getMaxBytes(): number {
  const raw = process.env.MCP_MAX_RESPONSE_BYTES;
  if (!raw) return DEFAULT_MAX_BYTES;
  const n = Number(raw);
  return Number.isFinite(n) && n > 1024 ? Math.floor(n) : DEFAULT_MAX_BYTES;
}

/**
 * Serialize an arbitrary value to a single MCP `text` content block,
 * truncating with a clear marker if it would exceed the byte cap.
 */
export function toTextContent(value: unknown): { type: 'text'; text: string }[] {
  const max = getMaxBytes();
  if (process.env.MCP_COMPACT === '1') return [{ type: 'text', text: boundedJson(compactPayload(value, 100), max) }];
  const json = safeStringify(compactPayload(value, Number.MAX_SAFE_INTEGER));
  if (Buffer.byteLength(json, 'utf8') <= max) {
    return [{ type: 'text', text: json }];
  }
  // Truncate by character count (close enough; we re-check bytes).
  const truncated = json.slice(0, max).replace(/[\s,{[]*$/, '');
  const marker =
    '\n\n…[TRUNCATED: response exceeded ' +
    max +
    ' bytes. Use a tighter filter, smaller $top, or a narrower date range.]';
  return [{ type: 'text', text: truncated + marker }];
}

function safeStringify(value: unknown): string {
  try {
    return JSON.stringify(value, null, 2);
  } catch (err) {
    return JSON.stringify({
      error: 'Failed to serialize result',
      message: (err as Error).message
    });
  }
}

/**
 * Convert a thrown error or successful value into an MCP CallToolResult body.
 * MCP convention: tool errors set `isError: true` and put the error message
 * in the content text — they are not transport-level errors.
 */
export function toMcpResult(
  result: ToolHandlerResult
): { content: { type: 'text'; text: string }[]; isError?: boolean } {
  if (result.ok) {
    return { content: toTextContent(result.data) };
  }
  return {
    content: toTextContent({ error: result.error }),
    isError: true
  };
}

/**
 * Wrap a tool handler so any thrown error becomes a structured ApiErrorShape.
 */
export async function runTool(
  handler: () => Promise<unknown>
): Promise<ToolHandlerResult> {
  try {
    const data = await handler();
    return { ok: true, data };
  } catch (err) {
    return { ok: false, error: errorToShape(err) };
  }
}

export function errorToShape(err: unknown): ApiErrorShape {
  if (err instanceof UpstreamApiError) {
    return { ...err.toJSON(), requests: (err as Error & { apiRequests?: unknown[] }).apiRequests }; 
  }
  if (err instanceof Error) {
    return { status: 0, message: err.message, requests: (err as Error & { apiRequests?: unknown[] }).apiRequests };
  }
  return { status: 0, message: String(err) };
}
