/** Limit model-facing payloads while keeping valid JSON and explicit truncation. */
export function compactPayload(value: unknown, maxItems = 10, fields?: string[]): unknown {
  if (Array.isArray(value)) {
    const items = value.slice(0, maxItems).map(v => compactPayload(v, maxItems, fields));
    return value.length > maxItems ? { items, returned: items.length, available: value.length, truncated: true } : items;
  }
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([key, entry]) => {
      if (/token|secret|password|private.?key|authorization|client.?id/i.test(key)) return [key, '[REDACTED]'];
      const projected = Array.isArray(entry) && fields?.length
        ? entry.map(item => item && typeof item === 'object'
          ? Object.fromEntries(Object.entries(item).filter(([k]) => fields.includes(k))) : item)
        : entry;
      return [key, compactPayload(projected, maxItems, fields)];
    }));
  }
  return value;
}

export function boundedJson(value: unknown, maxBytes = 12000): string {
  const json = JSON.stringify(value);
  if (Buffer.byteLength(json, 'utf8') <= maxBytes) return json;
  let preview = json.slice(0, Math.floor(maxBytes / 2));
  while (true) {
    const out = JSON.stringify({ truncated: true, originalBytes: Buffer.byteLength(json),
      hint: 'Use narrower filters, pagination, maxItems, or fields.', preview });
    if (Buffer.byteLength(out) <= maxBytes) return out;
    preview = preview.slice(0, Math.floor(preview.length * 0.75));
  }
}
