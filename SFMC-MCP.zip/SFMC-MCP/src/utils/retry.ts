import axios, { AxiosError, AxiosRequestConfig, AxiosResponse } from 'axios';
import type { Logger } from '../logger.js';
import { UpstreamApiError } from '../types.js';

export interface RetryOptions {
  maxRetries?: number;
  baseDelayMs?: number;
  maxDelayMs?: number;
  /**
   * Called once when a 401 is observed. Should refresh the upstream token.
   * If it resolves, the request is retried exactly one extra time on top of
   * the normal retry budget. If it throws, the original 401 surfaces.
   */
  onUnauthorized?: () => Promise<void>;
  /**
   * Mutates the request config right before the (re-)attempt is dispatched.
   * Used to inject a freshly-minted Authorization header after refresh.
   */
  prepareConfig?: (config: AxiosRequestConfig) => Promise<AxiosRequestConfig> | AxiosRequestConfig;
  logger: Logger;
  /**
   * Human label for the operation (e.g. "POST /v2/query/sources/workspace/123").
   * Used purely for logging.
   */
  label: string;
}

const RETRYABLE_STATUS = new Set([408, 429, 500, 502, 503, 504]);

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function jitter(ms: number): number {
  return Math.round(ms * (0.5 + Math.random() * 0.5));
}

function parseRetryAfter(header: string | undefined): number | null {
  if (!header) return null;
  const secs = Number(header);
  if (Number.isFinite(secs)) return Math.max(0, Math.floor(secs * 1000));
  const date = Date.parse(header);
  if (!Number.isNaN(date)) return Math.max(0, date - Date.now());
  return null;
}

function extractErrorMessage(err: AxiosError): string {
  const data = err.response?.data as unknown;
  if (typeof data === 'string' && data.trim()) return data;
  if (data && typeof data === 'object') {
    const obj = data as Record<string, unknown>;
    const direct =
      (typeof obj.message === 'string' && obj.message) ||
      (typeof obj.error_description === 'string' && obj.error_description) ||
      (typeof obj.error === 'string' && obj.error) ||
      (typeof obj.detail === 'string' && obj.detail);
    if (direct) return direct;
    // SFMC REST returns { errors: [{ message, errorcode }] }
    const errors = obj.errors;
    if (Array.isArray(errors) && errors.length > 0) {
      const first = errors[0] as Record<string, unknown>;
      if (typeof first?.message === 'string') return first.message;
    }
    // Datorama returns { errorMessage } or { errors: { ... } }
    if (typeof obj.errorMessage === 'string') return obj.errorMessage;
  }
  return err.message || 'Upstream request failed';
}

function extractErrorCode(err: AxiosError): string | number | undefined {
  const data = err.response?.data as Record<string, unknown> | undefined;
  if (!data) return undefined;
  if (typeof data.errorcode === 'string' || typeof data.errorcode === 'number') return data.errorcode;
  if (typeof data.code === 'string' || typeof data.code === 'number') return data.code;
  const errors = data.errors;
  if (Array.isArray(errors) && errors.length > 0) {
    const first = errors[0] as Record<string, unknown>;
    const c = first?.errorcode ?? first?.code;
    if (typeof c === 'string' || typeof c === 'number') return c;
  }
  return undefined;
}

/**
 * Run an HTTP request with retry/backoff, 401-refresh, and Retry-After support.
 *
 * - Retries on network errors and on 408/429/5xx (capped at `maxRetries`).
 * - On 401, calls `onUnauthorized` once, then re-issues the request through
 *   `prepareConfig` so the new token can be injected.
 * - Honors `Retry-After` on 429/503 (overrides exponential backoff).
 * - Non-retryable 4xx surface as `UpstreamApiError` with the API's message.
 */
export async function requestWithRetry<T>(
  config: AxiosRequestConfig,
  options: RetryOptions
): Promise<AxiosResponse<T>> {
  const {
    maxRetries = 3,
    baseDelayMs = 500,
    maxDelayMs = 8000,
    onUnauthorized,
    prepareConfig,
    logger,
    label
  } = options;

  let attempt = 0;
  let didRefresh = false;

  // attempt budget: initial + maxRetries. 401 refresh adds one extra slot.
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const effectiveConfig = prepareConfig ? await prepareConfig({ ...config }) : config;
    try {
      const res = await axios.request<T>(effectiveConfig);
      if (attempt > 0) {
        logger.debug(`${label} succeeded after ${attempt} retr${attempt === 1 ? 'y' : 'ies'}`);
      }
      return res;
    } catch (rawErr) {
      const err = rawErr as AxiosError;
      const status = err.response?.status;

      // 401 → refresh once, retry without consuming the retry budget.
      if (status === 401 && onUnauthorized && !didRefresh) {
        didRefresh = true;
        logger.warn(`${label} returned 401; refreshing token and retrying once`);
        try {
          await onUnauthorized();
        } catch (refreshErr) {
          logger.error(`${label} token refresh failed`, (refreshErr as Error).message);
          throw new UpstreamApiError({
            status: 401,
            message: extractErrorMessage(err),
            code: extractErrorCode(err),
            details: err.response?.data
          });
        }
        continue;
      }

      const isNetwork = !err.response;
      const retryable = isNetwork || (status !== undefined && RETRYABLE_STATUS.has(status));

      if (!retryable || attempt >= maxRetries) {
        if (status !== undefined) {
          throw new UpstreamApiError({
            status,
            message: extractErrorMessage(err),
            code: extractErrorCode(err),
            details: err.response?.data
          });
        }
        // Network failure with no response object.
        throw new UpstreamApiError({
          status: 0,
          message: err.message || 'Network error',
          details: { code: err.code }
        });
      }

      // Compute backoff. Retry-After wins if present.
      const headers = (err.response?.headers ?? {}) as Record<string, string>;
      const retryAfter = parseRetryAfter(headers['retry-after'] ?? headers['Retry-After']);
      const exp = Math.min(maxDelayMs, baseDelayMs * 2 ** attempt);
      const wait = retryAfter ?? jitter(exp);
      attempt += 1;
      logger.warn(
        `${label} attempt ${attempt} failed (${status ?? 'network'}); retrying in ${wait}ms`
      );
      await sleep(wait);
    }
  }
}

/** Test seam: re-export axios so tests can mock the singleton. */
export { axios };
