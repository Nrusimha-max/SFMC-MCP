import { AsyncLocalStorage } from 'node:async_hooks';
export interface ApiTrace { endpoint: string; method: string; status: number; durationMs: number; soapAction?: string }
export const apiTrace = new AsyncLocalStorage<ApiTrace[]>();
export function recordApi(trace: ApiTrace): void { apiTrace.getStore()?.push(trace); }
export async function traceCall<T>(call: () => Promise<T>): Promise<{ data: T; requests: ApiTrace[] }> {
  const requests: ApiTrace[] = [];
  return apiTrace.run(requests, async () => {
    try { return { data: await call(), requests }; }
    catch (error) { if (error instanceof Error) Object.assign(error, { apiRequests: requests }); throw error; }
  });
}
