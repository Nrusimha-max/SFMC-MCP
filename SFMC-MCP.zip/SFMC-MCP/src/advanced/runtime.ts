import { resolve } from 'node:path';
import { z, type ZodType } from 'zod';
import { zodToJsonSchema } from 'zod-to-json-schema';
import type { SfmcToolContext } from '../sfmc/context.js';
import { READ_TOOLS, restIsRead, validateRestPath } from './policy.js';
import { PlanStore } from './plans.js';
import { traceCall } from './trace.js';
import { errorToShape } from '../utils/response.js';
import { compactPayload } from '../utils/efficient-response.js';

export interface RuntimeTool { name: string; description: string; schema: ZodType; handler: (input: any) => Promise<unknown> }
const restSchema = z.object({ bu: z.string().min(1).max(200).default('test'), method: z.enum(['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE']).default('GET'), path: z.string().max(2000), query: z.record(z.union([z.string(), z.number(), z.boolean()])).optional(), body: z.unknown().optional() }).strict().superRefine((input, ctx) => {
  try { validateRestPath(input.path); } catch { ctx.addIssue({ code: 'custom', message: 'Invalid tenant-relative REST path' }); }
  if (['GET', 'HEAD'].includes(input.method) && input.body !== undefined) ctx.addIssue({ code: 'custom', message: 'GET and HEAD cannot have a body' });
  if (Object.keys(input.query ?? {}).some(key => /token|secret|authorization|password/i.test(key))) ctx.addIssue({ code: 'custom', message: 'Authentication values cannot be passed as query parameters' });
});
export class AdvancedRuntime {
  readonly plans = new PlanStore(resolve(process.env.SFMC_PLAN_DIRECTORY || '.sfmc-plans'));
  readonly startedAt = Date.now();
  private active = 0;
  private completed = 0;
  private failures = 0;
  private totalMs = 0;
  private readonly management = new Set(['sfmc_capabilities', 'sfmc_diagnostics', 'sfmc_rest_request', 'sfmc_batch_read', 'sfmc_prepare_change', 'sfmc_execute_change', 'sfmc_connection_health', 'sfmc_business_units', 'sfmc_call_tool']);
  constructor(private readonly tools: Map<string, RuntimeTool>, private readonly ctx: SfmcToolContext, private readonly accounts: Array<{ alias: string; name: string; accountId: string }>) {}
  private target(name: string, args: unknown): { tool: RuntimeTool; input: any } {
    const tool = this.tools.get(name);
    if (!tool) throw new Error('Unknown API tool; use sfmc_capabilities to discover supported operations');
    return { tool, input: tool.schema.parse(args) };
  }
  private readable(name: string, input: any): boolean {
    return READ_TOOLS.has(name) || (name === 'sfmc_rest_request' && restIsRead(input.method, input.path));
  }
  private async execute(name: string, input: any): Promise<unknown> {
    const tool = this.tools.get(name)!;
    const started = Date.now(); this.active++;
    try {
      const result = await traceCall(() => tool.handler(input));
      this.completed++;
      return { tool: name, ...result };
    } catch (error) { this.failures++; throw error; }
    finally { this.active--; this.totalMs += Date.now() - started; }
  }
  async invoke(name: string, args: unknown): Promise<unknown> {
    const { input } = this.target(name, args);
    if (!this.readable(name, input) && !this.management.has(name)) throw new Error('This operation requires explicit approval. Use sfmc_prepare_change, review the exact plan with the user, approve locally, then sfmc_execute_change.');
    if (name === 'sfmc_rest_request' && !this.readable(name, input)) throw new Error('REST writes require sfmc_prepare_change and one-time local approval');
    return this.execute(name, input);
  }
  definitions(): RuntimeTool[] {
    return [
      { name: 'sfmc_capabilities', description: 'Search all available tools and optionally return argument schemas and approval requirements. Local discovery; no SFMC API call.', schema: z.object({ query: z.string().default(''), offset: z.number().int().min(0).default(0), limit: z.number().int().min(1).max(30).default(10), includeSchemas: z.boolean().default(false) }).strict(), handler: async input => {
        const words = input.query.toLowerCase().split(/\s+/).filter(Boolean);
        const matches = [...this.tools.values()].filter(t => words.every((w: string) => `${t.name} ${t.description}`.toLowerCase().includes(w)));
        return { total: this.tools.size, matched: matches.length, items: matches.slice(input.offset, input.offset + input.limit).map(t => ({ name: t.name, description: t.description, requiresApproval: t.name === 'sfmc_rest_request' ? 'method-dependent' : t.name === 'sfmc_execute_change' || (!READ_TOOLS.has(t.name) && !this.management.has(t.name)), ...(input.includeSchemas ? { inputSchema: zodToJsonSchema(t.schema) } : {}) })), nextOffset: input.offset + input.limit < matches.length ? input.offset + input.limit : null };
      } },
      { name: 'sfmc_call_tool', description: 'Invoke a discovered read-only tool with its validated native arguments, with optional field projection. Use in discovery profile to access the full API registry. Writes still require a reviewed approved plan.', schema: z.object({ tool: z.string(), arguments: z.record(z.unknown()).default({}), maxItems: z.number().int().min(1).max(100).default(25), fields: z.array(z.string()).max(50).optional() }).strict(), handler: async input => {
        const target = this.target(input.tool, input.arguments);
        if (!this.readable(input.tool, target.input)) throw new Error('Call accepts read-only API tools; writes require an approved change plan');
        const result = await this.execute(input.tool, target.input) as { tool: string; data: unknown; requests: unknown[] };
        return { ...result, data: compactPayload(result.data, input.maxItems, input.fields) };
      } },
      { name: 'sfmc_business_units', description: 'List configured business-unit aliases and names without credentials.', schema: z.object({}).strict(), handler: async () => ({ accounts: this.accounts }) },
      { name: 'sfmc_diagnostics', description: 'Local runtime health and call metrics; does not expose authentication or make API calls.', schema: z.object({}).strict(), handler: async () => ({ uptimeMs: Date.now() - this.startedAt, active: this.active, completed: this.completed, failures: this.failures, averageDurationMs: this.completed + this.failures ? Math.round(this.totalMs / (this.completed + this.failures)) : 0, registeredTools: this.tools.size, writes: 'exact-plan-local-approval', apiOnly: true, responseCache: false }) },
      { name: 'sfmc_connection_health', description: 'Perform a read-only REST connectivity probe for a configured business unit, reporting endpoint, HTTP status and timing.', schema: z.object({ bu: z.string().min(1).max(200).default('test') }).strict(), handler: async input => {
        await this.ctx.client.rest({ method: 'GET', path: '/interaction/v1/interactions', query: { $pageSize: 1, $page: 1 }, accountId: this.ctx.resolveAccountId(input.bu) });
        return { connected: true, bu: input.bu };
      } },
      { name: 'sfmc_rest_request', description: 'Direct authenticated tenant REST request. GET/HEAD and Content Builder query are read-only; all other methods require a prepared approved change. No arbitrary host or auth headers.', schema: restSchema, handler: async input => this.ctx.client.rest({ ...input, accountId: this.ctx.resolveAccountId(input.bu) }) },
      { name: 'sfmc_batch_read', description: 'Run up to 20 independent read-only API tools with up to 4 concurrent calls. Returns per-call data, status metadata and isolated errors. No writes or nested batches.', schema: z.object({ concurrency: z.number().int().min(1).max(4).default(3), calls: z.array(z.object({ tool: z.string(), arguments: z.record(z.unknown()).default({}) }).strict()).min(1).max(20) }).strict(), handler: async input => {
        // Validate every request before starting any network work.
        const calls = input.calls.map((call: {tool: string; arguments: unknown}) => {
          const target = this.target(call.tool, call.arguments);
          if (!this.readable(call.tool, target.input)) throw new Error('Batch accepts only read-only API tools');
          return { name: call.tool, input: target.input };
        });
        const results: unknown[] = new Array(calls.length); let next = 0;
        await Promise.all(Array.from({ length: Math.min(input.concurrency, calls.length) }, async () => {
          while (next < calls.length) { const index = next++; const call = calls[index];
            try { results[index] = { ok: true, ...await this.execute(call.name, call.input) as object }; }
            catch (error) { results[index] = { ok: false, tool: call.name, error: errorToShape(error) }; }
          }
        }));
        return { results };
      } },
      { name: 'sfmc_prepare_change', description: 'Validate and save an exact write request for human review, without executing it. Plan expires in 10 minutes. Local CLI approval is required before execution.', schema: z.object({ tool: z.string(), arguments: z.record(z.unknown()) }).strict(), handler: async input => {
        const target = this.target(input.tool, input.arguments);
        if (this.readable(input.tool, target.input) || (this.management.has(input.tool) && input.tool !== 'sfmc_rest_request')) throw new Error('Prepare only a mutating SFMC/Datorama API tool');
        const plan = await this.plans.prepare(input.tool, target.input);
        return { planId: plan.id, tool: plan.tool, arguments: compactPayload(plan.arguments, 100), digest: plan.digest, reviewFile: resolve(this.plans.directory, `${plan.id}.json`), expiresAt: new Date(plan.expiresAt).toISOString(), instruction: 'Present this exact change to the user and obtain explicit approval. Only then run the local approval CLI with this plan ID. Preparation does not approve or execute anything.' };
      } },
      { name: 'sfmc_execute_change', description: 'Execute the exact approved plan once. Cannot change its arguments. Plans must be approved through the local CLI after explicit user approval. Approval is consumed before dispatch.', schema: z.object({ planId: z.string().uuid() }).strict(), handler: async input => {
        const preview = await this.plans.inspect(input.planId);
        const target = this.target(preview.tool, preview.arguments);
        if (this.readable(preview.tool, target.input) || (this.management.has(preview.tool) && preview.tool !== 'sfmc_rest_request')) throw new Error('Invalid change-plan target');
        await this.plans.consume(input.planId);
        return this.execute(preview.tool, target.input);
      } }
    ];
  }
}
