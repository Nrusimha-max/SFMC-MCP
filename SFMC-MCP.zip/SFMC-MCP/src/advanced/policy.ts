/** Unknown tool names require a reviewed change plan. */
export const READ_TOOLS = new Set([
  'sfmc_list_data_extensions', 'sfmc_get_data_extension_rows', 'sfmc_query_soap',
  'sfmc_list_journeys', 'sfmc_get_journey', 'sfmc_get_journey_graph', 'sfmc_get_journey_activity', 'sfmc_get_email_send_summary',
  'sfmc_list_automations', 'sfmc_get_automation', 'sfmc_get_automation_history',
  'sfmc_get_automation_soap', 'sfmc_list_automations_soap', 'sfmc_debug_soap_automation',
  'sfmc_list_assets', 'sfmc_get_asset', 'sfmc_get_cloudpage_url', 'sfmc_get_contact',
  'sfmc_list_contact_attribute_groups', 'sfmc_get_journey_metrics', 'sfmc_list_subscribers',
  'sfmc_get_subscriber', 'sfmc_list_lists', 'sfmc_list_users', 'sfmc_query_data_view',
  'sfmc_get_subscriber_send_history', 'sfmc_get_einstein_sto_score', 'sfmc_get_query_definition',
  'datorama_list_workspaces', 'datorama_get_workspace', 'datorama_list_measurements',
  'datorama_list_dimensions', 'datorama_list_calculated_measurements', 'datorama_get_calculated_measurement',
  'datorama_list_dashboards', 'datorama_get_dashboard', 'datorama_export_dashboard_data',
  'datorama_list_data_streams', 'datorama_get_data_stream', 'datorama_list_reports',
  'datorama_run_query', 'datorama_list_widgets', 'datorama_get_widget'
]);

export function validateRestPath(path: string): void {
  if (/\s/.test(path)) throw new Error('Encode whitespace in REST paths');
  let decoded = path;
  for (let i = 0; i < 5; i++) {
    if (!decoded.startsWith('/') || decoded.startsWith('//') || /[\\?#\x00-\x1f]/.test(decoded) || decoded.split('/').some(s => s === '.' || s === '..')) {
      throw new Error('Use a tenant-relative path without query strings, fragments, traversal, or external URLs. Pass query parameters separately.');
    }
    const next = decodeURIComponent(decoded);
    if (next === decoded) return;
    decoded = next;
  }
  throw new Error('Excessively encoded path');
}

export function restIsRead(method: string, path: string): boolean {
  return method === 'GET' || method === 'HEAD' || (method === 'POST' && path === '/asset/v1/content/assets/query');
}
