#!/usr/bin/env node
import { resolve } from 'node:path';
import { PlanStore } from './plans.js';
const id = process.argv[2];
if (!id || process.argv[3] !== '--approve') {
  console.error('Only after explicit user approval: node dist/advanced/approve.js PLAN_ID --approve');
  process.exit(1);
}
try {
  const store = new PlanStore(resolve(process.env.SFMC_PLAN_DIRECTORY || '.sfmc-plans'));
  const plan = await store.approve(id);
  console.log(JSON.stringify({ approved: plan.id, tool: plan.tool, digest: plan.digest, expiresAt: new Date(plan.expiresAt).toISOString() }));
} catch { console.error('Unable to approve plan. Check the ID, expiry, and plan directory.'); process.exit(1); }
