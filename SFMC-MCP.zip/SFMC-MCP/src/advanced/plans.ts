import { createHash, randomUUID } from 'node:crypto';
import { mkdir, readFile, writeFile, link, unlink, rename } from 'node:fs/promises';
import { join } from 'node:path';
export interface ChangePlan { id: string; tool: string; arguments: Record<string, unknown>; digest: string; createdAt: number; expiresAt: number; approvedAt?: number }
function digest(plan: Pick<ChangePlan, 'tool' | 'arguments'>): string { return createHash('sha256').update(JSON.stringify([plan.tool, plan.arguments])).digest('hex'); }
export class PlanStore {
  constructor(readonly directory: string) {}
  private path(id: string): string { if (!/^[a-f0-9-]{36}$/.test(id)) throw new Error('Invalid plan ID'); return join(this.directory, `${id}.json`); }
  async prepare(tool: string, args: Record<string, unknown>): Promise<ChangePlan> {
    await mkdir(this.directory, { recursive: true, mode: 0o700 });
    const now = Date.now();
    const plan: ChangePlan = { id: randomUUID(), tool, arguments: args, digest: digest({ tool, arguments: args }), createdAt: now, expiresAt: now + 600000 };
    await writeFile(this.path(plan.id), JSON.stringify(plan), { mode: 0o600, flag: 'wx' });
    return plan;
  }
  async inspect(id: string): Promise<ChangePlan> {
    const plan = JSON.parse(await readFile(this.path(id), 'utf8')) as ChangePlan;
    if (plan.id !== id || plan.digest !== digest(plan)) throw new Error('Change plan integrity check failed');
    if (Date.now() > plan.expiresAt) throw new Error('Change plan expired; prepare a new plan');
    return plan;
  }
  async approve(id: string): Promise<ChangePlan> {
    const plan = await this.inspect(id);
    plan.approvedAt = Date.now();
    const temp = `${this.path(id)}.${randomUUID()}.tmp`;
    await writeFile(temp, JSON.stringify(plan), { mode: 0o600, flag: 'wx' });
    await rename(temp, this.path(id));
    return plan;
  }
  async consume(id: string): Promise<ChangePlan> {
    const plan = await this.inspect(id);
    if (!plan.approvedAt) throw new Error('Explicit human approval is required; approve this exact plan with the local approval CLI first');
    // Exclusive durable marker makes approval single use, even across server processes.
    await link(this.path(id), `${this.path(id)}.used`);
    await unlink(this.path(id));
    return plan;
  }
}
