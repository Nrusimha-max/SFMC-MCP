#!/usr/bin/env node
/**
 * One-time user authorization for a saved Web App (authorization_code) SFMC account.
 *
 * Run by the SFMC user whose name should appear on changes (they sign in themselves):
 *   node dist/advanced/authorize-user.js "CAN - MIK"
 *
 * Prints the SFMC sign-in URL, receives the redirect on the configured localhost
 * redirect_uri, exchanges the code and stores the refresh token (mode 0600) at the
 * account's refresh_token_path. Tokens are never printed.
 */
import axios from 'axios';
import { randomBytes } from 'node:crypto';
import { createServer } from 'node:http';
import { savedAccounts } from './accounts.js';
import { writeRefreshToken } from '../auth/sfmc-auth.js';

const name = process.argv[2];
const account = savedAccounts().find((a) => a.name === name || a.accountId === name);
if (!account?.refreshTokenPath || !account.redirectUri) {
  console.error('Usage: node dist/advanced/authorize-user.js "<business unit name or MID>"');
  console.error('The account must be saved with grant_type "authorization_code", refresh_token_path and redirect_uri.');
  process.exit(1);
}
const redirect = new URL(account.redirectUri);
if (redirect.protocol !== 'http:' || !['localhost', '127.0.0.1'].includes(redirect.hostname)) {
  console.error('redirect_uri must be an http://localhost (or 127.0.0.1) URL so the code can be received locally.');
  process.exit(1);
}

const authBase = `https://${account.subdomain}.auth.marketingcloudapis.com`;
const state = randomBytes(16).toString('hex');
const authorizeUrl = new URL(`${authBase}/v2/authorize`);
authorizeUrl.search = new URLSearchParams({
  response_type: 'code',
  client_id: account.clientId,
  redirect_uri: account.redirectUri,
  state,
  ...(account.accountId ? { account_id: account.accountId } : {})
}).toString();

const timeout = setTimeout(() => {
  console.error('Timed out after 10 minutes waiting for the SFMC sign-in redirect.');
  process.exit(1);
}, 10 * 60_000);

const server = createServer(async (req, res) => {
  const url = new URL(req.url ?? '/', account.redirectUri);
  if (url.pathname !== redirect.pathname) {
    res.writeHead(404).end();
    return;
  }
  const finish = (status: number, message: string, exitCode: number) => {
    res.writeHead(status, { 'Content-Type': 'text/plain; charset=utf-8' }).end(message);
    console.log(message);
    clearTimeout(timeout);
    server.close(() => process.exit(exitCode));
  };
  if (url.searchParams.get('state') !== state) return finish(400, 'Authorization rejected: state mismatch.', 1);
  const code = url.searchParams.get('code');
  if (!code) return finish(400, `Authorization failed: ${url.searchParams.get('error') ?? 'no code returned'}.`, 1);
  try {
    const { data } = await axios.post<{ refresh_token?: string }>(
      `${authBase}/v2/token`,
      {
        grant_type: 'authorization_code',
        code,
        client_id: account.clientId,
        client_secret: account.clientSecret,
        redirect_uri: account.redirectUri
      },
      { headers: { 'Content-Type': 'application/json' }, timeout: 15_000 }
    );
    if (!data.refresh_token) return finish(502, 'Authorization failed: SFMC returned no refresh token.', 1);
    writeRefreshToken(account.refreshTokenPath!, data.refresh_token);
    finish(200, `Authorized "${account.name}". Refresh token saved to ${account.refreshTokenPath}. You can close this tab.`, 0);
  } catch (err) {
    const ax = err as { response?: { status?: number; data?: { error_description?: string; error?: string } } };
    finish(502, `Authorization failed: ${ax.response?.data?.error_description ?? ax.response?.data?.error ?? 'token exchange error'}.`, 1);
  }
});

server.listen(Number(redirect.port || 80), redirect.hostname, () => {
  console.log(`Sign in to SFMC as the user who should appear on changes, then approve access:\n\n${authorizeUrl}\n`);
  console.log(`Waiting for the redirect on ${account.redirectUri} ...`);
});
