import { readFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';

export interface SavedAccount { name: string; subdomain: string; clientId: string; clientSecret: string; accountId: string; refreshTokenPath?: string; redirectUri?: string }
export function savedAccountsPath(): string {
  return process.env.SFMC_CONFIG_PATH || join(process.env.XDG_CONFIG_HOME || join(homedir(), '.config'), 'sfmc', 'accounts.json');
}
export function savedAccounts(): SavedAccount[] {
  const path = savedAccountsPath();
  const parsed: unknown = JSON.parse(readFileSync(path, 'utf8'));
  if (!Array.isArray(parsed) || !parsed.length) throw new Error('Saved SFMC accounts configuration is empty or invalid');
  return parsed.map((entry, index) => {
    const a = entry as Record<string, string>;
    const result: SavedAccount = { name: a.business_unit_name || a.businessUnitName || `Account ${index + 1}`, subdomain: a.subdomain, clientId: a.client_id || a.clientId, clientSecret: a.client_secret || a.clientSecret, accountId: String(a.account_id || a.accountId || '') };
    if (!result.clientId || !result.clientSecret || !/^[a-zA-Z0-9-]+$/.test(result.subdomain)) throw new Error('Saved SFMC account has invalid authentication configuration');
    // User-context (Web App) accounts act as the user who authorized them via authorize-user.js.
    if ((a.grant_type || a.grantType) === 'authorization_code') {
      const tokenPath = a.refresh_token_path || a.refreshTokenPath;
      if (!tokenPath) throw new Error(`Saved SFMC account "${result.name}" uses authorization_code but has no refresh_token_path`);
      result.refreshTokenPath = tokenPath.startsWith('~/') ? join(homedir(), tokenPath.slice(2)) : tokenPath;
      result.redirectUri = a.redirect_uri || a.redirectUri;
    }
    return result;
  });
}
