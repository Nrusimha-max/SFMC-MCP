import type { Logger } from '../logger.js';
import {
  CreateCalculatedMeasurementInput,
  CreateDashboardInput,
  CreateWidgetInput,
  DeleteCalculatedMeasurementInput,
  DeleteDashboardInput,
  DeleteWidgetInput,
  ExportDashboardDataInput,
  GetCalculatedMeasurementInput,
  GetDashboardInput,
  GetDataStreamInput,
  GetWidgetInput,
  ListCalculatedMeasurementsInput,
  ListDashboardsInput,
  ListDataStreamsInput,
  ListDimensionsInput,
  ListMeasurementsInput,
  ListReportsInput,
  ListWidgetsInput,
  ListWorkspacesInput,
  RunQueryInput,
  UpdateCalculatedMeasurementInput,
  UpdateWidgetInput,
  GetWorkspaceInput
} from '../schemas/datorama.js';
import { DatoramaClient } from './client.js';

export interface DatoramaToolContext {
  client: DatoramaClient;
  defaultWorkspaceId?: string;
  logger: Logger;
}

function resolveWorkspace(ctx: DatoramaToolContext, override?: string): string {
  const id = override ?? ctx.defaultWorkspaceId;
  if (!id) {
    throw new Error(
      'workspaceId is required (set DATORAMA_WORKSPACE_ID env var or pass workspaceId)'
    );
  }
  return id;
}

function toArray<T>(data: T[] | Record<string, unknown>): T[] {
  return Array.isArray(data) ? data : [];
}

// ─── Workspaces ───────────────────────────────────────────────────────────────

/** datorama_list_workspaces */
export async function listWorkspaces(
  ctx: DatoramaToolContext,
  _input: ListWorkspacesInput
): Promise<unknown> {
  const data = await ctx.client.request<Array<Record<string, unknown>>>({
    method: 'GET',
    path: '/v1/workspaces'
  });
  const items = toArray(data);
  return {
    count: items.length,
    items: items.map((w) => ({
      id: w.id,
      name: w.name,
      accountId: w.accountId,
      accountName: w.accountName,
      timezone: w.timezone,
      currency: w.currency,
      verticalId: w.verticalId,
      colorSchemeId: w.colorSchemeId,
      createdAt: w.createTime,
      updatedAt: w.updateTime,
      createUser: w.createUser,
      updateUser: w.updateUser
    }))
  };
}

/** datorama_get_workspace */
export async function getWorkspace(
  ctx: DatoramaToolContext,
  input: GetWorkspaceInput
): Promise<unknown> {
  const workspaceId = resolveWorkspace(ctx, input.workspaceId);
  const data = await ctx.client.request<Record<string, unknown>>({
    method: 'GET',
    path: `/v1/workspaces/${encodeURIComponent(workspaceId)}`
  });
  return {
    id: data.id,
    name: data.name,
    accountId: data.accountId,
    accountName: data.accountName,
    timezone: data.timezone,
    currency: data.currency,
    verticalId: data.verticalId,
    colorSchemeId: data.colorSchemeId,
    marketingCloudMemberId: data.marketingCloudMemberId,
    createdAt: data.createTime,
    updatedAt: data.updateTime,
    createUser: data.createUser,
    updateUser: data.updateUser,
    raw: data
  };
}

// ─── Measurements & Dimensions ────────────────────────────────────────────────

/** datorama_list_measurements */
export async function listMeasurements(
  ctx: DatoramaToolContext,
  input: ListMeasurementsInput
): Promise<unknown> {
  const workspaceId = resolveWorkspace(ctx, input.workspaceId);
  const data = await ctx.client.request<Record<string, Record<string, unknown>>>({
    method: 'GET',
    path: `/v1/workspaces/${encodeURIComponent(workspaceId)}/measurements`
  });
  let items = Object.entries(data).map(([systemName, v]) => ({
    systemName,
    displayName: v.displayName ?? v.defaultDisplayName,
    defaultDisplayName: v.defaultDisplayName,
    aggType: v.aggType ?? v.defaultAggType,
    precision: v.precision,
    color: v.color,
    isCalculated: v.calc ?? false,
    isTrackable: v.trackable ?? false,
    currencySymbol: v.currencySymbol
  }));
  if (input.nameContains) {
    const needle = input.nameContains.toLowerCase();
    items = items.filter(
      (m) =>
        String(m.displayName ?? '').toLowerCase().includes(needle) ||
        String(m.systemName).toLowerCase().includes(needle)
    );
  }
  return { workspaceId, count: items.length, items };
}

/** datorama_list_dimensions */
export async function listDimensions(
  ctx: DatoramaToolContext,
  input: ListDimensionsInput
): Promise<unknown> {
  const workspaceId = resolveWorkspace(ctx, input.workspaceId);
  const data = await ctx.client.request<Record<string, Record<string, unknown>>>({
    method: 'GET',
    path: `/v1/workspaces/${encodeURIComponent(workspaceId)}/dimensions`
  });
  let items = Object.entries(data).map(([systemName, v]) => ({
    systemName,
    displayName: v.displayName ?? v.defaultDisplayName,
    defaultDisplayName: v.defaultDisplayName,
    filterable: v.filterable,
    groupFilterable: v.groupFilterable,
    scope: v.scope,
    maxLength: v.maxLength,
    propertyName: v.propertyName,
    slowlyChangingType: v.slowlyChangingType
  }));
  if (input.nameContains) {
    const needle = input.nameContains.toLowerCase();
    items = items.filter(
      (d) =>
        String(d.displayName ?? '').toLowerCase().includes(needle) ||
        String(d.systemName).toLowerCase().includes(needle)
    );
  }
  return { workspaceId, count: items.length, items };
}

// ─── Calculated Measurements ──────────────────────────────────────────────────

/** datorama_list_calculated_measurements */
export async function listCalculatedMeasurements(
  ctx: DatoramaToolContext,
  input: ListCalculatedMeasurementsInput
): Promise<unknown> {
  const workspaceId = resolveWorkspace(ctx, input.workspaceId);
  const data = await ctx.client.request<Array<Record<string, unknown>>>({
    method: 'GET',
    path: `/v1/workspaces/${encodeURIComponent(workspaceId)}/calculated-measurements`
  });
  const items = toArray(data);
  return {
    workspaceId,
    count: items.length,
    items: items.map((m) => ({
      id: m.id,
      name: m.displayName ?? m.defaultDisplayName ?? m.name,
      expression: m.expression,
      description: m.description ?? m.descr,
      format: m.format,
      precision: m.precision,
      createdAt: m.createTime,
      updatedAt: m.updateTime,
      createUser: m.createUser,
      updateUser: m.updateUser
    }))
  };
}

/** datorama_get_calculated_measurement */
export async function getCalculatedMeasurement(
  ctx: DatoramaToolContext,
  input: GetCalculatedMeasurementInput
): Promise<unknown> {
  const workspaceId = resolveWorkspace(ctx, input.workspaceId);
  // The individual GET /{id} path returns HTML; fetch the list and filter
  const data = await ctx.client.request<Array<Record<string, unknown>>>({
    method: 'GET',
    path: `/v1/workspaces/${encodeURIComponent(workspaceId)}/calculated-measurements`
  });
  const items = toArray(data);
  const found = items.find((m) => String(m.id) === String(input.measurementId));
  if (!found) {
    throw new Error(
      `Calculated measurement ${input.measurementId} not found in workspace ${workspaceId}`
    );
  }
  return {
    workspaceId,
    id: found.id,
    name: found.displayName ?? found.defaultDisplayName ?? found.name,
    expression: found.expression,
    description: found.description ?? found.descr,
    format: found.format,
    precision: found.precision,
    createdAt: found.createTime,
    updatedAt: found.updateTime,
    createUser: found.createUser,
    updateUser: found.updateUser,
    raw: found
  };
}

/** datorama_create_calculated_measurement */
export async function createCalculatedMeasurement(
  ctx: DatoramaToolContext,
  input: CreateCalculatedMeasurementInput
): Promise<unknown> {
  const workspaceId = resolveWorkspace(ctx, input.workspaceId);
  const body: Record<string, unknown> = {
    displayName: input.name,
    expression: input.expression
  };
  if (input.description !== undefined) body.description = input.description;
  if (input.format !== undefined) body.format = input.format;
  if (input.precision !== undefined) body.precision = input.precision;

  const data = await ctx.client.request<Record<string, unknown>>({
    method: 'POST',
    path: `/v1/workspaces/${encodeURIComponent(workspaceId)}/calculated-measurements`,
    body
  });
  return {
    workspaceId,
    id: data.id,
    name: data.displayName ?? data.defaultDisplayName ?? input.name,
    expression: data.expression ?? input.expression,
    description: data.description ?? data.descr,
    status: 'created'
  };
}

/** datorama_update_calculated_measurement */
export async function updateCalculatedMeasurement(
  ctx: DatoramaToolContext,
  input: UpdateCalculatedMeasurementInput
): Promise<unknown> {
  const workspaceId = resolveWorkspace(ctx, input.workspaceId);
  const body: Record<string, unknown> = { id: Number(input.measurementId) };
  if (input.name !== undefined) body.displayName = input.name;
  if (input.expression !== undefined) body.expression = input.expression;
  if (input.description !== undefined) body.description = input.description;
  if (input.format !== undefined) body.format = input.format;
  if (input.precision !== undefined) body.precision = input.precision;

  const data = await ctx.client.request<Record<string, unknown>>({
    method: 'PUT',
    path: `/v1/workspaces/${encodeURIComponent(workspaceId)}/calculated-measurements/${encodeURIComponent(input.measurementId)}`,
    body
  });
  return {
    workspaceId,
    id: input.measurementId,
    name: data.displayName ?? data.defaultDisplayName ?? input.name,
    expression: data.expression ?? input.expression,
    status: 'updated'
  };
}

/** datorama_delete_calculated_measurement */
export async function deleteCalculatedMeasurement(
  ctx: DatoramaToolContext,
  input: DeleteCalculatedMeasurementInput
): Promise<unknown> {
  const workspaceId = resolveWorkspace(ctx, input.workspaceId);
  await ctx.client.request<unknown>({
    method: 'DELETE',
    path: `/v1/workspaces/${encodeURIComponent(workspaceId)}/calculated-measurements/${encodeURIComponent(input.measurementId)}`
  });
  return {
    workspaceId,
    id: input.measurementId,
    status: 'deleted'
  };
}

// ─── Dashboards ───────────────────────────────────────────────────────────────

/** datorama_list_dashboards */
export async function listDashboards(
  ctx: DatoramaToolContext,
  input: ListDashboardsInput
): Promise<unknown> {
  const workspaceId = resolveWorkspace(ctx, input.workspaceId);
  const data = await ctx.client.request<Array<Record<string, unknown>>>({
    method: 'GET',
    path: `/v1/workspaces/${encodeURIComponent(workspaceId)}/dashboards`
  });
  let items = toArray(data);
  if (input.ownerEmail) {
    const email = input.ownerEmail.toLowerCase();
    items = items.filter(
      (d) =>
        String(d.ownerEmail ?? d.owner ?? '').toLowerCase() === email ||
        String(d.createUser ?? '').toLowerCase().includes(email)
    );
  }
  if (input.nameContains) {
    const needle = input.nameContains.toLowerCase();
    items = items.filter((d) => String(d.name ?? '').toLowerCase().includes(needle));
  }
  const page = items.slice(input.offset ?? 0, (input.offset ?? 0) + (input.limit ?? 100));
  return {
    workspaceId,
    totalCount: items.length,
    items: page.map((d) => ({
      id: d.id,
      name: d.name,
      description: d.description,
      uiTheme: d.uiTheme,
      ordinal: d.ordinal,
      isPromoted: d.promoted ?? d.promotedDest,
      createUser: d.createUser,
      updateUser: d.updateUser,
      createdAt: d.createTime,
      updatedAt: d.updateTime
    }))
  };
}

/** datorama_get_dashboard */
export async function getDashboard(
  ctx: DatoramaToolContext,
  input: GetDashboardInput
): Promise<unknown> {
  const data = await ctx.client.request<Record<string, unknown>>({
    method: 'GET',
    path: `/v1/dashboards/${encodeURIComponent(input.dashboardId)}`
  });
  return {
    id: data.id,
    name: data.name,
    description: data.description,
    uiTheme: data.uiTheme,
    dashboardThemeId: data.dashboardThemeId,
    ordinal: data.ordinal,
    originalId: data.originalId,
    createUser: data.createUser,
    updateUser: data.updateUser,
    createdAt: data.createTime,
    updatedAt: data.updateTime,
    raw: data
  };
}

/** datorama_create_dashboard */
export async function createDashboard(
  ctx: DatoramaToolContext,
  input: CreateDashboardInput
): Promise<unknown> {
  const workspaceId = resolveWorkspace(ctx, input.workspaceId);
  // Datorama rejects an empty/null jsonConfig ("jsonConfig must not be null").
  // Use a caller-supplied config, else generate a minimal valid one-page config.
  let cfg: unknown = (input as any).jsonConfig;
  if (cfg === undefined || cfg === null || cfg === '' || cfg === '{}') {
    cfg = { version: 1, pages: [{ id: 'page-1', name: (input as any).pageName ?? 'Page 1', ordinal: 0, widgets: [] }] };
  }
  const jsonConfig = typeof cfg === 'string' ? cfg : JSON.stringify(cfg);
  const body: Record<string, unknown> = {
    name: input.name,
    workspaceId: Number(workspaceId),
    uiTheme: input.uiTheme ?? 'WHITE_THEME',
    jsonConfig
  };
  if (input.description !== undefined) body.description = input.description;

  const data = await ctx.client.request<Record<string, unknown>>({
    method: 'POST',
    path: '/v1/dashboards',
    body
  });
  return {
    workspaceId,
    id: data.id,
    name: data.name ?? input.name,
    description: data.description,
    uiTheme: data.uiTheme,
    status: 'created'
  };
}

/** datorama_delete_dashboard */
export async function deleteDashboard(
  ctx: DatoramaToolContext,
  input: DeleteDashboardInput
): Promise<unknown> {
  await ctx.client.request<unknown>({
    method: 'DELETE',
    path: `/v1/dashboards/${encodeURIComponent(input.dashboardId)}`
  });
  return {
    id: input.dashboardId,
    status: 'deleted'
  };
}

// ─── Data Streams ─────────────────────────────────────────────────────────────

/** datorama_list_data_streams */
export async function listDataStreams(
  ctx: DatoramaToolContext,
  input: ListDataStreamsInput
): Promise<unknown> {
  const workspaceId = resolveWorkspace(ctx, input.workspaceId);
  const data = await ctx.client.request<Array<Record<string, unknown>>>({
    method: 'GET',
    path: `/v1/workspaces/${encodeURIComponent(workspaceId)}/data-streams`,
    query: {
      status: input.status === 'ALL' ? undefined : input.status,
      limit: input.limit,
      offset: input.offset
    }
  });
  const items = toArray(data);
  return {
    workspaceId,
    totalCount: items.length,
    items: items.map((s) => ({
      id: s.id,
      name: s.name,
      status: s.status,
      dataSourceId: s.dataSourceId,
      dataSourceName: s.dataSourceName,
      channelId: s.channelId,
      channelName: s.channelName,
      lastIngestionTime: s.lastIngestionTime ?? s.lastRunTime,
      nextRunTime: s.nextRunTime,
      owner: s.ownerEmail ?? s.owner,
      createdAt: s.createTime,
      updatedAt: s.updateTime,
      createUser: s.createUser,
      updateUser: s.updateUser
    }))
  };
}

/** datorama_get_data_stream */
export async function getDataStream(
  ctx: DatoramaToolContext,
  input: GetDataStreamInput
): Promise<unknown> {
  const workspaceId = resolveWorkspace(ctx, input.workspaceId);
  const data = await ctx.client.request<Record<string, unknown>>({
    method: 'GET',
    path: `/v1/workspaces/${encodeURIComponent(workspaceId)}/data-streams/${encodeURIComponent(input.dataStreamId)}`
  });
  return {
    workspaceId,
    id: data.id,
    name: data.name,
    status: data.status,
    dataSourceId: data.dataSourceId,
    dataSourceName: data.dataSourceName,
    channelId: data.channelId,
    channelName: data.channelName,
    parentInstanceId: data.parentInstanceId,
    lastIngestionTime: data.lastIngestionTime ?? data.lastRunTime,
    nextRunTime: data.nextRunTime,
    scheduleType: data.scheduleType,
    owner: data.ownerEmail ?? data.owner,
    createdAt: data.createTime,
    updatedAt: data.updateTime,
    createUser: data.createUser,
    updateUser: data.updateUser,
    raw: data
  };
}

// ─── Reports ──────────────────────────────────────────────────────────────────

/** datorama_list_reports */
export async function listReports(
  ctx: DatoramaToolContext,
  input: ListReportsInput
): Promise<unknown> {
  const workspaceId = resolveWorkspace(ctx, input.workspaceId);
  const data = await ctx.client.request<
    Array<Record<string, unknown>> | { total?: number; reportDtos?: Array<Record<string, unknown>> }
  >({
    method: 'POST',
    path: `/v1/workspaces/${encodeURIComponent(workspaceId)}/reports`,
    body: { limit: input.limit, offset: input.offset }
  });
  const reports = Array.isArray(data)
    ? data
    : ((data as { reportDtos?: Array<Record<string, unknown>> }).reportDtos ?? []);
  const total = Array.isArray(data)
    ? data.length
    : ((data as { total?: number }).total ?? reports.length);
  return {
    workspaceId,
    total,
    items: reports.map((r) => ({
      id: r.id,
      name: r.name,
      description: r.description,
      dashboardId: r.dashboardId,
      scheduleType: r.scheduleType,
      recipients: r.recipients,
      createdAt: r.createTime,
      updatedAt: r.updateTime,
      createUser: r.createUser,
      updateUser: r.updateUser
    }))
  };
}

// ─── Analytics Query ──────────────────────────────────────────────────────────

/** datorama_run_query */
export async function runQuery(
  ctx: DatoramaToolContext,
  input: RunQueryInput
): Promise<unknown> {
  const workspaceId = resolveWorkspace(ctx, input.workspaceId);
  const body = {
    measurements: input.measurements,
    dimensions: input.dimensions,
    dateRange: input.dateRange,
    filters: input.filters,
    orderBy: input.orderBy,
    limit: input.limit,
    offset: input.offset
  };
  const data = await ctx.client.request<{
    rows?: Array<Record<string, unknown>>;
    columns?: Array<Record<string, unknown>>;
    totalRows?: number;
    headers?: Array<Record<string, unknown>>;
    data?: Array<Array<unknown>>;
  }>({
    method: 'POST',
    path: `/v2/query/sources/workspace/${encodeURIComponent(workspaceId)}`,
    body
  });
  return {
    workspaceId,
    totalRows: data.totalRows ?? data.rows?.length ?? 0,
    columns: data.columns ?? data.headers ?? [],
    rows: data.rows ?? data.data ?? []
  };
}

// ─── Export ───────────────────────────────────────────────────────────────────

/** datorama_export_dashboard_data */
export async function exportDashboardData(
  ctx: DatoramaToolContext,
  input: ExportDashboardDataInput
): Promise<unknown> {
  const workspaceId = resolveWorkspace(ctx, input.workspaceId);
  const data = await ctx.client.request<{
    widgets?: Array<{
      id?: string;
      name?: string;
      type?: string;
      data?: { rows?: unknown[]; columns?: unknown[] };
    }>;
    rows?: unknown[];
  }>({
    method: 'POST',
    path: `/v2/dashboards/workspace/${encodeURIComponent(workspaceId)}/${encodeURIComponent(input.dashboardId)}/export`,
    body: {
      format: input.format,
      dateRange: input.dateRange
    }
  });
  return {
    workspaceId,
    dashboardId: input.dashboardId,
    format: input.format,
    widgets: (data.widgets ?? []).map((w) => ({
      id: w.id,
      name: w.name,
      type: w.type,
      rowCount: w.data?.rows?.length ?? 0,
      columns: w.data?.columns,
      rows: w.data?.rows
    })),
    rows: data.rows
  };
}

// ─── Dashboard Widgets ────────────────────────────────────────────────────────

/** datorama_list_widgets */
export async function listWidgets(
  ctx: DatoramaToolContext,
  input: ListWidgetsInput
): Promise<unknown> {
  const workspaceId = input.workspaceId ?? ctx.defaultWorkspaceId;
  const data = await ctx.client.request<Array<Record<string, unknown>>>({
    method: 'GET',
    path: `/v1/dashboards/${encodeURIComponent(input.dashboardId)}/widgets`
  });
  const items = toArray(data);
  return {
    workspaceId,
    dashboardId: input.dashboardId,
    totalCount: items.length,
    items: items.map((w) => ({
      id: w.id ?? w.widgetId,
      title: w.title,
      type: w.type,
      measurements: w.measurements,
      dimensions: w.dimensions
    }))
  };
}

/** datorama_get_widget */
export async function getWidget(
  ctx: DatoramaToolContext,
  input: GetWidgetInput
): Promise<unknown> {
  const workspaceId = input.workspaceId ?? ctx.defaultWorkspaceId;
  const data = await ctx.client.request<Record<string, unknown>>({
    method: 'GET',
    path: `/v1/dashboards/${encodeURIComponent(input.dashboardId)}/widgets/${encodeURIComponent(input.widgetId)}`
  });
  return {
    workspaceId,
    dashboardId: input.dashboardId,
    id: data.id ?? data.widgetId ?? input.widgetId,
    title: data.title,
    type: data.type,
    measurements: data.measurements,
    dimensions: data.dimensions,
    dateRange: data.dateRange,
    raw: data
  };
}

/** datorama_create_widget */
export async function createWidget(
  ctx: DatoramaToolContext,
  input: CreateWidgetInput
): Promise<unknown> {
  const workspaceId = input.workspaceId ?? ctx.defaultWorkspaceId;
  const body: Record<string, unknown> = {
    type: input.widgetType,
    title: input.title
  };
  if (input.measurements !== undefined) body.measurements = input.measurements;
  if (input.dimensions !== undefined) body.dimensions = input.dimensions;
  if (input.dateRange !== undefined) body.dateRange = input.dateRange;
  // Custom widget code panes (HTML/CSS/JS)
  const custom = (input as any).custom;
  if (custom) {
    if (custom.html !== undefined) body.html = custom.html;
    if (custom.css !== undefined) body.css = custom.css;
    if (custom.javascript !== undefined) body.javascript = custom.javascript;
  }
  // Raw passthrough — merged last so callers can supply the exact Datorama payload
  const rawCfg = (input as any).config;
  if (rawCfg && typeof rawCfg === 'object') Object.assign(body, rawCfg);
  const data = await ctx.client.request<Record<string, unknown>>({
    method: 'POST',
    path: `/v1/dashboards/${encodeURIComponent(input.dashboardId)}/widgets`,
    body
  });
  return {
    workspaceId,
    dashboardId: input.dashboardId,
    id: data.id ?? data.widgetId,
    title: data.title ?? input.title,
    type: data.type ?? input.widgetType,
    measurements: data.measurements ?? input.measurements,
    dimensions: data.dimensions ?? input.dimensions,
    status: 'created'
  };
}

/** datorama_update_widget */
export async function updateWidget(
  ctx: DatoramaToolContext,
  input: UpdateWidgetInput
): Promise<unknown> {
  const workspaceId = input.workspaceId ?? ctx.defaultWorkspaceId;
  const body: Record<string, unknown> = {};
  if (input.title !== undefined) body.title = input.title;
  if (input.measurements !== undefined) body.measurements = input.measurements;
  if (input.dimensions !== undefined) body.dimensions = input.dimensions;
  if (input.dateRange !== undefined) body.dateRange = input.dateRange;
  const data = await ctx.client.request<Record<string, unknown>>({
    method: 'PATCH',
    path: `/v1/dashboards/${encodeURIComponent(input.dashboardId)}/widgets/${encodeURIComponent(input.widgetId)}`,
    body
  });
  return {
    workspaceId,
    dashboardId: input.dashboardId,
    id: input.widgetId,
    title: data.title ?? input.title,
    type: data.type,
    measurements: data.measurements,
    dimensions: data.dimensions,
    status: 'updated'
  };
}

/** datorama_delete_widget */
export async function deleteWidget(
  ctx: DatoramaToolContext,
  input: DeleteWidgetInput
): Promise<unknown> {
  await ctx.client.request<unknown>({
    method: 'DELETE',
    path: `/v1/dashboards/${encodeURIComponent(input.dashboardId)}/widgets/${encodeURIComponent(input.widgetId)}`
  });
  return {
    dashboardId: input.dashboardId,
    id: input.widgetId,
    status: 'deleted'
  };
}
