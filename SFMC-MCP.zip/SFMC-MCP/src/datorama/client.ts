import type { AxiosRequestConfig } from 'axios';
import { DatoramaAuth } from '../auth/datorama-auth.js';
import type { Logger } from '../logger.js';
import { requestWithRetry } from '../utils/retry.js';

export interface DatoramaClientConfig {
  auth: DatoramaAuth;
  logger: Logger;
}

export class DatoramaClient {
  private readonly cfg: DatoramaClientConfig;
  private readonly logger: Logger;

  constructor(cfg: DatoramaClientConfig) {
    this.cfg = cfg;
    this.logger = cfg.logger.child('http');
  }

  async request<T>(opts: {
    method: AxiosRequestConfig['method'];
    path: string;
    query?: Record<string, string | number | boolean | undefined>;
    body?: unknown;
    timeoutMs?: number;
  }): Promise<T> {
    const url = `${this.cfg.auth.baseUrl}${opts.path}`;
    const params = opts.query
      ? Object.fromEntries(
          Object.entries(opts.query).filter(([, v]) => v !== undefined && v !== null)
        )
      : undefined;
    const label = `Datorama ${opts.method ?? 'GET'} ${opts.path}`;

    const res = await requestWithRetry<T>(
      {
        method: opts.method,
        url,
        params,
        data: opts.body,
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        timeout: opts.timeoutMs ?? 60_000
      },
      {
        logger: this.logger,
        label,
        onUnauthorized: () => this.cfg.auth.handleUnauthorized(),
        prepareConfig: async (config) => {
          config.headers = {
            ...(config.headers ?? {}),
            ...(await this.cfg.auth.authHeader())
          };
          return config;
        }
      }
    );
    return res.data;
  }
}
