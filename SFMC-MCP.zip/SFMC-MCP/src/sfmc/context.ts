import type { Logger } from '../logger.js';
import { SfmcClient } from './client.js';

export type BuAlias = string;

export interface SfmcToolContext {
  client: SfmcClient;
  logger: Logger;
  /** Map a BU alias to its account ID override. Returns undefined for the default (Test) BU. */
  resolveAccountId: (bu: BuAlias) => string | undefined;
}
