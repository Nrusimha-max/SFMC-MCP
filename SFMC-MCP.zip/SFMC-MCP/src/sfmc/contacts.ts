import {
  CreateJourneyInput,
  DeleteContactInput,
  GetContactInput,
  GetJourneyActivityInput,
  GetJourneyGraphInput,
  GetJourneyMetricsInput,
  JourneyActionInput,
  UpdateJourneyInput,
  UpsertContactInput
} from '../schemas/sfmc.js';
import type { SfmcToolContext } from './context.js';

// ─── Contact Builder ─────────────────────────────────────────────────────────

/** sfmc_get_contact */
export async function getContact(
  ctx: SfmcToolContext,
  input: GetContactInput
): Promise<unknown> {
  const data = await ctx.client.rest<unknown>({
    method: 'GET',
    path: `/contacts/v2/contacts/key:${encodeURIComponent(input.contactKey)}/attributes`,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return data;
}

/** sfmc_upsert_contact */
export async function upsertContact(
  ctx: SfmcToolContext,
  input: UpsertContactInput
): Promise<unknown> {
  const data = await ctx.client.rest<Record<string, unknown>>({
    method: 'POST',
    path: '/contacts/v2/contacts',
    body: {
      contactKey: input.contactKey,
      attributeSets: input.attributeSets
    },
    accountId: ctx.resolveAccountId(input.bu)
  });
  return {
    contactKey: input.contactKey,
    status: 'OK',
    message: 'Contact upserted.',
    raw: data
  };
}

/** sfmc_delete_contact */
export async function deleteContact(
  ctx: SfmcToolContext,
  input: DeleteContactInput
): Promise<unknown> {
  const data = await ctx.client.rest<Record<string, unknown>>({
    method: 'POST',
    path: '/contacts/v2/contacts/actions/delete',
    body: {
      deleteOperationType: input.deleteType,
      targetList: { listType: { listTypeID: 3 }, idList: [] },
      deleteListWhenCompleted: false,
      contacts: [{ contactKey: input.contactKey }]
    },
    accountId: ctx.resolveAccountId(input.bu)
  });
  return {
    contactKey: input.contactKey,
    status: 'OK',
    message: 'Contact deletion submitted.',
    raw: data
  };
}

/** sfmc_list_contact_attribute_groups */
export async function listContactAttributeGroups(
  ctx: SfmcToolContext
): Promise<unknown> {
  const data = await ctx.client.rest<unknown>({
    method: 'GET',
    path: '/contacts/v2/attributegroups'
  });
  return data;
}

// ─── Journey Builder Extensions ──────────────────────────────────────────────

/** sfmc_create_journey */
export async function createJourney(
  ctx: SfmcToolContext,
  input: CreateJourneyInput
): Promise<unknown> {
  const body: Record<string, unknown> = {
    name: input.name,
    workflowApiVersion: input.workflowApiVersion ?? 1.0
  };
  if (input.key) body.key = input.key;
  if (input.description) body.description = input.description;
  if (input.triggers) body.triggers = input.triggers;
  if (input.goals) body.goals = input.goals;
  if (input.activities) body.activities = input.activities;
  if (input.exits) body.exits = input.exits;

  const data = await ctx.client.rest<Record<string, unknown>>({
    method: 'POST',
    path: '/interaction/v1/interactions',
    body,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return {
    id: data.id,
    key: data.key,
    name: data.name,
    version: data.version,
    status: data.status,
    message: 'Journey created as Draft.'
  };
}

/** sfmc_update_journey */
export async function updateJourney(
  ctx: SfmcToolContext,
  input: UpdateJourneyInput
): Promise<unknown> {
  const existing = await ctx.client.rest<Record<string, unknown>>({
    method: 'GET',
    path: `/interaction/v1/interactions/${encodeURIComponent(input.id)}`,
    query: input.versionNumber ? { versionNumber: input.versionNumber } : undefined,
    accountId: ctx.resolveAccountId(input.bu)
  });

  const body: Record<string, unknown> = { ...existing };
  if (input.name) body.name = input.name;
  if (input.description !== undefined) body.description = input.description;
  if (input.activities) body.activities = input.activities;
  if (input.triggers) body.triggers = input.triggers;
  if (input.goals) body.goals = input.goals;

  const data = await ctx.client.rest<Record<string, unknown>>({
    method: 'PUT',
    path: `/interaction/v1/interactions/${encodeURIComponent(input.id)}`,
    query: input.versionNumber ? { versionNumber: input.versionNumber } : undefined,
    body,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return {
    id: input.id,
    version: data.version,
    status: 'OK',
    message: 'Journey updated.'
  };
}

type JourneyActivity = {
  key?: string;
  name?: string;
  type?: string;
  outcomes?: Array<{ key?: string; next?: string; metaData?: { label?: string } }>;
  [key: string]: unknown;
};

async function fetchJourney(ctx: SfmcToolContext, bu: string, id: string, versionNumber?: number) {
  return ctx.client.rest<{ activities?: JourneyActivity[]; [key: string]: unknown }>({
    method: 'GET',
    path: `/interaction/v1/interactions/${encodeURIComponent(id)}`,
    query: versionNumber ? { versionNumber } : undefined,
    accountId: ctx.resolveAccountId(bu)
  });
}

/** sfmc_get_journey_activity — return one complete activity without truncating the full journey for callers. */
export async function getJourneyActivity(
  ctx: SfmcToolContext,
  input: GetJourneyActivityInput
): Promise<unknown> {
  const journey = await fetchJourney(ctx, input.bu, input.id, input.versionNumber);
  const activity = (journey.activities ?? []).find(candidate => candidate.key === input.activityKey);
  if (!activity) throw new Error(`Activity key not found in journey: ${input.activityKey}`);
  return {
    journey: { id: journey.id, name: journey.name, version: journey.version, status: journey.status },
    activity
  };
}

/** sfmc_get_journey_graph — return a compact, complete node/edge view for safe journey planning. */
export async function getJourneyGraph(
  ctx: SfmcToolContext,
  input: GetJourneyGraphInput
): Promise<unknown> {
  const journey = await fetchJourney(ctx, input.bu, input.id, input.versionNumber);
  const activities = journey.activities ?? [];
  const nodes = activities.map(activity => ({
    key: activity.key,
    name: activity.name,
    type: activity.type,
    outcomes: (activity.outcomes ?? []).map(outcome => ({
      key: outcome.key,
      label: outcome.metaData?.label,
      next: outcome.next ?? null
    }))
  }));
  const typeCounts = nodes.reduce<Record<string, number>>((counts, node) => {
    const type = node.type ?? 'UNKNOWN';
    counts[type] = (counts[type] ?? 0) + 1;
    return counts;
  }, {});
  return {
    journey: { id: journey.id, key: journey.key, name: journey.name, version: journey.version, status: journey.status },
    activityCount: nodes.length,
    typeCounts,
    nodes
  };
}

/** sfmc_journey_action — publish, stop, pause, or resume a journey. */
export async function journeyAction(
  ctx: SfmcToolContext,
  input: JourneyActionInput
): Promise<unknown> {
  const query = input.versionNumber ? { versionNumber: input.versionNumber } : undefined;
  const actionPath =
    input.action === 'publish'
      ? `/interaction/v1/interactions/publishAsync/${encodeURIComponent(input.id)}`
      : `/interaction/v1/interactions/${input.action}/${encodeURIComponent(input.id)}`;

  const data = await ctx.client.rest<Record<string, unknown>>({
    method: 'POST',
    path: actionPath,
    query,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return {
    id: input.id,
    action: input.action,
    status: 'OK',
    message: `Journey ${input.action} submitted.`,
    raw: data
  };
}

/** sfmc_get_journey_metrics — fetch performance metrics (population counts, goal rates) for a journey. */
export async function getJourneyMetrics(
  ctx: SfmcToolContext,
  input: GetJourneyMetricsInput
): Promise<unknown> {
  const query: Record<string, string | number | boolean | undefined> = {};
  if (input.versionNumber !== undefined) query.versionNumber = input.versionNumber;
  const data = await ctx.client.rest<unknown>({
    method: 'GET',
    path: `/interaction/v1/interactions/${encodeURIComponent(input.id)}/metrics`,
    query,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return data;
}
