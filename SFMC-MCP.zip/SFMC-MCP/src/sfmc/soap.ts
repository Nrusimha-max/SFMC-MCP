/**
 * Tiny SOAP envelope builder + response parser for SFMC.
 *
 * We deliberately avoid pulling in a heavy SOAP library — the only operation
 * we issue is `Retrieve`, and the response shape is well-known. A few regex /
 * string-based helpers are enough and keep the dependency tree small.
 */

export interface SimpleFilter {
  property: string;
  simpleOperator: string;
  value?: string | number | Array<string | number>;
  /** Use for date-typed fields — SFMC SOAP requires <DateValue> not <Value>. */
  dateValue?: string[];
}

const XML_ESCAPE: Record<string, string> = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&apos;'
};

function escapeXml(input: string): string {
  return input.replace(/[&<>"']/g, (c) => XML_ESCAPE[c] ?? c);
}

function escapeValue(v: string | number): string {
  return escapeXml(String(v));
}

function buildFilter(filter: SimpleFilter): string {
  const op = escapeXml(filter.simpleOperator);
  const prop = escapeXml(filter.property);
  let values = '';
  if (filter.dateValue?.length) {
    values = filter.dateValue.map((v) => `<DateValue>${escapeValue(v)}</DateValue>`).join('');
  } else if (Array.isArray(filter.value)) {
    values = filter.value.map((v) => `<Value>${escapeValue(v)}</Value>`).join('');
  } else if (filter.value !== undefined) {
    values = `<Value>${escapeValue(filter.value)}</Value>`;
  }
  return `<Filter xsi:type="SimpleFilterPart">
    <Property>${prop}</Property>
    <SimpleOperator>${op}</SimpleOperator>
    ${values}
  </Filter>`;
}

/**
 * Build a SOAP Retrieve envelope. Token is sent via the `<fueloauth>` element
 * (legacy) AND the HTTP Authorization header — SFMC accepts either, both
 * works fine.
 */
export function buildRetrieveEnvelope(opts: {
  token: string;
  objectType: string;
  properties: string[];
  filter?: SimpleFilter;
  continueRequestId?: string;
}): string {
  const props = opts.properties
    .map((p) => `<Properties>${escapeXml(p)}</Properties>`)
    .join('');
  const filterXml = opts.filter ? buildFilter(opts.filter) : '';
  const continueXml = opts.continueRequestId
    ? `<ContinueRequest>${escapeXml(opts.continueRequestId)}</ContinueRequest>`
    : '';
  return `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <soapenv:Header>
    <fueloauth xmlns="http://exacttarget.com">${escapeXml(opts.token)}</fueloauth>
  </soapenv:Header>
  <soapenv:Body>
    <RetrieveRequestMsg xmlns="http://exacttarget.com/wsdl/partnerAPI">
      <RetrieveRequest>
        <ObjectType>${escapeXml(opts.objectType)}</ObjectType>
        ${props}
        ${filterXml}
        ${continueXml}
      </RetrieveRequest>
    </RetrieveRequestMsg>
  </soapenv:Body>
</soapenv:Envelope>`;
}

export interface RetrieveResponse {
  overallStatus: string;
  requestId?: string;
  moreResults: boolean;
  results: Array<Record<string, string>>;
}

/**
 * Parse a SOAP Retrieve response. We do this by hand to avoid an XML
 * dependency: SFMC's response shape is stable and only uses a small subset
 * of XML features.
 */
export function parseRetrieveResponse(xml: string): RetrieveResponse {
  const overallStatus = extractTag(xml, 'OverallStatus') ?? 'Unknown';
  const requestId = extractTag(xml, 'RequestID');
  const overallStatusMessage = extractTag(xml, 'OverallStatusMessage');
  if (overallStatus !== 'OK' && overallStatus !== 'MoreDataAvailable') {
    throw new Error(
      `SOAP Retrieve failed: ${overallStatus}${overallStatusMessage ? ` — ${overallStatusMessage}` : ''}`
    );
  }
  const results = extractAllTags(xml, 'Results').map(parseResultBlock);
  return {
    overallStatus,
    requestId,
    moreResults: overallStatus === 'MoreDataAvailable',
    results
  };
}

function extractTag(xml: string, tag: string): string | undefined {
  const re = new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tag}>`);
  const m = xml.match(re);
  return m ? decodeXml(m[1]) : undefined;
}

function extractAllTags(xml: string, tag: string): string[] {
  const re = new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tag}>`, 'g');
  const out: string[] = [];
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml)) !== null) {
    out.push(m[1]);
  }
  return out;
}

/**
 * Each <Results> block in a Retrieve response contains arbitrary child
 * elements (the requested properties) plus a few SFMC envelope fields.
 * We flatten direct children into a Record<string,string>.
 */
function parseResultBlock(block: string): Record<string, string> {
  const out: Record<string, string> = {};
  // Match top-level <Tag>value</Tag> pairs — value can include nested tags
  // (e.g. CustomerKey under <Properties>); for our use we capture the raw
  // inner text and let the caller decide.
  const re = /<([A-Za-z_][A-Za-z0-9_]*)>([\s\S]*?)<\/\1>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(block)) !== null) {
    const key = m[1];
    const val = m[2];
    // Skip if it has further nested elements — the API rarely returns these
    // at top level for the objects we query.
    if (val.includes('<')) {
      // For DataExtension we get nested <Properties> for fields; collapse
      // into a single string. Callers can re-parse if needed.
      out[key] = val.trim();
      continue;
    }
    out[key] = decodeXml(val);
  }
  return out;
}

function decodeXml(s: string): string {
  return s
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&');
}

// ─── Automation SOAP helpers ─────────────────────────────────────────────────

export interface AutomationActivityResult {
  name?: string;
  objectId?: string;
  customerKey?: string;
  activityType?: string;
  displayOrder?: number;
  isActive?: boolean;
  description?: string;
}

export interface AutomationStepResult {
  name?: string;
  stepNumber?: number;
  activities: AutomationActivityResult[];
}

export interface AutomationSoapResult {
  name?: string;
  customerKey?: string;
  objectId?: string;
  description?: string;
  isActive?: boolean;
  status?: string;
  scheduledTime?: string;
  steps: AutomationStepResult[];
}

/** Parse <Steps> XML from an Automation SOAP result into typed step/activity objects. */
function parseAutomationStepsXml(stepsXml: string): AutomationStepResult[] {
  const stepBlocks = extractAllTags(stepsXml, 'Step');
  return stepBlocks.map((stepBlock) => {
    const stepName = extractTag(stepBlock, 'Name');
    const stepNumberStr = extractTag(stepBlock, 'StepNumber');
    const activitiesXml = extractTag(stepBlock, 'Activities') ?? stepBlock;
    const activityBlocks = extractAllTags(activitiesXml, 'Activity');
    const activities: AutomationActivityResult[] = activityBlocks.map((ab) => {
      const displayOrderStr = extractTag(ab, 'DisplayOrder');
      return {
        name: extractTag(ab, 'Name'),
        objectId: extractTag(ab, 'ObjectID'),
        customerKey: extractTag(ab, 'CustomerKey'),
        activityType: extractTag(ab, 'ActivityType') ?? extractTag(ab, 'ActivityTypeId'),
        displayOrder: displayOrderStr !== undefined ? Number(displayOrderStr) : undefined,
        isActive: extractTag(ab, 'IsActive') === 'true',
        description: extractTag(ab, 'Description')
      };
    });
    return {
      name: stepName,
      stepNumber: stepNumberStr !== undefined ? Number(stepNumberStr) : undefined,
      activities
    };
  });
}

/** Extract automation fields from a block — handles both flat and <Object>-wrapped structures. */
function extractAutomationFields(block: string): AutomationSoapResult {
  // SFMC wraps the actual data in <Object xsi:type="Automation"> inside <Results>.
  // Try the Object wrapper first; fall back to reading directly from the block.
  const objectXml = extractTag(block, 'Object') ?? block;
  const stepsRaw = extractTag(objectXml, 'Steps');
  return {
    name: extractTag(objectXml, 'Name'),
    customerKey: extractTag(objectXml, 'CustomerKey'),
    objectId: extractTag(objectXml, 'ObjectID'),
    description: extractTag(objectXml, 'Description'),
    isActive: extractTag(objectXml, 'IsActive') === 'true',
    status: extractTag(objectXml, 'Status'),
    scheduledTime: extractTag(objectXml, 'ScheduledTime'),
    steps: stepsRaw ? parseAutomationStepsXml(stepsRaw) : []
  };
}

/** Parse all Automation <Results> blocks from a SOAP Retrieve response. */
export function parseAutomationSoapResponse(xml: string): AutomationSoapResult[] {
  const overallStatus = extractTag(xml, 'OverallStatus') ?? 'Unknown';
  if (overallStatus !== 'OK' && overallStatus !== 'MoreDataAvailable') {
    const msg = extractTag(xml, 'OverallStatusMessage');
    throw new Error(`SOAP Retrieve Automation failed: ${overallStatus}${msg ? ` — ${msg}` : ''}`);
  }
  const resultBlocks = extractAllTags(xml, 'Results');
  const automations: AutomationSoapResult[] = [];
  for (const block of resultBlocks) {
    // Skip Results blocks that are error status entries (no actual automation data)
    const statusCode = extractTag(block, 'StatusCode');
    if (statusCode && statusCode.toLowerCase() === 'error') continue;
    const parsed = extractAutomationFields(block);
    // Only include if we got at least a name or objectId — filters out envelope noise
    if (parsed.name || parsed.objectId) {
      automations.push(parsed);
    }
  }
  return automations;
}

/** Return the raw OverallStatus from a SOAP Retrieve XML string (for diagnostics). */
export function getSoapOverallStatus(xml: string): string {
  return extractTag(xml, 'OverallStatus') ?? 'Unknown';
}

// ─── Mutate support (Create / Update / Delete) ──────────────────────────────

export interface DeFieldDef {
  name: string;
  fieldType: string;
  maxLength?: number;
  isPrimaryKey?: boolean;
  isRequired?: boolean;
  defaultValue?: string;
}

export interface SendableConfig {
  deFieldName: string;
  subscriberFieldName: string;
}

export interface RetentionConfig {
  period: number;
  unit: string;
  rowBased: boolean;
  deleteAtEnd: boolean;
  resetOnImport: boolean;
}

export interface MutateResult {
  statusCode: string;
  statusMessage: string;
  objectId?: string;
  customerKey?: string;
}

export interface MutateResponse {
  overallStatus: string;
  requestId?: string;
  results: MutateResult[];
}

function buildMutateEnvelope(
  token: string,
  action: 'Create' | 'Update' | 'Delete',
  objectsXml: string
): string {
  const req = `${action}Request`;
  return `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <soapenv:Header>
    <fueloauth xmlns="http://exacttarget.com">${escapeXml(token)}</fueloauth>
  </soapenv:Header>
  <soapenv:Body>
    <${req} xmlns="http://exacttarget.com/wsdl/partnerAPI">
      ${objectsXml}
    </${req}>
  </soapenv:Body>
</soapenv:Envelope>`;
}

export function parseMutateResponse(xml: string, action: string): MutateResponse {
  const overallStatus = extractTag(xml, 'OverallStatus') ?? 'Unknown';
  const requestId = extractTag(xml, 'RequestID');
  const results = extractAllTags(xml, 'Results').map((block) => ({
    statusCode: extractTag(block, 'StatusCode') ?? 'Unknown',
    statusMessage: extractTag(block, 'StatusMessage') ?? '',
    objectId: extractTag(block, 'ObjectID'),
    customerKey: extractTag(block, 'CustomerKey')
  }));
  if (overallStatus !== 'OK' && overallStatus !== 'HasErrors') {
    const msg = results[0]?.statusMessage || overallStatus;
    throw new Error(`SOAP ${action} failed: ${msg}`);
  }
  return { overallStatus, requestId, results };
}

function buildFieldBody(f: DeFieldDef): string {
  const parts = [
    `<Name>${escapeXml(f.name)}</Name>`,
    `<FieldType>${escapeXml(f.fieldType)}</FieldType>`
  ];
  if (f.maxLength !== undefined) parts.push(`<MaxLength>${f.maxLength}</MaxLength>`);
  if (f.isPrimaryKey) parts.push(`<IsPrimaryKey>true</IsPrimaryKey>`);
  if (f.isRequired) parts.push(`<IsRequired>true</IsRequired>`);
  if (f.defaultValue !== undefined) parts.push(`<DefaultValue>${escapeXml(f.defaultValue)}</DefaultValue>`);
  return parts.join('');
}

/** Build SOAP CreateRequest for a new DataExtension. */
export function buildCreateDeEnvelope(opts: {
  token: string;
  name: string;
  customerKey?: string;
  description?: string;
  categoryId?: number;
  fields: DeFieldDef[];
  sendable?: SendableConfig;
  retention?: RetentionConfig;
}): string {
  const { token, name, customerKey, description, categoryId, fields, sendable, retention } = opts;
  const parts: string[] = [`<Name>${escapeXml(name)}</Name>`];
  if (customerKey) parts.push(`<CustomerKey>${escapeXml(customerKey)}</CustomerKey>`);
  if (description) parts.push(`<Description>${escapeXml(description)}</Description>`);
  if (categoryId !== undefined) parts.push(`<CategoryID>${categoryId}</CategoryID>`);
  if (sendable) {
    parts.push(
      `<IsSendable>true</IsSendable>`,
      `<SendableDataExtensionField><Name>${escapeXml(sendable.deFieldName)}</Name></SendableDataExtensionField>`,
      `<SendableSubscriberField><Name>${escapeXml(sendable.subscriberFieldName)}</Name></SendableSubscriberField>`
    );
  } else {
    parts.push(`<IsSendable>false</IsSendable>`);
  }
  if (retention) {
    parts.push(
      `<DataRetentionPeriodLength>${retention.period}</DataRetentionPeriodLength>`,
      `<DataRetentionPeriodUnit>${escapeXml(retention.unit)}</DataRetentionPeriodUnit>`,
      `<RowBasedRetention>${retention.rowBased ? 'true' : 'false'}</RowBasedRetention>`,
      `<DeleteAtEndOfRetentionPeriod>${retention.deleteAtEnd ? 'true' : 'false'}</DeleteAtEndOfRetentionPeriod>`,
      `<ResetRetentionPeriodOnImport>${retention.resetOnImport ? 'true' : 'false'}</ResetRetentionPeriodOnImport>`
    );
  }
  const fieldsXml = fields.map((f) => `<Field>${buildFieldBody(f)}</Field>`).join('');
  parts.push(`<Fields>${fieldsXml}</Fields>`);
  return buildMutateEnvelope(
    token,
    'Create',
    `<Objects xsi:type="DataExtension">${parts.join('')}</Objects>`
  );
}

/** Build SOAP CreateRequest to add fields to an existing DataExtension. */
export function buildAddDeFieldsEnvelope(opts: {
  token: string;
  deKey: string;
  fields: DeFieldDef[];
}): string {
  const { token, deKey, fields } = opts;
  // SOAP has no Create handler for DataExtensionField; new fields are added by updating the DataExtension.
  const fieldsXml = fields.map((f) => `<Field>${buildFieldBody(f)}</Field>`).join('');
  const objectsXml = `<Objects xsi:type="DataExtension"><CustomerKey>${escapeXml(deKey)}</CustomerKey><Fields>${fieldsXml}</Fields></Objects>`;
  return buildMutateEnvelope(token, 'Update', objectsXml);
}

/** Build SOAP UpdateRequest to modify existing DataExtensionField properties. */
export function buildUpdateDeFieldsEnvelope(opts: {
  token: string;
  deKey: string;
  updates: Array<{
    fieldName: string;
    maxLength?: number;
    defaultValue?: string;
    isRequired?: boolean;
  }>;
}): string {
  const { token, deKey, updates } = opts;
  const objectsXml = updates
    .map((u) => {
      const parts = [
        `<DataExtension><CustomerKey>${escapeXml(deKey)}</CustomerKey></DataExtension>`,
        `<Name>${escapeXml(u.fieldName)}</Name>`
      ];
      if (u.maxLength !== undefined) parts.push(`<MaxLength>${u.maxLength}</MaxLength>`);
      if (u.defaultValue !== undefined) parts.push(`<DefaultValue>${escapeXml(u.defaultValue)}</DefaultValue>`);
      if (u.isRequired !== undefined) parts.push(`<IsRequired>${u.isRequired ? 'true' : 'false'}</IsRequired>`);
      return `<Objects xsi:type="DataExtensionField">${parts.join('')}</Objects>`;
    })
    .join('');
  return buildMutateEnvelope(token, 'Update', objectsXml);
}

/** Build SOAP DeleteRequest to remove fields from a DataExtension. */
export function buildDeleteDeFieldsEnvelope(opts: {
  token: string;
  deKey: string;
  fieldNames: string[];
}): string {
  const { token, deKey, fieldNames } = opts;
  const objectsXml = fieldNames
    .map(
      (n) =>
        `<Objects xsi:type="DataExtensionField"><DataExtension><CustomerKey>${escapeXml(deKey)}</CustomerKey></DataExtension><Name>${escapeXml(n)}</Name></Objects>`
    )
    .join('');
  return buildMutateEnvelope(token, 'Delete', objectsXml);
}

/** Build SOAP UpdateRequest to change DataExtension-level properties (name, folder, sendable, retention). */
export function buildUpdateDeEnvelope(opts: {
  token: string;
  deKey: string;
  name?: string;
  description?: string;
  categoryId?: number;
  sendable?: SendableConfig;
  retention?: RetentionConfig;
}): string {
  const { token, deKey, name, description, categoryId, sendable, retention } = opts;
  const parts = [`<CustomerKey>${escapeXml(deKey)}</CustomerKey>`];
  if (name) parts.push(`<Name>${escapeXml(name)}</Name>`);
  if (description !== undefined) parts.push(`<Description>${escapeXml(description)}</Description>`);
  if (categoryId !== undefined) parts.push(`<CategoryID>${categoryId}</CategoryID>`);
  if (sendable) {
    parts.push(
      `<IsSendable>true</IsSendable>`,
      `<SendableDataExtensionField><Name>${escapeXml(sendable.deFieldName)}</Name></SendableDataExtensionField>`,
      `<SendableSubscriberField><Name>${escapeXml(sendable.subscriberFieldName)}</Name></SendableSubscriberField>`
    );
  }
  if (retention) {
    parts.push(
      `<DataRetentionPeriodLength>${retention.period}</DataRetentionPeriodLength>`,
      `<DataRetentionPeriodUnit>${escapeXml(retention.unit)}</DataRetentionPeriodUnit>`,
      `<RowBasedRetention>${retention.rowBased ? 'true' : 'false'}</RowBasedRetention>`,
      `<DeleteAtEndOfRetentionPeriod>${retention.deleteAtEnd ? 'true' : 'false'}</DeleteAtEndOfRetentionPeriod>`,
      `<ResetRetentionPeriodOnImport>${retention.resetOnImport ? 'true' : 'false'}</ResetRetentionPeriodOnImport>`
    );
  }
  return buildMutateEnvelope(
    token,
    'Update',
    `<Objects xsi:type="DataExtension">${parts.join('')}</Objects>`
  );
}

/** Build SOAP CreateRequest for a new DataFolder. */
export function buildCreateFolderEnvelope(opts: {
  token: string;
  name: string;
  parentCategoryId: number;
  contentType?: string;
}): string {
  const { token, name, parentCategoryId, contentType = 'dataextension' } = opts;
  return buildMutateEnvelope(
    token,
    'Create',
    `<Objects xsi:type="DataFolder"><Name>${escapeXml(name)}</Name><ParentFolder><ID>${parentCategoryId}</ID></ParentFolder><ContentType>${escapeXml(contentType)}</ContentType><IsActive>true</IsActive><IsEditable>true</IsEditable><AllowChildren>true</AllowChildren></Objects>`
  );
}

/** Build SOAP Create/Update for a Subscriber. */
export function buildSubscriberEnvelope(opts: {
  token: string;
  action: 'Create' | 'Update';
  emailAddress: string;
  subscriberKey?: string;
  status?: string;
  lists?: Array<{ id: number; status?: string }>;
  attributes?: Array<{ name: string; value: string }>;
}): string {
  const { token, action, emailAddress, subscriberKey, status, lists, attributes } = opts;
  const parts = [`<EmailAddress>${escapeXml(emailAddress)}</EmailAddress>`];
  if (subscriberKey) parts.push(`<SubscriberKey>${escapeXml(subscriberKey)}</SubscriberKey>`);
  if (status) parts.push(`<Status>${escapeXml(status)}</Status>`);
  if (lists?.length) {
    parts.push(
      ...lists.map(
        (l) =>
          `<Lists><ID>${l.id}</ID>${l.status ? `<Status>${escapeXml(l.status)}</Status>` : ''}</Lists>`
      )
    );
  }
  if (attributes?.length) {
    parts.push(
      ...attributes.map(
        (a) =>
          `<Attributes><Name>${escapeXml(a.name)}</Name><Value>${escapeXml(a.value)}</Value></Attributes>`
      )
    );
  }
  return buildMutateEnvelope(
    token,
    action,
    `<Objects xsi:type="Subscriber">${parts.join('')}</Objects>`
  );
}

/** Build SOAP DeleteRequest for a Subscriber. */
export function buildDeleteSubscriberEnvelope(opts: {
  token: string;
  emailAddress: string;
  subscriberKey?: string;
}): string {
  const { token, emailAddress, subscriberKey } = opts;
  const parts = [`<EmailAddress>${escapeXml(emailAddress)}</EmailAddress>`];
  if (subscriberKey) parts.push(`<SubscriberKey>${escapeXml(subscriberKey)}</SubscriberKey>`);
  return buildMutateEnvelope(
    token,
    'Delete',
    `<Objects xsi:type="Subscriber">${parts.join('')}</Objects>`
  );
}

/** Build SOAP CreateRequest for a List. */
export function buildCreateListEnvelope(opts: {
  token: string;
  listName: string;
  description?: string;
  listClassification?: string;
}): string {
  const { token, listName, description, listClassification = 'ExactTargetList' } = opts;
  const parts = [
    `<ListName>${escapeXml(listName)}</ListName>`,
    `<ListClassification>${escapeXml(listClassification)}</ListClassification>`
  ];
  if (description) parts.push(`<Description>${escapeXml(description)}</Description>`);
  return buildMutateEnvelope(
    token,
    'Create',
    `<Objects xsi:type="List">${parts.join('')}</Objects>`
  );
}

/** Build SOAP Create/Delete for ListSubscriber (subscribe or unsubscribe from a list). */
export function buildListSubscriberEnvelope(opts: {
  token: string;
  action: 'Create' | 'Delete';
  listId: number;
  subscribers: Array<{ emailAddress: string; subscriberKey?: string; status?: string }>;
}): string {
  const { token, action, listId, subscribers } = opts;
  const objectsXml = subscribers
    .map((sub) => {
      const subParts = [
        `<List><ID>${listId}</ID></List>`,
        `<Subscriber><EmailAddress>${escapeXml(sub.emailAddress)}</EmailAddress>${
          sub.subscriberKey
            ? `<SubscriberKey>${escapeXml(sub.subscriberKey)}</SubscriberKey>`
            : ''
        }</Subscriber>`
      ];
      if (sub.status) subParts.push(`<Status>${escapeXml(sub.status)}</Status>`);
      return `<Objects xsi:type="ListSubscriber">${subParts.join('')}</Objects>`;
    })
    .join('');
  return buildMutateEnvelope(token, action, objectsXml);
}

/** Build SOAP Create/Update for an AccountUser. */
export function buildUserEnvelope(opts: {
  token: string;
  action: 'Create' | 'Update';
  id?: number;
  name?: string;
  email?: string;
  password?: string;
  mustChangePassword?: boolean;
  isLocked?: boolean;
  notificationEmailAddress?: string;
  isActive?: boolean;
}): string {
  const {
    token,
    action,
    id,
    name,
    email,
    password,
    mustChangePassword,
    isLocked,
    notificationEmailAddress,
    isActive
  } = opts;
  const parts: string[] = [];
  if (id !== undefined) parts.push(`<ID>${id}</ID>`);
  if (name) parts.push(`<Name>${escapeXml(name)}</Name>`);
  if (email) parts.push(`<Email>${escapeXml(email)}</Email>`);
  if (password) parts.push(`<Password>${escapeXml(password)}</Password>`);
  if (mustChangePassword !== undefined)
    parts.push(`<MustChangePassword>${mustChangePassword ? 'true' : 'false'}</MustChangePassword>`);
  if (isLocked !== undefined) parts.push(`<IsLocked>${isLocked ? 'true' : 'false'}</IsLocked>`);
  if (notificationEmailAddress)
    parts.push(
      `<NotificationEmailAddress>${escapeXml(notificationEmailAddress)}</NotificationEmailAddress>`
    );
  if (isActive !== undefined)
    parts.push(`<ActiveFlag>${isActive ? 'true' : 'false'}</ActiveFlag>`);
  return buildMutateEnvelope(
    token,
    action,
    `<Objects xsi:type="AccountUser">${parts.join('')}</Objects>`
  );
}

/** Build SOAP DeleteRequest to permanently remove a DataExtension. */
export function buildDeleteDeEnvelope(opts: {
  token: string;
  deKey: string;
}): string {
  const { token, deKey } = opts;
  return buildMutateEnvelope(
    token,
    'Delete',
    `<Objects xsi:type="DataExtension"><CustomerKey>${escapeXml(deKey)}</CustomerKey></Objects>`
  );
}

/** Build SOAP UpdateRequest to rename or re-parent a DataFolder. */
export function buildUpdateFolderEnvelope(opts: {
  token: string;
  categoryId: number;
  name?: string;
  parentCategoryId?: number;
}): string {
  const { token, categoryId, name, parentCategoryId } = opts;
  const parts = [`<ID>${categoryId}</ID>`];
  if (name) parts.push(`<Name>${escapeXml(name)}</Name>`);
  if (parentCategoryId !== undefined) parts.push(`<ParentFolder><ID>${parentCategoryId}</ID></ParentFolder>`);
  return buildMutateEnvelope(
    token,
    'Update',
    `<Objects xsi:type="DataFolder">${parts.join('')}</Objects>`
  );
}

// ─── Activity / Perform support ─────────────────────────────────────────────

/** Build SOAP Create/Update for a QueryDefinition (SQL Query Activity). */
export function buildQueryDefinitionEnvelope(opts: {
  token: string;
  action: 'Create' | 'Update';
  objectId?: string;
  customerKey?: string;
  name?: string;
  description?: string;
  queryText?: string;
  targetDeKey?: string;
  targetDeName?: string;
  targetUpdateType?: string;
}): string {
  const { token, action, objectId, customerKey, name, description, queryText, targetDeKey, targetDeName, targetUpdateType } = opts;
  const parts: string[] = [];
  if (objectId) parts.push(`<ObjectID>${escapeXml(objectId)}</ObjectID>`);
  if (customerKey) parts.push(`<CustomerKey>${escapeXml(customerKey)}</CustomerKey>`);
  if (name) parts.push(`<Name>${escapeXml(name)}</Name>`);
  if (description !== undefined) parts.push(`<Description>${escapeXml(description)}</Description>`);
  if (queryText) parts.push(`<QueryText>${escapeXml(queryText)}</QueryText>`);
  if (targetDeKey) {
    parts.push(`<TargetType>DE</TargetType>`);
    const deNameXml = targetDeName ? `<Name>${escapeXml(targetDeName)}</Name>` : '';
    parts.push(`<DataExtensionTarget><CustomerKey>${escapeXml(targetDeKey)}</CustomerKey>${deNameXml}</DataExtensionTarget>`);
  }
  if (targetUpdateType) parts.push(`<TargetUpdateType>${escapeXml(targetUpdateType)}</TargetUpdateType>`);
  return buildMutateEnvelope(token, action, `<Objects xsi:type="QueryDefinition">${parts.join('')}</Objects>`);
}

/** Build SOAP DeleteRequest for a QueryDefinition. */
export function buildDeleteQueryDefinitionEnvelope(opts: {
  token: string;
  objectId?: string;
  customerKey?: string;
}): string {
  const { token, objectId, customerKey } = opts;
  const parts: string[] = [];
  if (objectId) parts.push(`<ObjectID>${escapeXml(objectId)}</ObjectID>`);
  if (customerKey) parts.push(`<CustomerKey>${escapeXml(customerKey)}</CustomerKey>`);
  return buildMutateEnvelope(token, 'Delete', `<Objects xsi:type="QueryDefinition">${parts.join('')}</Objects>`);
}

/** Build SOAP DeleteRequest for an Automation (by ObjectID). */
export function buildDeleteAutomationEnvelope(opts: { token: string; objectId: string }): string {
  return buildMutateEnvelope(
    opts.token,
    'Delete',
    `<Objects xsi:type="Automation"><ObjectID>${escapeXml(opts.objectId)}</ObjectID></Objects>`
  );
}

/** Build a SOAP PerformRequest to start any activity (QueryDefinition, ImportDefinition, etc.). */
export function buildPerformEnvelope(opts: {
  token: string;
  objectType: string;
  objectId?: string;
  customerKey?: string;
  action?: string;
}): string {
  const { token, objectType, objectId, customerKey, action = 'start' } = opts;
  const idXml = objectId ? `<ObjectID>${escapeXml(objectId)}</ObjectID>` : '';
  const keyXml = customerKey ? `<CustomerKey>${escapeXml(customerKey)}</CustomerKey>` : '';
  return `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <soapenv:Header>
    <fueloauth xmlns="http://exacttarget.com">${escapeXml(token)}</fueloauth>
  </soapenv:Header>
  <soapenv:Body>
    <PerformRequestMsg xmlns="http://exacttarget.com/wsdl/partnerAPI">
      <Action>${escapeXml(action)}</Action>
      <Definitions>
        <Definition xsi:type="${escapeXml(objectType)}">${idXml}${keyXml}</Definition>
      </Definitions>
    </PerformRequestMsg>
  </soapenv:Body>
</soapenv:Envelope>`;
}

export interface PerformResponse {
  overallStatus: string;
  requestId?: string;
  statusCode: string;
  statusMessage: string;
  taskId?: string;
}

/** Parse a SOAP PerformResponseMsg. */
export function parsePerformResponse(xml: string): PerformResponse {
  const overallStatus = extractTag(xml, 'OverallStatus') ?? 'Unknown';
  const requestId = extractTag(xml, 'RequestID');
  const resultsBlocks = extractAllTags(xml, 'Result');
  const firstResult = resultsBlocks[0] ?? '';
  const statusCode = extractTag(firstResult, 'StatusCode') ?? overallStatus;
  const statusMessage = extractTag(firstResult, 'StatusMessage') ?? '';
  const taskBlocks = extractAllTags(xml, 'Task');
  const taskId = taskBlocks.length > 0 ? extractTag(taskBlocks[0], 'ID') : undefined;
  if (overallStatus !== 'OK' && overallStatus !== 'MoreDataAvailable') {
    throw new Error(`SOAP Perform failed: ${overallStatus}${statusMessage ? ` — ${statusMessage}` : ''}`);
  }
  return { overallStatus, requestId, statusCode, statusMessage, taskId };
}

/** Build SOAP Create/Update for an SssjsActivity (Script Activity). */
export function buildSssjsActivityEnvelope(opts: {
  token: string;
  action: 'Create' | 'Update';
  objectId?: string;
  customerKey?: string;
  name?: string;
  description?: string;
  script?: string;
}): string {
  const { token, action, objectId, customerKey, name, description, script } = opts;
  const parts: string[] = [];
  if (objectId) parts.push(`<ObjectID>${escapeXml(objectId)}</ObjectID>`);
  if (customerKey) parts.push(`<CustomerKey>${escapeXml(customerKey)}</CustomerKey>`);
  if (name) parts.push(`<Name>${escapeXml(name)}</Name>`);
  if (description !== undefined) parts.push(`<Description>${escapeXml(description)}</Description>`);
  if (script !== undefined) parts.push(`<Script>${escapeXml(script)}</Script>`);
  return buildMutateEnvelope(token, action, `<Objects xsi:type="SssjsActivity">${parts.join('')}</Objects>`);
}

/** Build SOAP Create/Update for a DataExtractActivity. */
export function buildDataExtractActivityEnvelope(opts: {
  token: string;
  action: 'Create' | 'Update';
  objectId?: string;
  customerKey?: string;
  name?: string;
  description?: string;
  extractDefinitionTemplateKey?: string;
  parameters?: Array<{ name: string; value: string }>;
}): string {
  const { token, action, objectId, customerKey, name, description, extractDefinitionTemplateKey, parameters } = opts;
  const parts: string[] = [];
  if (objectId) parts.push(`<ObjectID>${escapeXml(objectId)}</ObjectID>`);
  if (customerKey) parts.push(`<CustomerKey>${escapeXml(customerKey)}</CustomerKey>`);
  if (name) parts.push(`<Name>${escapeXml(name)}</Name>`);
  if (description !== undefined) parts.push(`<Description>${escapeXml(description)}</Description>`);
  if (extractDefinitionTemplateKey)
    parts.push(`<ExtractDefinitionTemplateKey>${escapeXml(extractDefinitionTemplateKey)}</ExtractDefinitionTemplateKey>`);
  if (parameters?.length) {
    parts.push(
      ...parameters.map(
        (p) => `<Parameters><Name>${escapeXml(p.name)}</Name><Value>${escapeXml(p.value)}</Value></Parameters>`
      )
    );
  }
  return buildMutateEnvelope(token, action, `<Objects xsi:type="DataExtractActivity">${parts.join('')}</Objects>`);
}

/** Build SOAP Create/Update for a FileTransferActivity. */
export function buildFileTransferActivityEnvelope(opts: {
  token: string;
  action: 'Create' | 'Update';
  objectId?: string;
  customerKey?: string;
  name?: string;
  description?: string;
  fileSpec?: string;
  fileTransferLocationKey?: string;
  moveCompleted?: boolean;
}): string {
  const { token, action, objectId, customerKey, name, description, fileSpec, fileTransferLocationKey, moveCompleted } = opts;
  const parts: string[] = [];
  if (objectId) parts.push(`<ObjectID>${escapeXml(objectId)}</ObjectID>`);
  if (customerKey) parts.push(`<CustomerKey>${escapeXml(customerKey)}</CustomerKey>`);
  if (name) parts.push(`<Name>${escapeXml(name)}</Name>`);
  if (description !== undefined) parts.push(`<Description>${escapeXml(description)}</Description>`);
  if (fileSpec) parts.push(`<FileSpec>${escapeXml(fileSpec)}</FileSpec>`);
  if (fileTransferLocationKey)
    parts.push(`<FileTransferLocation><CustomerKey>${escapeXml(fileTransferLocationKey)}</CustomerKey></FileTransferLocation>`);
  if (moveCompleted !== undefined) parts.push(`<MoveCompleted>${moveCompleted ? 'true' : 'false'}</MoveCompleted>`);
  return buildMutateEnvelope(token, action, `<Objects xsi:type="FileTransferActivity">${parts.join('')}</Objects>`);
}

/** Build SOAP Create/Update for an ImportDefinition (bulk subscriber/DE import). */
export function buildImportDefinitionEnvelope(opts: {
  token: string;
  action: 'Create' | 'Update';
  objectId?: string;
  customerKey?: string;
  name?: string;
  description?: string;
  targetDeKey?: string;
  fileSpec?: string;
  fileType?: string;
  fieldMappingType?: string;
  updateType?: string;
  maxFileAge?: number;
  ftpLocationKey?: string;
  allowErrors?: boolean;
}): string {
  const {
    token, action, objectId, customerKey, name, description,
    targetDeKey, fileSpec, fileType, fieldMappingType,
    updateType, maxFileAge, ftpLocationKey, allowErrors
  } = opts;
  const parts: string[] = [];
  if (objectId) parts.push(`<ObjectID>${escapeXml(objectId)}</ObjectID>`);
  if (customerKey) parts.push(`<CustomerKey>${escapeXml(customerKey)}</CustomerKey>`);
  if (name) parts.push(`<Name>${escapeXml(name)}</Name>`);
  if (description !== undefined) parts.push(`<Description>${escapeXml(description)}</Description>`);
  if (targetDeKey) parts.push(`<DestinationObject><CustomerKey>${escapeXml(targetDeKey)}</CustomerKey></DestinationObject>`);
  if (fileSpec) parts.push(`<FileSpec>${escapeXml(fileSpec)}</FileSpec>`);
  if (fileType) parts.push(`<FileType>${escapeXml(fileType)}</FileType>`);
  if (fieldMappingType) parts.push(`<FieldMappingType>${escapeXml(fieldMappingType)}</FieldMappingType>`);
  if (updateType) parts.push(`<UpdateType>${escapeXml(updateType)}</UpdateType>`);
  if (maxFileAge !== undefined)
    parts.push(`<MaxFileAge>${maxFileAge}</MaxFileAge><MaxFileAgeScheduleOffset>0</MaxFileAgeScheduleOffset>`);
  const ftpKey = ftpLocationKey ?? (action === 'Create' ? 'ExactTarget Enhanced FTP' : undefined);
  if (ftpKey) parts.push(`<RetrieveFileTransferLocation><CustomerKey>${escapeXml(ftpKey)}</CustomerKey></RetrieveFileTransferLocation>`);
  if (allowErrors !== undefined) parts.push(`<AllowErrors>${allowErrors ? 'true' : 'false'}</AllowErrors>`);
  return buildMutateEnvelope(token, action, `<Objects xsi:type="ImportDefinition">${parts.join('')}</Objects>`);
}

/** Build SOAP Create/Delete for AccountUserRole (assign or revoke a role from a user). */
export function buildAccountUserRoleEnvelope(opts: {
  token: string;
  action: 'Create' | 'Delete';
  userId: number;
  roleId?: number;
  roleName?: string;
}): string {
  const { token, action, userId, roleId, roleName } = opts;
  const rolePart =
    roleId !== undefined
      ? `<Role><ID>${roleId}</ID></Role>`
      : `<Role><Name>${escapeXml(roleName!)}</Name></Role>`;
  return buildMutateEnvelope(
    token,
    action,
    `<Objects xsi:type="AccountUserRole"><AccountUser><ID>${userId}</ID></AccountUser>${rolePart}</Objects>`
  );
}
