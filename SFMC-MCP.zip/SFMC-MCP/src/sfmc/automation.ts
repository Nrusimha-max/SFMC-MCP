import {
  AutomationActionInput,
  CreateAutomationInput,
  DebugSoapAutomationInput,
  DeleteAutomationInput,
  FireAutomationInput,
  GetAutomationHistoryInput,
  GetAutomationInput,
  GetAutomationByNameInput,
  ListAutomationsSoapInput,
  ListAutomationsInput,
  UpdateAutomationInput
} from '../schemas/sfmc.js';
import {
  buildDeleteAutomationEnvelope,
  buildRetrieveEnvelope,
  getSoapOverallStatus,
  parseAutomationSoapResponse,
  parseMutateResponse
} from './soap.js';
import { UpstreamApiError } from '../types.js';
import type { SfmcToolContext } from './context.js';

interface AutomationListResponse {
  count?: number;
  page?: number;
  pageSize?: number;
  items?: Array<Record<string, unknown>>;
}

/** sfmc_list_automations */
export async function listAutomations(
  ctx: SfmcToolContext,
  input: ListAutomationsInput
): Promise<unknown> {
  const data = await ctx.client.rest<AutomationListResponse>({
    method: 'GET',
    path: '/automation/v2/automations',
    query: {
      $page: input.page,
      $pagesize: input.top,
      ...(input.nameContains ? { name: input.nameContains } : {}),
      ...(input.status ? { status: input.status } : {})
    },
    accountId: ctx.resolveAccountId(input.bu)
  });
  return {
    total: data.count ?? (data.items?.length ?? 0),
    page: data.page ?? input.page,
    pageSize: data.pageSize ?? input.top,
    items: (data.items ?? []).map((a) => ({
      id: a.id,
      key: a.key,
      name: a.name,
      description: a.description,
      status: a.status,
      statusId: a.statusId,
      createdDate: a.createdDate,
      modifiedDate: a.modifiedDate,
      schedule: a.schedule
    }))
  };
}

/** sfmc_get_automation */
export async function getAutomation(
  ctx: SfmcToolContext,
  input: GetAutomationInput
): Promise<unknown> {
  const data = await ctx.client.rest<unknown>({
    method: 'GET',
    path: `/automation/v2/automations/${encodeURIComponent(input.id)}`,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return data;
}

/** sfmc_create_automation */
export async function createAutomation(
  ctx: SfmcToolContext,
  input: CreateAutomationInput
): Promise<unknown> {
  const body: Record<string, unknown> = {
    name: input.name,
    description: input.description,
    steps: input.steps
  };
  if (input.key) body.key = input.key;
  if (input.schedule) body.schedule = input.schedule;

  const data = await ctx.client.rest<Record<string, unknown>>({
    method: 'POST',
    path: '/automation/v2/automations',
    body,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return {
    id: data.id,
    key: data.key,
    name: data.name,
    status: data.status,
    message: 'Automation created.'
  };
}

/** sfmc_update_automation */
export async function updateAutomation(
  ctx: SfmcToolContext,
  input: UpdateAutomationInput
): Promise<unknown> {
  const body: Record<string, unknown> = {};
  if (input.name) body.name = input.name;
  if (input.description !== undefined) body.description = input.description;
  if (input.schedule) body.schedule = input.schedule;

  await ctx.client.rest<unknown>({
    method: 'PATCH',
    path: `/automation/v2/automations/${encodeURIComponent(input.id)}`,
    body,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return { id: input.id, status: 'OK', message: 'Automation updated.' };
}

/** sfmc_delete_automation */
export async function deleteAutomation(
  ctx: SfmcToolContext,
  input: DeleteAutomationInput
): Promise<unknown> {
  const accountId = ctx.resolveAccountId(input.bu);
  try {
    await ctx.client.rest<unknown>({
      method: 'DELETE',
      path: `/automation/v2/automations/${encodeURIComponent(input.id)}`,
      accountId
    });
    return { id: input.id, status: 'OK', message: 'Automation deleted.' };
  } catch (err) {
    // Some tenants don't serve automation v2 (596) or reject the route (404); SOAP Delete still works.
    if (!(err instanceof UpstreamApiError) || (err.status !== 596 && err.status !== 404)) throw err;
  }
  const token = await ctx.client.getAccessToken(accountId);
  const xml = await ctx.client.soap({
    soapAction: 'Delete',
    envelope: buildDeleteAutomationEnvelope({ token, objectId: input.id }),
    accountId
  });
  const resp = parseMutateResponse(xml, 'Delete Automation');
  const result = resp.results[0];
  if (!result || result.statusCode !== 'OK') {
    throw new UpstreamApiError({ status: 0, message: `SOAP Delete Automation failed: ${result?.statusMessage || resp.overallStatus}` });
  }
  return { id: input.id, status: 'OK', message: 'Automation deleted (SOAP).' };
}

/** sfmc_automation_action — start or stop an automation. */
export async function automationAction(
  ctx: SfmcToolContext,
  input: AutomationActionInput
): Promise<unknown> {
  const data = await ctx.client.rest<Record<string, unknown>>({
    method: 'POST',
    path: `/automation/v2/automations/${encodeURIComponent(input.id)}/${input.action}`,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return {
    id: input.id,
    action: input.action,
    status: 'OK',
    message: `Automation ${input.action} triggered.`,
    raw: data
  };
}

/**
 * sfmc_fire_automation
 * Trigger an immediate single run of an automation using the actions/start
 * endpoint (separate from the schedule-based start/stop toggle).
 */
export async function fireAutomation(
  ctx: SfmcToolContext,
  input: FireAutomationInput
): Promise<unknown> {
  const data = await ctx.client.rest<Record<string, unknown>>({
    method: 'POST',
    path: `/automation/v2/automations/${encodeURIComponent(input.id)}/actions/start`,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return {
    id: input.id,
    status: 'OK',
    message: 'Automation fired for an immediate run.',
    raw: data
  };
}

/** sfmc_get_automation_history — list past run records for an automation. */
export async function getAutomationHistory(
  ctx: SfmcToolContext,
  input: GetAutomationHistoryInput
): Promise<unknown> {
  const data = await ctx.client.rest<Record<string, unknown>>({
    method: 'GET',
    path: `/automation/v2/automations/${encodeURIComponent(input.id)}/activities`,
    query: { $page: input.page, $pagesize: input.top },
    accountId: ctx.resolveAccountId(input.bu)
  });
  return data;
}

const ACTIVITY_TYPE_LABELS: Record<string, string> = {
  '1': 'Email Send',
  '2': 'SQL Query',
  '3': 'Data Extract',
  '4': 'Import Definition',
  '5': 'File Transfer',
  '6': 'Script (SSJS)',
  '7': 'DE Verification',
  '22': 'Verification',
  '23': 'Filter Activity',
  SENDEMAIL: 'Email Send',
  QUERY: 'SQL Query',
  DATAEXTRACT: 'Data Extract',
  IMPORT: 'Import',
  FILETRANSFER: 'File Transfer',
  SCRIPT: 'Script (SSJS)',
  VERIFICATION: 'Verification',
  FILTER: 'Filter Activity'
};

function formatAutomation(a: ReturnType<typeof parseAutomationSoapResponse>[number], includeSteps: boolean) {
  const base = {
    name: a.name,
    customerKey: a.customerKey,
    objectId: a.objectId,
    description: a.description,
    isActive: a.isActive,
    status: a.status,
    scheduledTime: a.scheduledTime
  };
  if (!includeSteps) return base;
  return {
    ...base,
    steps: a.steps.map((s) => ({
      name: s.name,
      stepNumber: s.stepNumber,
      activities: s.activities.map((act) => ({
        name: act.name,
        objectId: act.objectId,
        customerKey: act.customerKey,
        activityType: act.activityType
          ? (ACTIVITY_TYPE_LABELS[act.activityType] ?? act.activityType)
          : undefined,
        displayOrder: act.displayOrder,
        isActive: act.isActive,
        description: act.description
      }))
    }))
  };
}

async function retrieveAutomationsSoap(
  ctx: SfmcToolContext,
  accountId: string,
  properties: string[]
): Promise<{ soapStatus: string; rawExcerpt: string; results: ReturnType<typeof parseAutomationSoapResponse> }> {
  const token = await ctx.client.resolveAuth(accountId).getAccessToken();

  // Try objectType 'Automation' first; if it returns 0 results with no error, also try 'Program'
  // SFMC SOAP requires a Filter for Automation Retrieve — unfiltered requests
  // fail with "Value cannot be null. Parameter name: WhereValues".
  const automationFilter = { property: 'Name', simpleOperator: 'isNotNull' };
  const makeEnvelope = (objectType: string) =>
    buildRetrieveEnvelope({ token, objectType, properties, filter: automationFilter });

  let xml = await ctx.client.soap({ soapAction: 'Retrieve', envelope: makeEnvelope('Automation'), accountId });
  let soapStatus = getSoapOverallStatus(xml);
  let results = parseAutomationSoapResponse(xml);

  if (results.length === 0 && (soapStatus === 'OK' || soapStatus === 'MoreDataAvailable')) {
    // Fallback: some SFMC accounts surface automations under the legacy 'Program' object type
    try {
      const xml2 = await ctx.client.soap({ soapAction: 'Retrieve', envelope: makeEnvelope('Program'), accountId });
      const status2 = getSoapOverallStatus(xml2);
      const results2 = parseAutomationSoapResponse(xml2);
      if (results2.length > 0) {
        xml = xml2;
        soapStatus = status2;
        results = results2;
      }
    } catch {
      // ignore fallback failure — return original results
    }
  }

  return { soapStatus, rawExcerpt: xml.slice(0, 2000), results };
}

/**
 * sfmc_debug_soap_automation — return raw SOAP XML for Automation Retrieve (first 3000 chars).
 * Use this to diagnose why sfmc_list_automations_soap returns unexpected results.
 */
export async function debugSoapAutomation(
  ctx: SfmcToolContext,
  input: DebugSoapAutomationInput
): Promise<unknown> {
  const accountId = ctx.resolveAccountId(input.bu) ?? '';
  const token = await ctx.client.resolveAuth(accountId).getAccessToken();
  const envelope = buildRetrieveEnvelope({
    token,
    objectType: 'Automation',
    properties: ['Name', 'CustomerKey', 'ObjectID', 'IsActive', 'Status'],
    filter: { property: 'Name', simpleOperator: 'isNotNull' }
  });
  const xml = await ctx.client.soap({ soapAction: 'Retrieve', envelope, accountId });
  return {
    rawSoapResponse: xml.slice(0, 3000),
    totalLength: xml.length
  };
}

/**
 * sfmc_get_automation_soap — fetch a single automation by name via SOAP.
 * Use this when sfmc_get_automation or sfmc_list_automations returns 596.
 * Retrieves ALL automations via SOAP and filters client-side (avoids en-dash
 * and other special-character encoding issues in SOAP server-side filters).
 */
export async function getAutomationByNameSoap(
  ctx: SfmcToolContext,
  input: GetAutomationByNameInput
): Promise<unknown> {
  const accountId = ctx.resolveAccountId(input.bu) ?? '';
  const { soapStatus, rawExcerpt, results } = await retrieveAutomationsSoap(ctx, accountId, [
    'Name', 'CustomerKey', 'ObjectID', 'Description', 'IsActive', 'Status', 'ScheduledTime', 'Steps'
  ]);

  // Client-side name match: exact (case-insensitive), then contains fallback
  const needle = input.name.toLowerCase().trim();
  let match = results.find((a) => (a.name ?? '').toLowerCase().trim() === needle);
  if (!match) {
    match = results.find((a) => (a.name ?? '').toLowerCase().includes(needle));
  }

  if (!match) {
    return {
      found: false,
      soapStatus,
      totalAutomationsRetrieved: results.length,
      message: `No automation matching "${input.name}" found.`,
      availableNames: results.map((a) => a.name).filter(Boolean).slice(0, 30),
      // Include raw SOAP excerpt so the caller can diagnose parse issues
      rawSoapExcerpt: rawExcerpt
    };
  }

  return {
    found: true,
    soapStatus,
    ...formatAutomation(match, true)
  };
}

/**
 * sfmc_list_automations_soap — list automations via SOAP with optional name filter.
 * Use this when sfmc_list_automations returns 596.
 * Always retrieves all automations and filters client-side.
 */
export async function listAutomationsSoap(
  ctx: SfmcToolContext,
  input: ListAutomationsSoapInput
): Promise<unknown> {
  const accountId = ctx.resolveAccountId(input.bu) ?? '';
  const { soapStatus, rawExcerpt, results: allResults } = await retrieveAutomationsSoap(ctx, accountId, [
    'Name', 'CustomerKey', 'ObjectID', 'Description', 'IsActive', 'Status', 'ScheduledTime'
  ]);

  if (allResults.length === 0) {
    return {
      soapStatus,
      count: 0,
      items: [],
      rawSoapExcerpt: rawExcerpt
    };
  }

  let results = allResults;
  if (input.nameContains) {
    const needle = input.nameContains.toLowerCase();
    results = results.filter((a) => (a.name ?? '').toLowerCase().includes(needle));
  }

  return {
    soapStatus,
    count: results.length,
    items: results.map((a) => formatAutomation(a, false))
  };
}
