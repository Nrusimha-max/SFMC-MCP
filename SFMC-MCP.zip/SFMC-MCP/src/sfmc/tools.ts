import { appendFile, mkdir, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';
import {
  AlterDataExtensionInput,
  CreateDataExtensionInput,
  DeleteDataExtensionInput,
  DeleteDeRowsInput,
  ExportDataExtensionInput,
  GetDataExtensionRowsInput,
  GetEmailSendSummaryInput,
  GetJourneyInput,
  ListDataExtensionsInput,
  ListJourneysInput,
  ManageFolderInput,
  QuerySoapInput,
  RenameDataExtensionInput,
  SendTriggeredEmailInput,
  UpsertDataExtensionRowsInput
} from '../schemas/sfmc.js';
import {
  buildAddDeFieldsEnvelope,
  buildCreateDeEnvelope,
  buildCreateFolderEnvelope,
  buildDeleteDeEnvelope,
  buildDeleteDeFieldsEnvelope,
  buildRetrieveEnvelope,
  buildUpdateDeEnvelope,
  buildUpdateDeFieldsEnvelope,
  buildUpdateFolderEnvelope,
  parseMutateResponse,
  parseRetrieveResponse
} from './soap.js';
import type { SfmcToolContext } from './context.js';

/** sfmc_list_data_extensions — uses SOAP DataExtension Retrieve. */
export async function listDataExtensions(
  ctx: SfmcToolContext,
  input: ListDataExtensionsInput
): Promise<unknown> {
  const token = await ctx.client.resolveAuth(ctx.resolveAccountId(input.bu)).getAccessToken();
  // When both filters are present, push categoryId to SOAP and do nameContains in JS.
  const soapFilter =
    input.categoryId !== undefined
      ? { property: 'CategoryID', simpleOperator: 'equals' as const, value: input.categoryId }
      : input.nameContains
        ? { property: 'Name', simpleOperator: 'like' as const, value: input.nameContains }
        : undefined;

  const envelope = buildRetrieveEnvelope({
    token,
    objectType: 'DataExtension',
    properties: [
      'ObjectID',
      'CustomerKey',
      'Name',
      'Description',
      'CreatedDate',
      'ModifiedDate',
      'IsSendable',
      'IsTestable',
      'CategoryID'
    ],
    filter: soapFilter
  });
  const xml = await ctx.client.soap({ soapAction: 'Retrieve', envelope, accountId: ctx.resolveAccountId(input.bu) });
  const parsed = parseRetrieveResponse(xml);

  // If both categoryId and nameContains are set, finish filtering in JS.
  const filtered =
    input.categoryId !== undefined && input.nameContains
      ? parsed.results.filter((r) =>
          String(r.Name ?? '').toLowerCase().includes(input.nameContains!.toLowerCase())
        )
      : parsed.results;

  // Get row counts in a follow-up batched call per DE (best-effort: many DEs
  // can be expensive, so we cap at the first 25 unless the caller asked for
  // fewer). Failures here don't fail the whole tool.
  const window = filtered.slice(input.skip, input.skip + input.top);
  const withCounts = await Promise.all(
    window.slice(0, 25).map(async (de) => {
      const key = de.CustomerKey;
      let rowCount: number | null = null;
      if (key) {
        try {
          const res = await ctx.client.rest<{ count?: number; items?: unknown[] }>({
            method: 'GET',
            path: `/data/v1/customobjectdata/key/${encodeURIComponent(key)}/rowset`,
            query: { $top: 1, $page: 1 },
            accountId: ctx.resolveAccountId(input.bu)
          });
          // SFMC returns `count` only when ?$inlinecount=allpages is used —
          // we retry with that to get the real count.
          if (typeof res.count !== 'number') {
            const counted = await ctx.client.rest<{ count?: number }>({
              method: 'GET',
              path: `/data/v1/customobjectdata/key/${encodeURIComponent(key)}/rowset`,
              query: { $top: 1, $inlinecount: 'allpages' },
              accountId: ctx.resolveAccountId(input.bu)
            });
            rowCount = counted.count ?? null;
          } else {
            rowCount = res.count;
          }
        } catch (err) {
          ctx.logger.debug(`row count failed for DE ${key}`, (err as Error).message);
        }
      }
      return {
        objectId: de.ObjectID,
        customerKey: de.CustomerKey,
        name: de.Name,
        description: de.Description,
        createdDate: de.CreatedDate,
        modifiedDate: de.ModifiedDate,
        isSendable: de.IsSendable === 'true',
        rowCount
      };
    })
  );

  return {
    total: filtered.length,
    returned: withCounts.length,
    moreResults: parsed.moreResults,
    items: withCounts
  };
}

/** sfmc_get_data_extension_rows */
export async function getDataExtensionRows(
  ctx: SfmcToolContext,
  input: GetDataExtensionRowsInput
): Promise<unknown> {
  const data = await ctx.client.rest<{
    count?: number;
    items?: Array<{ keys?: Record<string, unknown>; values?: Record<string, unknown> }>;
  }>({
    method: 'GET',
    path: `/data/v1/customobjectdata/key/${encodeURIComponent(input.key)}/rowset`,
    query: {
      $top: input.top,
      $skip: input.skip,
      $filter: input.filter,
      $orderby: input.orderBy,
      $inlinecount: 'allpages'
    },
    accountId: ctx.resolveAccountId(input.bu)
  });
  return {
    key: input.key,
    total: data.count ?? null,
    returned: data.items?.length ?? 0,
    rows: (data.items ?? []).map((it) => ({ ...(it.keys ?? {}), ...(it.values ?? {}) }))
  };
}

/** sfmc_upsert_data_extension_rows — async REST upsert. */
export async function upsertDataExtensionRows(
  ctx: SfmcToolContext,
  input: UpsertDataExtensionRowsInput
): Promise<unknown> {
  const data = await ctx.client.rest<{ requestId?: string; resultMessages?: unknown[] }>({
    method: 'POST',
    path: `/data/v1/async/dataextensions/key:${encodeURIComponent(input.key)}/rows`,
    body: { items: input.rows },
    accountId: ctx.resolveAccountId(input.bu)
  });
  return {
    key: input.key,
    submittedRows: input.rows.length,
    requestId: data.requestId,
    message:
      'Upsert submitted asynchronously. Poll /data/v2/async/{requestId}/status for completion.',
    raw: data
  };
}

/** sfmc_query_soap — generic SOAP Retrieve. */
export async function querySoap(
  ctx: SfmcToolContext,
  input: QuerySoapInput
): Promise<unknown> {
  const token = await ctx.client.resolveAuth(ctx.resolveAccountId(input.bu)).getAccessToken();
  const collected: Record<string, string>[] = [];
  let continueRequestId: string | undefined;

  while (collected.length < input.maxResults) {
    const envelope = buildRetrieveEnvelope({
      token,
      objectType: input.objectType,
      properties: input.properties,
      filter: input.filter,
      continueRequestId
    });
    const xml = await ctx.client.soap({ soapAction: 'Retrieve', envelope, accountId: ctx.resolveAccountId(input.bu) });
    const parsed = parseRetrieveResponse(xml);
    for (const r of parsed.results) {
      collected.push(r);
      if (collected.length >= input.maxResults) break;
    }
    if (!parsed.moreResults || !parsed.requestId) break;
    continueRequestId = parsed.requestId;
  }

  return {
    objectType: input.objectType,
    returned: collected.length,
    truncated: collected.length >= input.maxResults,
    rows: collected
  };
}

/** sfmc_list_journeys */
export async function listJourneys(
  ctx: SfmcToolContext,
  input: ListJourneysInput
): Promise<unknown> {
  const data = await ctx.client.rest<{
    count?: number;
    items?: Array<Record<string, unknown>>;
  }>({
    method: 'GET',
    path: '/interaction/v1/interactions',
    query: {
      status: input.status,
      $pageSize: input.top,
      $page: Math.floor(input.skip / input.top) + 1
    },
    accountId: ctx.resolveAccountId(input.bu)
  });
  const items = (data.items ?? []).filter((j) => {
    if (!input.nameContains) return true;
    const name = String(j.name ?? '').toLowerCase();
    return name.includes(input.nameContains.toLowerCase());
  });
  return {
    total: data.count ?? items.length,
    returned: items.length,
    items: items.map((j) => ({
      id: j.id,
      key: j.key,
      name: j.name,
      version: j.version,
      status: j.status,
      createdDate: j.createdDate,
      modifiedDate: j.modifiedDate,
      lastPublishedDate: j.lastPublishedDate,
      goals: j.goals,
      definitionId: j.definitionId
    }))
  };
}

/** sfmc_get_journey */
export async function getJourney(
  ctx: SfmcToolContext,
  input: GetJourneyInput
): Promise<unknown> {
  const extras = input.extras?.join(',');
  const data = await ctx.client.rest<unknown>({
    method: 'GET',
    path: `/interaction/v1/interactions/${encodeURIComponent(input.id)}`,
    query: {
      versionNumber: input.versionNumber,
      extras
    },
    accountId: ctx.resolveAccountId(input.bu)
  });
  return data;
}

/** sfmc_send_triggered_email */
export async function sendTriggeredEmail(
  ctx: SfmcToolContext,
  input: SendTriggeredEmailInput
): Promise<unknown> {
  const requestType = input.options?.requestType ?? 'ASYNC';
  // Messaging API expects a single recipient per POST. For >1 we fan out.
  const results = await Promise.all(
    input.subscribers.map(async (sub) => {
      const body = {
        To: {
          Address: sub.EmailAddress,
          SubscriberKey: sub.SubscriberKey,
          ContactAttributes: sub.attributes ? { SubscriberAttributes: sub.attributes } : undefined
        },
        Options: { RequestType: requestType }
      };
      const data = await ctx.client.rest<{ requestId?: string; responses?: unknown[] }>({
        method: 'POST',
        path: `/messaging/v2/messageDefinitionSends/key:${encodeURIComponent(input.externalKey)}/send`,
        body,
        accountId: ctx.resolveAccountId(input.bu)
      });
      return {
        emailAddress: sub.EmailAddress,
        subscriberKey: sub.SubscriberKey,
        requestId: data.requestId,
        responses: data.responses
      };
    })
  );
  return {
    externalKey: input.externalKey,
    submitted: results.length,
    requestType,
    results
  };
}

/** sfmc_get_email_send_summary */
export async function getEmailSendSummary(
  ctx: SfmcToolContext,
  input: GetEmailSendSummaryInput
): Promise<unknown> {
  const token = await ctx.client.resolveAuth(ctx.resolveAccountId(input.bu)).getAccessToken();
  const filter = input.sendId
    ? { property: 'ID', simpleOperator: 'equals' as const, value: input.sendId }
    : {
        property: 'SendDate',
        simpleOperator: 'between' as const,
        value: [input.startDate!, input.endDate!]
      };
  const envelope = buildRetrieveEnvelope({
    token,
    objectType: 'Send',
    properties: [
      'ID',
      'EmailName',
      'SentDate',
      'NumberSent',
      'NumberDelivered',
      'UniqueOpens',
      'NumberOfOpens',
      'UniqueClicks',
      'NumberOfClicks',
      'SoftBounces',
      'HardBounces',
      'OtherBounces',
      'Unsubscribes',
      'SpamComplaints'
    ],
    filter
  });
  const xml = await ctx.client.soap({ soapAction: 'Retrieve', envelope, accountId: ctx.resolveAccountId(input.bu) });
  const parsed = parseRetrieveResponse(xml);

  const sends = parsed.results.map((r) => ({
    sendId: r.ID,
    emailName: r.EmailName,
    sentDate: r.SentDate,
    numberSent: toInt(r.NumberSent),
    numberDelivered: toInt(r.NumberDelivered),
    uniqueOpens: toInt(r.UniqueOpens),
    totalOpens: toInt(r.NumberOfOpens),
    uniqueClicks: toInt(r.UniqueClicks),
    totalClicks: toInt(r.NumberOfClicks),
    softBounces: toInt(r.SoftBounces),
    hardBounces: toInt(r.HardBounces),
    otherBounces: toInt(r.OtherBounces),
    unsubscribes: toInt(r.Unsubscribes),
    spamComplaints: toInt(r.SpamComplaints)
  }));

  const aggregate = sends.reduce(
    (acc, s) => {
      acc.sends += s.numberSent ?? 0;
      acc.delivered += s.numberDelivered ?? 0;
      acc.uniqueOpens += s.uniqueOpens ?? 0;
      acc.totalOpens += s.totalOpens ?? 0;
      acc.uniqueClicks += s.uniqueClicks ?? 0;
      acc.totalClicks += s.totalClicks ?? 0;
      acc.bounces +=
        (s.softBounces ?? 0) + (s.hardBounces ?? 0) + (s.otherBounces ?? 0);
      acc.unsubscribes += s.unsubscribes ?? 0;
      acc.spamComplaints += s.spamComplaints ?? 0;
      return acc;
    },
    {
      sends: 0,
      delivered: 0,
      uniqueOpens: 0,
      totalOpens: 0,
      uniqueClicks: 0,
      totalClicks: 0,
      bounces: 0,
      unsubscribes: 0,
      spamComplaints: 0
    }
  );

  return {
    scope: input.sendId
      ? { sendId: input.sendId }
      : { startDate: input.startDate, endDate: input.endDate },
    sendCount: sends.length,
    aggregate,
    sends
  };
}

function toInt(v: string | undefined): number | null {
  if (v === undefined) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

/** sfmc_create_data_extension */
export async function createDataExtension(
  ctx: SfmcToolContext,
  input: CreateDataExtensionInput
): Promise<unknown> {
  const token = await ctx.client.resolveAuth(ctx.resolveAccountId(input.bu)).getAccessToken();
  const envelope = buildCreateDeEnvelope({
    token,
    name: input.name,
    customerKey: input.customerKey,
    description: input.description,
    categoryId: input.categoryId,
    fields: input.fields,
    sendable: input.sendable,
    retention: input.retention
  });
  const xml = await ctx.client.soap({ soapAction: 'Create', envelope, accountId: ctx.resolveAccountId(input.bu) });
  const resp = parseMutateResponse(xml, 'Create DataExtension');
  const r = resp.results[0];
  if (r?.statusCode !== 'OK') {
    throw new Error(`Create DataExtension failed: ${r?.statusMessage ?? resp.overallStatus}`);
  }
  return {
    status: r.statusCode,
    message: r.statusMessage,
    customerKey: r.customerKey ?? input.customerKey,
    objectId: r.objectId
  };
}

/** sfmc_alter_data_extension — add/remove/update fields and/or DE-level properties. */
export async function alterDataExtension(
  ctx: SfmcToolContext,
  input: AlterDataExtensionInput
): Promise<unknown> {
  const token = await ctx.client.resolveAuth(ctx.resolveAccountId(input.bu)).getAccessToken();
  const operations: Array<{ operation: string; status: string; message?: string }> = [];

  if (input.addFields?.length) {
    const envelope = buildAddDeFieldsEnvelope({ token, deKey: input.key, fields: input.addFields });
    const xml = await ctx.client.soap({ soapAction: 'Update', envelope, accountId: ctx.resolveAccountId(input.bu) });
    const resp = parseMutateResponse(xml, 'Add Fields');
    for (const r of resp.results) {
      operations.push({ operation: 'addField', status: r.statusCode, message: r.statusMessage });
    }
  }

  if (input.updateFields?.length) {
    const envelope = buildUpdateDeFieldsEnvelope({
      token,
      deKey: input.key,
      updates: input.updateFields.map((u) => ({
        fieldName: u.name,
        maxLength: u.maxLength,
        defaultValue: u.defaultValue,
        isRequired: u.isRequired
      }))
    });
    const xml = await ctx.client.soap({ soapAction: 'Update', envelope, accountId: ctx.resolveAccountId(input.bu) });
    const resp = parseMutateResponse(xml, 'Update Fields');
    for (const r of resp.results) {
      operations.push({ operation: 'updateField', status: r.statusCode, message: r.statusMessage });
    }
  }

  if (input.removeFields?.length) {
    const envelope = buildDeleteDeFieldsEnvelope({
      token,
      deKey: input.key,
      fieldNames: input.removeFields
    });
    const xml = await ctx.client.soap({ soapAction: 'Delete', envelope, accountId: ctx.resolveAccountId(input.bu) });
    const resp = parseMutateResponse(xml, 'Delete Fields');
    for (const r of resp.results) {
      operations.push({ operation: 'removeField', status: r.statusCode, message: r.statusMessage });
    }
  }

  if (input.properties) {
    const { name, description, categoryId, sendable, retention } = input.properties;
    const envelope = buildUpdateDeEnvelope({ token, deKey: input.key, name, description, categoryId, sendable, retention });
    const xml = await ctx.client.soap({ soapAction: 'Update', envelope, accountId: ctx.resolveAccountId(input.bu) });
    const resp = parseMutateResponse(xml, 'Update DE Properties');
    const r = resp.results[0];
    operations.push({
      operation: 'updateProperties',
      status: r?.statusCode ?? 'Unknown',
      message: r?.statusMessage
    });
  }

  const hasErrors = operations.some((o) => o.status !== 'OK');
  return {
    key: input.key,
    overallStatus: hasErrors ? 'HasErrors' : 'OK',
    operations
  };
}

/** sfmc_delete_data_extension — permanently delete a DataExtension by CustomerKey. */
export async function deleteDataExtension(
  ctx: SfmcToolContext,
  input: DeleteDataExtensionInput
): Promise<unknown> {
  const token = await ctx.client.resolveAuth(ctx.resolveAccountId(input.bu)).getAccessToken();
  const envelope = buildDeleteDeEnvelope({ token, deKey: input.key });
  const xml = await ctx.client.soap({ soapAction: 'Delete', envelope, accountId: ctx.resolveAccountId(input.bu) });
  const resp = parseMutateResponse(xml, 'Delete DataExtension');
  const r = resp.results[0];
  if (r?.statusCode !== 'OK') {
    throw new Error(`Delete DataExtension failed: ${r?.statusMessage ?? resp.overallStatus}`);
  }
  return {
    key: input.key,
    status: r.statusCode,
    message: r.statusMessage
  };
}

/**
 * sfmc_delete_data_extension_rows
 * Asynchronously delete rows from a Data Extension via the REST async API.
 * Provide an OData $filter to delete matching rows; omit it to delete all rows.
 */
export async function deleteDataExtensionRows(
  ctx: SfmcToolContext,
  input: DeleteDeRowsInput
): Promise<unknown> {
  const path = `/data/v1/async/dataextensions/key:${encodeURIComponent(input.key)}/rows`;
  const query: Record<string, string | number | boolean | undefined> = {};
  if (input.filter) query.$filter = input.filter;
  const data = await ctx.client.rest<Record<string, unknown>>({
    method: 'DELETE',
    path,
    query,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return {
    key: input.key,
    status: 'OK',
    message: 'Row deletion request accepted. Rows will be removed asynchronously.',
    raw: data
  };
}

/** sfmc_rename_data_extension — rename a Data Extension in-place without touching rows or schema. */
export async function renameDataExtension(
  ctx: SfmcToolContext,
  input: RenameDataExtensionInput
): Promise<unknown> {
  const token = await ctx.client.resolveAuth(ctx.resolveAccountId(input.bu)).getAccessToken();
  const envelope = buildUpdateDeEnvelope({ token, deKey: input.key, name: input.newName });
  const xml = await ctx.client.soap({ soapAction: 'Update', envelope, accountId: ctx.resolveAccountId(input.bu) });
  const resp = parseMutateResponse(xml, 'Update DataExtension');
  const r = resp.results[0];
  if (r?.statusCode !== 'OK') {
    throw new Error(`Rename DataExtension failed: ${r?.statusMessage ?? resp.overallStatus}`);
  }
  return { key: input.key, newName: input.newName, status: 'OK', message: 'Data Extension renamed.' };
}

/**
 * sfmc_export_data_extension — two modes:
 *
 * DATE-RANGE mode  (dateField + fromDate/toDate provided):
 *   Uses REST $filter with monthly chunking. No SOAP DataExtensionObject
 *   perms required. No $skip — each monthly chunk is its own $top=2500 call.
 *
 * FULL-DE mode  (no date filter):
 *   Uses SOAP DataExtensionObject + ContinueRequest. Requires the connected
 *   app to have Data Extension read scope.
 */
export async function exportDataExtension(
  ctx: SfmcToolContext,
  input: ExportDataExtensionInput
): Promise<unknown> {
  const accountId = ctx.resolveAccountId(input.bu);
  const maxRows = input.maxRows ?? Infinity;

  // Ensure the output directory exists (creates it if needed).
  await mkdir(dirname(input.outputPath), { recursive: true });

  // Step 1 — discover column names.
  // SOAP DataExtensionField preserves ordinal order; REST fallback gives alphabetical.
  const fields = await resolveDeFields(ctx, accountId, input.key);
  if (fields.length === 0) {
    throw new Error(
      `No fields found for DE key "${input.key}". ` +
      `Use the CustomerKey (External Key), not the display name.`
    );
  }

  const esc = (v: unknown): string => {
    const s = v == null ? '' : String(v);
    return /[,"\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };

  await writeFile(input.outputPath, fields.join(',') + '\r\n', 'utf-8');

  let totalRows = 0;
  let truncatedChunks = 0;

  if (input.dateField && (input.fromDate || input.toDate)) {
    // ── DATE-RANGE MODE ─────────────────────────────────────────────────────
    const dateField  = input.dateField; // narrow string|undefined → string
    const from       = parseUserDate(input.fromDate ?? '2000-01-01');
    const to         = parseUserDate(input.toDate   ?? '2099-12-31');
    // Expand toDate to end-of-day so rows with intra-day timestamps are included.
    const toEndOfDay = new Date(to.getFullYear(), to.getMonth(), to.getDate(), 23, 59, 59, 999);

    // Probe: does REST $filter accept this field name?
    // Field names with spaces (e.g. "Date Collected") always return 400 in OData.
    let serverFilterWorks = false;
    try {
      await fetchRestDateChunk(ctx, accountId, input.key, dateField, from, toEndOfDay, 1);
      serverFilterWorks = true;
    } catch (err) {
      if (!isFilterError(err)) throw err;
      // 400 / Bad Request — fall through to client-side filter
    }

    if (serverFilterWorks) {
      // Server-side mode: REST $filter + monthly chunks (no $skip needed).
      for (const [chunkFrom, chunkTo] of monthlyChunks(from, toEndOfDay)) {
        if (totalRows >= maxRows) break;
        const limit = Math.min(2500, maxRows - totalRows);
        const rows = await fetchRestDateChunk(
          ctx, accountId, input.key, dateField, chunkFrom, chunkTo, limit
        );
        if (rows.length > 0) {
          const chunk = rows.map((r) => { const nr = normalizeRow(r, fields); return fields.map((f) => esc(nr[f])).join(','); }).join('\r\n') + '\r\n';
          await appendFile(input.outputPath, chunk, 'utf-8');
          totalRows += rows.length;
        }
        if (rows.length === limit && limit === 2500) truncatedChunks++;
      }
    } else {
      // Client-side filter: field name has spaces — REST $filter unsupported.
      // Fetch ALL rows via REST $skip, filter by date in memory, write matches only.
      const fromMs     = from.getTime();
      const toMs       = toEndOfDay.getTime();
      const PAGE       = 2500;
      let   page       = 0;
      let   firstFp: string | undefined;

      while (totalRows < maxRows) {
        const lim = Math.min(PAGE, maxRows - totalRows);
        const data = await ctx.client.rest<{
          items?: Array<{ keys?: Record<string, unknown>; values?: Record<string, unknown> }>;
        }>({
          method: 'GET',
          path: `/data/v1/customobjectdata/key/${encodeURIComponent(input.key)}/rowset`,
          query: { $top: lim, $skip: page * PAGE },
          accountId
        });
        const items = data.items ?? [];
        if (items.length === 0) break;

        // Stop if $skip is looping (SFMC bug — same first row on every page).
        const fp = JSON.stringify(items[0]);
        if (page === 0) { firstFp = fp; }
        else if (fp === firstFp) { truncatedChunks++; break; }

        const matched = items
          .map((r) => normalizeRow({ ...(r.keys ?? {}), ...(r.values ?? {}) }, fields))
          .filter((row) => {
            const v = row[dateField];
            if (v == null) return false;
            const ms = new Date(String(v)).getTime();
            return !isNaN(ms) && ms >= fromMs && ms <= toMs;
          });

        if (matched.length > 0) {
          const slice = matched.slice(0, maxRows - totalRows);
          const chunk = slice.map((r) => fields.map((f) => esc(r[f])).join(',')).join('\r\n') + '\r\n';
          await appendFile(input.outputPath, chunk, 'utf-8');
          totalRows += slice.length;
        }
        if (items.length < PAGE) break;
        page++;
      }
    }
  } else {
    // ── FULL-DE MODE: SOAP ContinueRequest → REST $skip fallback ────────────
    // Tries SOAP first; if permissions fail, falls back to REST $skip pagination
    // with loop detection (stops if SFMC returns the same page twice).
    let soapSucceeded = false;
    try {
      const token = await ctx.client.resolveAuth(accountId).getAccessToken();
      let continueRequestId: string | undefined;
      for (;;) {
        if (totalRows >= maxRows) break;
        const envelope = buildRetrieveEnvelope({
          token,
          objectType: `DataExtensionObject[${input.key}]`,
          properties: fields,
          continueRequestId
        });
        const xml = await ctx.client.soap({ soapAction: 'Retrieve', envelope, accountId });
        const parsed = parseRetrieveResponse(xml);
        if (parsed.results.length === 0) break;
        const limit = Math.min(parsed.results.length, maxRows - totalRows);
        const chunk = parsed.results
          .slice(0, limit)
          .map((r) => {
            const row = parseDeProperties(r['Properties'] ?? '', fields);
            return fields.map((f) => esc(row[f])).join(',');
          })
          .join('\r\n') + '\r\n';
        await appendFile(input.outputPath, chunk, 'utf-8');
        totalRows += limit;
        if (!parsed.moreResults || !parsed.requestId) break;
        continueRequestId = parsed.requestId;
      }
      soapSucceeded = true;
    } catch {
      /* SOAP permissions denied — fall through to REST */
    }

    if (!soapSucceeded) {
      // REST $skip fallback. Detects page-loop (SFMC $skip bug) and stops early.
      const PAGE = 2500;
      let page = 0;
      let firstPageFingerprint: string | undefined;

      while (totalRows < maxRows) {
        const lim = Math.min(PAGE, maxRows - totalRows);
        const data = await ctx.client.rest<{
          items?: Array<{ keys?: Record<string, unknown>; values?: Record<string, unknown> }>;
        }>({
          method: 'GET',
          path: `/data/v1/customobjectdata/key/${encodeURIComponent(input.key)}/rowset`,
          query: { $top: lim, $skip: page * PAGE },
          accountId
        });
        const items = data.items ?? [];
        if (items.length === 0) break;

        // Detect $skip looping: if page 2+ starts with the same row as page 1, stop.
        const fingerprint = JSON.stringify(items[0]);
        if (page === 0) {
          firstPageFingerprint = fingerprint;
        } else if (fingerprint === firstPageFingerprint) {
          truncatedChunks++;
          break;
        }

        const chunk = items
          .map((r) => {
            const row = normalizeRow({ ...(r.keys ?? {}), ...(r.values ?? {}) }, fields);
            return fields.map((f) => esc(row[f])).join(',');
          })
          .join('\r\n') + '\r\n';
        await appendFile(input.outputPath, chunk, 'utf-8');
        totalRows += items.length;
        if (items.length < lim) break;
        page++;
      }
    }
  }

  const result: Record<string, unknown> = {
    key: input.key,
    outputPath: input.outputPath,
    totalRows,
    columns: fields,
    truncated: totalRows >= (input.maxRows ?? Infinity),
    message: `Exported ${totalRows} rows to ${input.outputPath}`
  };
  if (truncatedChunks > 0) {
    result.truncatedChunks = truncatedChunks;
    result.truncatedChunksNote =
      `Export is incomplete: either ${truncatedChunks} monthly chunk(s) hit the 2500-row REST limit, ` +
      `or REST $skip pagination looped (SFMC bug). ` +
      `For a complete export, re-run with dateField + fromDate + toDate to use date-chunked REST mode.`;
  }
  return result;
}

/**
 * Normalize a REST row's keys to match the SOAP field names.
 * SFMC REST returns all keys in lowercase; SOAP field names may be mixed-case.
 * This builds a canonical record keyed exactly by each SOAP field name.
 */
function normalizeRow(
  rawRow: Record<string, unknown>,
  fields: string[]
): Record<string, unknown> {
  const lowerMap = new Map<string, unknown>();
  for (const [k, v] of Object.entries(rawRow)) {
    lowerMap.set(k.toLowerCase(), v);
  }
  const out: Record<string, unknown> = {};
  for (const f of fields) {
    out[f] = lowerMap.get(f.toLowerCase());
  }
  return out;
}

/** Discover DE field names. SOAP first (preserves ordinal); REST fallback (alphabetical). */
async function resolveDeFields(
  ctx: SfmcToolContext,
  accountId: string | undefined,
  key: string
): Promise<string[]> {
  try {
    const token = await ctx.client.resolveAuth(accountId).getAccessToken();
    const envelope = buildRetrieveEnvelope({
      token,
      objectType: 'DataExtensionField',
      properties: ['Name', 'Ordinal'],
      filter: { property: 'DataExtension.CustomerKey', simpleOperator: 'equals', value: key }
    });
    const xml = await ctx.client.soap({ soapAction: 'Retrieve', envelope, accountId });
    const resp = parseRetrieveResponse(xml);
    const fields = resp.results
      .sort((a, b) => Number(a.Ordinal ?? 0) - Number(b.Ordinal ?? 0))
      .map((f) => f.Name)
      .filter(Boolean);
    if (fields.length > 0) return fields;
  } catch {
    /* SOAP unavailable — fall through to REST */
  }
  // REST fallback: derive field names from one sample row.
  const sample = await ctx.client.rest<{
    items?: Array<{ keys?: Record<string, unknown>; values?: Record<string, unknown> }>;
  }>({
    method: 'GET',
    path: `/data/v1/customobjectdata/key/${encodeURIComponent(key)}/rowset`,
    query: { $top: 1 },
    accountId
  });
  const first = sample.items?.[0];
  if (!first) return [];
  return [...Object.keys(first.keys ?? {}), ...Object.keys(first.values ?? {})];
}

/** Yields [chunkFrom, chunkTo] date pairs, one per calendar month, within [from, to]. */
function* monthlyChunks(from: Date, to: Date): Generator<[Date, Date]> {
  let year = from.getFullYear();
  let month = from.getMonth();
  while (true) {
    const monthStart = new Date(year, month, 1);
    if (monthStart > to) break;
    const monthEnd = new Date(year, month + 1, 0, 23, 59, 59, 999);
    yield [
      monthStart < from ? from : monthStart,
      monthEnd > to ? to : monthEnd
    ];
    if (++month > 11) { month = 0; year++; }
  }
}

function parseUserDate(s: string): Date {
  const d = new Date(s);
  if (isNaN(d.getTime())) throw new Error(`Invalid date: "${s}"`);
  return d;
}

function dateToStr(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

/** Returns true if err looks like a REST 400 / OData filter-rejected error. */
function isFilterError(err: unknown): boolean {
  const msg = String((err as Error)?.message ?? err ?? '').toLowerCase();
  return msg.includes('400') || msg.includes('bad request') || msg.includes('filter');
}

/** Fetch a single date-bounded chunk of DE rows via REST $filter (no $skip). */
async function fetchRestDateChunk(
  ctx: SfmcToolContext,
  accountId: string | undefined,
  deKey: string,
  dateField: string,
  from: Date,
  to: Date,
  limit: number
): Promise<Array<Record<string, unknown>>> {
  const filter = `${dateField} ge '${dateToStr(from)}' and ${dateField} le '${dateToStr(to)}'`;
  const data = await ctx.client.rest<{
    items?: Array<{ keys?: Record<string, unknown>; values?: Record<string, unknown> }>;
  }>({
    method: 'GET',
    path: `/data/v1/customobjectdata/key/${encodeURIComponent(deKey)}/rowset`,
    query: { $top: limit, $filter: filter },
    accountId
  });
  return (data.items ?? []).map((r) => ({ ...(r.keys ?? {}), ...(r.values ?? {}) }));
}

/** Parse the raw <Properties>...</Properties> XML from a DataExtensionObject SOAP result. */
function parseDeProperties(propsXml: string, fields: string[]): Record<string, string> {
  const row: Record<string, string> = {};
  for (const f of fields) row[f] = '';
  if (!propsXml) return row;
  const re = /<Property[^>]*>[\s\S]*?<Name>([^<]+)<\/Name>[\s\S]*?<Value>([\s\S]*?)<\/Value>[\s\S]*?<\/Property>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(propsXml)) !== null) {
    const name = m[1].trim();
    const value = m[2].replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&').trim();
    row[name] = value;
  }
  return row;
}

/** sfmc_manage_folder — create, rename, or move a Data Extension folder. */
export async function manageFolder(
  ctx: SfmcToolContext,
  input: ManageFolderInput
): Promise<unknown> {
  const token = await ctx.client.resolveAuth(ctx.resolveAccountId(input.bu)).getAccessToken();
  let envelope: string;
  let soapAction: string;

  if (input.action === 'create') {
    envelope = buildCreateFolderEnvelope({
      token,
      name: input.name!,
      parentCategoryId: input.parentCategoryId!
    });
    soapAction = 'Create';
  } else {
    envelope = buildUpdateFolderEnvelope({
      token,
      categoryId: input.categoryId!,
      name: input.name,
      parentCategoryId: input.parentCategoryId
    });
    soapAction = 'Update';
  }

  const xml = await ctx.client.soap({ soapAction, envelope, accountId: ctx.resolveAccountId(input.bu) });
  const resp = parseMutateResponse(xml, `${input.action} Folder`);
  const r = resp.results[0];
  if (r?.statusCode !== 'OK') {
    throw new Error(`Folder ${input.action} failed: ${r?.statusMessage ?? resp.overallStatus}`);
  }
  return {
    action: input.action,
    status: r.statusCode,
    message: r.statusMessage,
    categoryId: input.action === 'create' ? (r.objectId ?? r.customerKey) : String(input.categoryId)
  };
}
