import {
  AssignRoleInput,
  CreateListInput,
  CreateUserInput,
  DeleteSubscriberInput,
  GetEinsteinStoScoreInput,
  GetSubscriberInput,
  GetSubscriberSendHistoryInput,
  ListListsInput,
  ListSubscribersInput,
  ListUsersInput,
  ManageListSubscriptionInput,
  QueryDataViewInput,
  RevokeRoleInput,
  UpdateUserInput,
  UpsertSubscriberInput
} from '../schemas/sfmc.js';
import {
  buildAccountUserRoleEnvelope,
  buildCreateListEnvelope,
  buildDeleteSubscriberEnvelope,
  buildListSubscriberEnvelope,
  buildRetrieveEnvelope,
  buildSubscriberEnvelope,
  buildUserEnvelope,
  parseMutateResponse,
  parseRetrieveResponse
} from './soap.js';
import type { SfmcToolContext } from './context.js';

// ─── Subscriber Management ───────────────────────────────────────────────────

/** sfmc_list_subscribers */
export async function listSubscribers(
  ctx: SfmcToolContext,
  input: ListSubscribersInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  let filter: Parameters<typeof buildRetrieveEnvelope>[0]['filter'];

  if (input.listId !== undefined) {
    filter = { property: 'Lists.ID', simpleOperator: 'equals', value: input.listId };
  } else if (input.emailAddress) {
    filter = { property: 'EmailAddress', simpleOperator: 'like', value: input.emailAddress };
  } else if (input.status) {
    filter = { property: 'Status', simpleOperator: 'equals', value: input.status };
  }

  const collected: Record<string, string>[] = [];
  let continueRequestId: string | undefined;

  while (collected.length < input.maxResults) {
    const envelope = buildRetrieveEnvelope({
      token,
      objectType: 'Subscriber',
      properties: ['ID', 'SubscriberKey', 'EmailAddress', 'Status', 'CreatedDate', 'ModifiedDate', 'UnsubscribedDate'],
      filter,
      continueRequestId
    });
    const xml = await ctx.client.soap({ soapAction: 'Retrieve', envelope, accountId: ctx.resolveAccountId(input.bu) });
    const parsed = parseRetrieveResponse(xml);
    for (const r of parsed.results) {
      collected.push(r);
      if (collected.length >= input.maxResults) break;
    }
    if (!parsed.moreResults || !parsed.requestId) break;
    continueRequestId = parsed.requestId;
  }

  return {
    returned: collected.length,
    truncated: collected.length >= input.maxResults,
    rows: collected.map((r) => ({
      id: r.ID,
      subscriberKey: r.SubscriberKey,
      emailAddress: r.EmailAddress,
      status: r.Status,
      createdDate: r.CreatedDate,
      modifiedDate: r.ModifiedDate,
      unsubscribedDate: r.UnsubscribedDate
    }))
  };
}

/** sfmc_get_subscriber */
export async function getSubscriber(
  ctx: SfmcToolContext,
  input: GetSubscriberInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const filter = input.subscriberKey
    ? { property: 'SubscriberKey', simpleOperator: 'equals' as const, value: input.subscriberKey }
    : { property: 'EmailAddress', simpleOperator: 'equals' as const, value: input.emailAddress! };

  const envelope = buildRetrieveEnvelope({
    token,
    objectType: 'Subscriber',
    properties: ['ID', 'SubscriberKey', 'EmailAddress', 'Status', 'CreatedDate', 'ModifiedDate', 'UnsubscribedDate'],
    filter
  });
  const xml = await ctx.client.soap({ soapAction: 'Retrieve', envelope, accountId: ctx.resolveAccountId(input.bu) });
  const parsed = parseRetrieveResponse(xml);
  if (parsed.results.length === 0) throw new Error('Subscriber not found.');
  const r = parsed.results[0];
  return {
    id: r.ID,
    subscriberKey: r.SubscriberKey,
    emailAddress: r.EmailAddress,
    status: r.Status,
    createdDate: r.CreatedDate,
    modifiedDate: r.ModifiedDate
  };
}

/** sfmc_upsert_subscriber */
export async function upsertSubscriber(
  ctx: SfmcToolContext,
  input: UpsertSubscriberInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  // Try Update first; if not found, fall back to Create
  for (const action of ['Update', 'Create'] as const) {
    const envelope = buildSubscriberEnvelope({
      token,
      action,
      emailAddress: input.emailAddress,
      subscriberKey: input.subscriberKey,
      status: input.status,
      lists: input.lists,
      attributes: input.attributes
    });
    const xml = await ctx.client.soap({ soapAction: action, envelope, accountId: ctx.resolveAccountId(input.bu) });
    const resp = parseMutateResponse(xml, `${action} Subscriber`);
    const r = resp.results[0];
    if (r?.statusCode === 'OK') {
      return {
        emailAddress: input.emailAddress,
        action,
        status: r.statusCode,
        message: r.statusMessage
      };
    }
    // "not found" errors on Update → retry with Create
    if (action === 'Update' && r?.statusMessage?.toLowerCase().includes('not found')) continue;
    // Any other error on Create → throw
    if (action === 'Create') {
      throw new Error(`Upsert Subscriber failed: ${r?.statusMessage ?? resp.overallStatus}`);
    }
  }
  throw new Error('Upsert Subscriber failed unexpectedly.');
}

/** sfmc_delete_subscriber */
export async function deleteSubscriber(
  ctx: SfmcToolContext,
  input: DeleteSubscriberInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const envelope = buildDeleteSubscriberEnvelope({
    token,
    emailAddress: input.emailAddress ?? '',
    subscriberKey: input.subscriberKey
  });
  const xml = await ctx.client.soap({ soapAction: 'Delete', envelope, accountId: ctx.resolveAccountId(input.bu) });
  const resp = parseMutateResponse(xml, 'Delete Subscriber');
  const r = resp.results[0];
  if (r?.statusCode !== 'OK') {
    throw new Error(`Delete Subscriber failed: ${r?.statusMessage ?? resp.overallStatus}`);
  }
  return { emailAddress: input.emailAddress, subscriberKey: input.subscriberKey, status: r.statusCode, message: r.statusMessage };
}

// ─── List Management ─────────────────────────────────────────────────────────

/** sfmc_list_lists */
export async function listLists(
  ctx: SfmcToolContext,
  input: ListListsInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const filter =
    input.listClassification
      ? { property: 'ListClassification', simpleOperator: 'equals' as const, value: input.listClassification }
      : undefined;

  const collected: Record<string, string>[] = [];
  let continueRequestId: string | undefined;

  while (collected.length < input.maxResults) {
    const envelope = buildRetrieveEnvelope({
      token,
      objectType: 'List',
      properties: ['ID', 'ListName', 'Description', 'ListClassification', 'Status', 'CreatedDate', 'ModifiedDate'],
      filter,
      continueRequestId
    });
    const xml = await ctx.client.soap({ soapAction: 'Retrieve', envelope, accountId: ctx.resolveAccountId(input.bu) });
    const parsed = parseRetrieveResponse(xml);
    for (const r of parsed.results) {
      if (
        input.nameContains &&
        !String(r.ListName ?? '').toLowerCase().includes(input.nameContains.toLowerCase())
      )
        continue;
      collected.push(r);
      if (collected.length >= input.maxResults) break;
    }
    if (!parsed.moreResults || !parsed.requestId) break;
    continueRequestId = parsed.requestId;
  }

  return {
    returned: collected.length,
    truncated: collected.length >= input.maxResults,
    rows: collected.map((r) => ({
      id: r.ID,
      listName: r.ListName,
      description: r.Description,
      classification: r.ListClassification,
      status: r.Status,
      createdDate: r.CreatedDate,
      modifiedDate: r.ModifiedDate
    }))
  };
}

/** sfmc_create_list */
export async function createList(
  ctx: SfmcToolContext,
  input: CreateListInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const envelope = buildCreateListEnvelope({
    token,
    listName: input.listName,
    description: input.description,
    listClassification: input.listClassification
  });
  const xml = await ctx.client.soap({ soapAction: 'Create', envelope, accountId: ctx.resolveAccountId(input.bu) });
  const resp = parseMutateResponse(xml, 'Create List');
  const r = resp.results[0];
  if (r?.statusCode !== 'OK') {
    throw new Error(`Create List failed: ${r?.statusMessage ?? resp.overallStatus}`);
  }
  return {
    listId: r.objectId,
    listName: input.listName,
    status: r.statusCode,
    message: r.statusMessage
  };
}

/** sfmc_manage_list_subscription */
export async function manageListSubscription(
  ctx: SfmcToolContext,
  input: ManageListSubscriptionInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const soapAction = input.action === 'subscribe' ? 'Create' : 'Delete';
  const envelope = buildListSubscriberEnvelope({
    token,
    action: soapAction,
    listId: input.listId,
    subscribers: input.subscribers.map((s) => ({
      emailAddress: s.emailAddress,
      subscriberKey: s.subscriberKey,
      status: input.action === 'subscribe' ? 'Active' : undefined
    }))
  });
  const xml = await ctx.client.soap({ soapAction, envelope, accountId: ctx.resolveAccountId(input.bu) });
  const resp = parseMutateResponse(xml, `${input.action} ListSubscriber`);
  const errors = resp.results.filter((r) => r.statusCode !== 'OK');
  return {
    listId: input.listId,
    action: input.action,
    submitted: input.subscribers.length,
    succeeded: resp.results.length - errors.length,
    failed: errors.length,
    errors: errors.map((e) => ({ statusCode: e.statusCode, message: e.statusMessage }))
  };
}

// ─── User & Account Management ───────────────────────────────────────────────

/** sfmc_list_users */
export async function listUsers(
  ctx: SfmcToolContext,
  input: ListUsersInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  let filter: Parameters<typeof buildRetrieveEnvelope>[0]['filter'];
  if (input.email) {
    filter = { property: 'Email', simpleOperator: 'equals', value: input.email };
  }

  const collected: Record<string, string>[] = [];
  let continueRequestId: string | undefined;

  while (collected.length < input.maxResults) {
    const envelope = buildRetrieveEnvelope({
      token,
      objectType: 'AccountUser',
      properties: ['ID', 'Name', 'Email', 'IsLocked', 'ActiveFlag', 'CreatedDate', 'ModifiedDate', 'MustChangePassword'],
      filter,
      continueRequestId
    });
    const xml = await ctx.client.soap({ soapAction: 'Retrieve', envelope, accountId: ctx.resolveAccountId(input.bu) });
    const parsed = parseRetrieveResponse(xml);
    for (const r of parsed.results) {
      if (input.nameContains && !String(r.Name ?? '').toLowerCase().includes(input.nameContains.toLowerCase()))
        continue;
      if (input.isActive !== undefined && (r.ActiveFlag === 'true') !== input.isActive) continue;
      collected.push(r);
      if (collected.length >= input.maxResults) break;
    }
    if (!parsed.moreResults || !parsed.requestId) break;
    continueRequestId = parsed.requestId;
  }

  return {
    returned: collected.length,
    rows: collected.map((r) => ({
      id: r.ID,
      name: r.Name,
      email: r.Email,
      isLocked: r.IsLocked === 'true',
      isActive: r.ActiveFlag === 'true',
      mustChangePassword: r.MustChangePassword === 'true',
      createdDate: r.CreatedDate,
      modifiedDate: r.ModifiedDate
    }))
  };
}

/** sfmc_create_user */
export async function createUser(
  ctx: SfmcToolContext,
  input: CreateUserInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const envelope = buildUserEnvelope({
    token,
    action: 'Create',
    name: input.name,
    email: input.email,
    password: input.password,
    mustChangePassword: input.mustChangePassword,
    isLocked: input.isLocked,
    notificationEmailAddress: input.notificationEmailAddress
  });
  const xml = await ctx.client.soap({ soapAction: 'Create', envelope, accountId: ctx.resolveAccountId(input.bu) });
  const resp = parseMutateResponse(xml, 'Create AccountUser');
  const r = resp.results[0];
  if (r?.statusCode !== 'OK') {
    throw new Error(`Create User failed: ${r?.statusMessage ?? resp.overallStatus}`);
  }
  return { userId: r.objectId, name: input.name, email: input.email, status: r.statusCode, message: r.statusMessage };
}

/** sfmc_update_user */
export async function updateUser(
  ctx: SfmcToolContext,
  input: UpdateUserInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const envelope = buildUserEnvelope({
    token,
    action: 'Update',
    id: input.id,
    name: input.name,
    notificationEmailAddress: input.notificationEmailAddress,
    isLocked: input.isLocked,
    mustChangePassword: input.mustChangePassword,
    isActive: input.isActive
  });
  const xml = await ctx.client.soap({ soapAction: 'Update', envelope, accountId: ctx.resolveAccountId(input.bu) });
  const resp = parseMutateResponse(xml, 'Update AccountUser');
  const r = resp.results[0];
  if (r?.statusCode !== 'OK') {
    throw new Error(`Update User failed: ${r?.statusMessage ?? resp.overallStatus}`);
  }
  return { userId: input.id, status: r.statusCode, message: r.statusMessage };
}

// ─── Reports & Analytics ─────────────────────────────────────────────────────

/** sfmc_query_data_view — query SFMC system data views via SOAP. */
export async function queryDataView(
  ctx: SfmcToolContext,
  input: QueryDataViewInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const collected: Record<string, string>[] = [];
  let continueRequestId: string | undefined;

  while (collected.length < input.maxResults) {
    const envelope = buildRetrieveEnvelope({
      token,
      objectType: input.view,
      properties: input.properties,
      filter: input.filter,
      continueRequestId
    });
    const xml = await ctx.client.soap({ soapAction: 'Retrieve', envelope, accountId: ctx.resolveAccountId(input.bu) });
    const parsed = parseRetrieveResponse(xml);
    for (const r of parsed.results) {
      collected.push(r);
      if (collected.length >= input.maxResults) break;
    }
    if (!parsed.moreResults || !parsed.requestId) break;
    continueRequestId = parsed.requestId;
  }

  return {
    view: input.view,
    returned: collected.length,
    truncated: collected.length >= input.maxResults,
    rows: collected
  };
}

/** sfmc_get_subscriber_send_history — pull per-send records for a subscriber via REST. */
export async function getSubscriberSendHistory(
  ctx: SfmcToolContext,
  input: GetSubscriberSendHistoryInput
): Promise<unknown> {
  const data = await ctx.client.rest<unknown>({
    method: 'GET',
    path: `/data/v2/subscribers/${encodeURIComponent(input.subscriberKey)}/sends`,
    query: { $top: input.top, $skip: input.skip },
    accountId: ctx.resolveAccountId(input.bu)
  });
  return data;
}

// ─── User Role Management ─────────────────────────────────────────────────────

/** sfmc_assign_role — grant a role to an SFMC account user. */
export async function assignRole(
  ctx: SfmcToolContext,
  input: AssignRoleInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const envelope = buildAccountUserRoleEnvelope({
    token,
    action: 'Create',
    userId: input.userId,
    roleId: input.roleId,
    roleName: input.roleName
  });
  const xml = await ctx.client.soap({ soapAction: 'Create', envelope, accountId: ctx.resolveAccountId(input.bu) });
  parseMutateResponse(xml, 'Create AccountUserRole');
  return { userId: input.userId, status: 'OK', message: 'Role assigned.' };
}

/** sfmc_revoke_role — remove a role from an SFMC account user. */
export async function revokeRole(
  ctx: SfmcToolContext,
  input: RevokeRoleInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const envelope = buildAccountUserRoleEnvelope({
    token,
    action: 'Delete',
    userId: input.userId,
    roleId: input.roleId,
    roleName: input.roleName
  });
  const xml = await ctx.client.soap({ soapAction: 'Delete', envelope, accountId: ctx.resolveAccountId(input.bu) });
  parseMutateResponse(xml, 'Delete AccountUserRole');
  return { userId: input.userId, status: 'OK', message: 'Role revoked.' };
}

// ─── Einstein Send Time Optimization ─────────────────────────────────────────

/** sfmc_get_einstein_sto_score — retrieve Einstein STO scores for a subscriber or account defaults. */
export async function getEinsteinStoScore(
  ctx: SfmcToolContext,
  input: GetEinsteinStoScoreInput
): Promise<unknown> {
  const query: Record<string, string | number | boolean | undefined> = {};
  if (input.subscriberKey) query.subscriberKey = input.subscriberKey;
  if (input.timezone) query.timezone = input.timezone;
  const data = await ctx.client.rest<unknown>({
    method: 'GET',
    path: '/ens/v2/sto/scores',
    query,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return data;
}
