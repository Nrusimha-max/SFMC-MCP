import {
  CloneAssetInput,
  CreateAssetInput,
  DeleteAssetInput,
  GetAssetInput,
  GetCloudpageUrlInput,
  ListAssetsInput,
  ManageCloudpageCollectionInput,
  MoveAssetInput,
  PublishCloudpageInput,
  UnpublishCloudpageInput,
  UpdateAssetInput
} from '../schemas/sfmc.js';
import type { SfmcToolContext } from './context.js';

// Asset type ID groups for filtering
const ASSET_TYPE_IDS: Record<string, number[]> = {
  email: [207, 208, 209, 210, 214],
  template: [4, 5, 6],
  'content-block': [195, 196, 197, 198, 199, 200],
  image: [28, 42, 44],
  cloudpage: [329, 310]
};

interface AssetQueryResponse {
  count?: number;
  page?: number;
  pageSize?: number;
  items?: Array<Record<string, unknown>>;
}

/** sfmc_list_assets */
export async function listAssets(
  ctx: SfmcToolContext,
  input: ListAssetsInput
): Promise<unknown> {
  const conditions: Array<Record<string, unknown>> = [];

  if (input.type !== 'all') {
    const ids = ASSET_TYPE_IDS[input.type] ?? [];
    if (ids.length > 0) {
      conditions.push({
        leftOperand: { property: 'assetType.id', simpleOperator: 'IN', value: ids }
      });
    }
  }
  if (input.nameContains) {
    conditions.push({
      leftOperand: {
        property: 'name',
        simpleOperator: 'like',
        value: `%${input.nameContains}%`
      }
    });
  }
  if (input.categoryId !== undefined) {
    conditions.push({
      leftOperand: { property: 'category.id', simpleOperator: 'equal', value: input.categoryId }
    });
  }

  const query =
    conditions.length === 0
      ? {}
      : conditions.length === 1
        ? conditions[0].leftOperand
        : conditions.reduce((acc, c, i) =>
            i === 1
              ? { leftOperand: conditions[0].leftOperand, logicalOperator: 'AND', rightOperand: c.leftOperand }
              : { leftOperand: acc, logicalOperator: 'AND', rightOperand: c.leftOperand }
          );

  const body: Record<string, unknown> = {
    page: { page: input.page, pageSize: input.top },
    sort: [{ property: 'name', direction: 'ASC' }],
    fields: ['id', 'name', 'assetType', 'category', 'description', 'createdDate', 'modifiedDate', 'status']
  };
  if (conditions.length > 0) body.query = query;

  const data = await ctx.client.rest<AssetQueryResponse>({
    method: 'POST',
    path: '/asset/v1/content/assets/query',
    body,
    accountId: ctx.resolveAccountId(input.bu)
  });

  return {
    total: data.count ?? (data.items?.length ?? 0),
    page: data.page ?? input.page,
    pageSize: data.pageSize ?? input.top,
    items: (data.items ?? []).map((a) => ({
      id: a.id,
      name: a.name,
      assetType: a.assetType,
      category: a.category,
      description: a.description,
      status: a.status,
      createdDate: a.createdDate,
      modifiedDate: a.modifiedDate
    }))
  };
}

/** sfmc_get_asset */
export async function getAsset(
  ctx: SfmcToolContext,
  input: GetAssetInput
): Promise<unknown> {
  const data = await ctx.client.rest<unknown>({
    method: 'GET',
    path: `/asset/v1/content/assets/${input.id}`,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return data;
}

/** sfmc_create_asset */
export async function createAsset(
  ctx: SfmcToolContext,
  input: CreateAssetInput
): Promise<unknown> {
  const body: Record<string, unknown> = {
    name: input.name,
    assetType: input.assetType
  };
  if (input.description) body.description = input.description;
  if (input.category) body.category = input.category;
  if (input.content) body.content = input.content;
  if (input.views) body.views = input.views;
  if (input.data) body.data = input.data;
  if (input.meta) body.meta = input.meta;

  const data = await ctx.client.rest<Record<string, unknown>>({
    method: 'POST',
    path: '/asset/v1/content/assets',
    body,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return {
    id: data.id,
    name: data.name,
    assetType: data.assetType,
    category: data.category,
    status: 'OK',
    message: 'Asset created.'
  };
}

/** sfmc_update_asset */
export async function updateAsset(
  ctx: SfmcToolContext,
  input: UpdateAssetInput
): Promise<unknown> {
  const body: Record<string, unknown> = {};
  if (input.name) body.name = input.name;
  if (input.description !== undefined) body.description = input.description;
  if (input.content !== undefined) body.content = input.content;
  if (input.views) body.views = input.views;
  if (input.data) body.data = input.data;
  if (input.meta) body.meta = input.meta;

  const data = await ctx.client.rest<Record<string, unknown>>({
    method: 'PATCH',
    path: `/asset/v1/content/assets/${input.id}`,
    body,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return {
    id: input.id,
    name: data.name ?? input.name,
    status: 'OK',
    message: 'Asset updated.'
  };
}

/** sfmc_delete_asset */
export async function deleteAsset(
  ctx: SfmcToolContext,
  input: DeleteAssetInput
): Promise<unknown> {
  await ctx.client.rest<unknown>({
    method: 'DELETE',
    path: `/asset/v1/content/assets/${input.id}`,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return { id: input.id, status: 'OK', message: 'Asset deleted.' };
}

/**
 * sfmc_clone_asset
 * Duplicate a Content Builder asset: fetch the source, strip server-managed
 * fields, rename it, optionally relocate it, then POST to create the copy.
 */
export async function cloneAsset(
  ctx: SfmcToolContext,
  input: CloneAssetInput
): Promise<unknown> {
  const source = await ctx.client.rest<Record<string, unknown>>({
    method: 'GET',
    path: `/asset/v1/content/assets/${input.sourceId}`,
    accountId: ctx.resolveAccountId(input.bu)
  });
  // Strip server-only fields that must not be sent on creation.
  const {
    id: _id,
    createdDate: _cd,
    createdBy: _cb,
    modifiedDate: _md,
    modifiedBy: _mb,
    ...cloneBody
  } = source;
  cloneBody.name = input.newName;
  if (input.targetCategoryId !== undefined) {
    cloneBody.category = { id: input.targetCategoryId };
  }
  const created = await ctx.client.rest<Record<string, unknown>>({
    method: 'POST',
    path: '/asset/v1/content/assets',
    body: cloneBody,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return {
    id: created.id,
    name: created.name,
    assetType: created.assetType,
    category: created.category,
    status: 'OK',
    message: 'Asset cloned.'
  };
}

/** sfmc_move_asset — change the folder (category) of a Content Builder asset. */
export async function moveAsset(
  ctx: SfmcToolContext,
  input: MoveAssetInput
): Promise<unknown> {
  await ctx.client.rest<unknown>({
    method: 'PATCH',
    path: `/asset/v1/content/assets/${input.id}`,
    body: { category: { id: input.categoryId } },
    accountId: ctx.resolveAccountId(input.bu)
  });
  return { id: input.id, categoryId: input.categoryId, status: 'OK', message: 'Asset moved.' };
}

/** sfmc_publish_cloudpage — publish a CloudPage and return its live URL. */
export async function publishCloudpage(
  ctx: SfmcToolContext,
  input: PublishCloudpageInput
): Promise<unknown> {
  const data = await ctx.client.rest<Record<string, unknown>>({
    method: 'POST',
    path: `/asset/v1/content/assets/${input.id}/publish`,
    accountId: ctx.resolveAccountId(input.bu)
  });
  const fileProps = data.fileProperties as Record<string, unknown> | undefined;
  return {
    id: input.id,
    status: 'OK',
    message: 'CloudPage published.',
    publishedURL: fileProps?.publishedURL ?? data.publishedURL ?? null,
    raw: data
  };
}

/** sfmc_unpublish_cloudpage — take a CloudPage offline without deleting it. */
export async function unpublishCloudpage(
  ctx: SfmcToolContext,
  input: UnpublishCloudpageInput
): Promise<unknown> {
  await ctx.client.rest<unknown>({
    method: 'DELETE',
    path: `/asset/v1/content/assets/${input.id}/publish`,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return { id: input.id, status: 'OK', message: 'CloudPage unpublished.' };
}

/** sfmc_get_cloudpage_url — fetch the live published URL from fileProperties.publishedURL. */
export async function getCloudpageUrl(
  ctx: SfmcToolContext,
  input: GetCloudpageUrlInput
): Promise<unknown> {
  const data = await ctx.client.rest<Record<string, unknown>>({
    method: 'GET',
    path: `/asset/v1/content/assets/${input.id}`,
    accountId: ctx.resolveAccountId(input.bu)
  });
  const fileProps = data.fileProperties as Record<string, unknown> | undefined;
  return {
    id: input.id,
    name: data.name,
    status: data.status,
    publishedURL: fileProps?.publishedURL ?? null
  };
}

/** sfmc_manage_cloudpage_collection — create, rename/move, or delete a CloudPage collection (category). */
export async function manageCloudpageCollection(
  ctx: SfmcToolContext,
  input: ManageCloudpageCollectionInput
): Promise<unknown> {
  if (input.action === 'create') {
    const body: Record<string, unknown> = { name: input.name };
    if (input.parentId !== undefined) body.parentId = input.parentId;
    const data = await ctx.client.rest<Record<string, unknown>>({
      method: 'POST',
      path: '/asset/v1/content/categories',
      body,
      accountId: ctx.resolveAccountId(input.bu)
    });
    return {
      id: data.id,
      name: data.name,
      parentId: data.parentId,
      status: 'OK',
      message: 'Collection created.'
    };
  }
  if (input.action === 'update') {
    const body: Record<string, unknown> = {};
    if (input.name !== undefined) body.name = input.name;
    if (input.parentId !== undefined) body.parentId = input.parentId;
    await ctx.client.rest<unknown>({
      method: 'PATCH',
      path: `/asset/v1/content/categories/${input.id!}`,
      body,
      accountId: ctx.resolveAccountId(input.bu)
    });
    return { id: input.id, status: 'OK', message: 'Collection updated.' };
  }
  // delete
  await ctx.client.rest<unknown>({
    method: 'DELETE',
    path: `/asset/v1/content/categories/${input.id!}`,
    accountId: ctx.resolveAccountId(input.bu)
  });
  return { id: input.id, status: 'OK', message: 'Collection deleted.' };
}
