import type { AxiosRequestConfig } from 'axios';
import { SfmcAuth } from '../auth/sfmc-auth.js';
import type { Logger } from '../logger.js';
import { requestWithRetry } from '../utils/retry.js';
import { recordApi } from '../advanced/trace.js';
import { restIsRead, validateRestPath } from '../advanced/policy.js';

export interface SfmcClientConfig {
  auth: SfmcAuth;
  logger: Logger;
  /** Override REST base — falls back to instance URL from token, then subdomain. */
  restBaseUrl?: string;
  /** Override SOAP endpoint — falls back to instance URL from token, then subdomain. */
  soapEndpoint?: string;
  /** Default subdomain — used when no instance URL is available yet. */
  subdomain: string;
  /** Per-MID auth overrides for multi-BU routing. Keys are account IDs (MIDs). */
  buAuthMap?: Map<string, SfmcAuth>;
}

/**
 * Thin SFMC HTTP client. Handles REST + SOAP transport, auth header injection,
 * and forwards everything through the shared retry helper.
 *
 * Tool implementations stay in tools.ts — this file owns nothing
 * tool-specific, just plumbing.
 */
export class SfmcClient {
  private readonly cfg: SfmcClientConfig;
  private readonly logger: Logger;

  constructor(cfg: SfmcClientConfig) {
    this.cfg = cfg;
    this.logger = cfg.logger.child('http');
  }

  get auth(): SfmcAuth {
    return this.cfg.auth;
  }

  /** Returns the SfmcAuth for the given MID, falling back to the default auth. */
  resolveAuth(accountId?: string): SfmcAuth {
    if (accountId && this.cfg.buAuthMap?.has(accountId)) {
      return this.cfg.buAuthMap.get(accountId)!;
    }
    return this.cfg.auth;
  }

  async getAccessToken(accountId?: string): Promise<string> {
    return this.resolveAuth(accountId).getAccessToken(this.cfg.buAuthMap?.has(accountId ?? '') ? undefined : accountId);
  }

  private restBase(auth = this.cfg.auth): string {
    return (
      this.cfg.restBaseUrl ??
      auth.restInstanceUrl ??
      `https://${this.cfg.subdomain}.rest.marketingcloudapis.com`
    ).replace(/\/$/, '');
  }

  private soapEndpoint(auth = this.cfg.auth): string {
    if (this.cfg.soapEndpoint) return this.cfg.soapEndpoint;
    const instance = auth.soapInstanceUrl;
    if (instance) return `${instance.replace(/\/+$/, '')}/Service.asmx`;
    return `https://${this.cfg.subdomain}.soap.marketingcloudapis.com/Service.asmx`;
  }

  /** Issue a REST request and return the parsed body. */
  async rest<T>(opts: {
    method: AxiosRequestConfig['method'];
    path: string;
    query?: Record<string, string | number | boolean | undefined>;
    body?: unknown;
    headers?: Record<string, string>;
    timeoutMs?: number;
    accountId?: string;
  }): Promise<T> {
    validateRestPath(opts.path);
    const auth = this.resolveAuth(opts.accountId);
    await auth.getAccessToken(this.cfg.buAuthMap?.has(opts.accountId ?? '') ? undefined : opts.accountId);
    const url = `${this.restBase(auth)}${opts.path}`;
    const parsedUrl = new URL(url);
    if (parsedUrl.protocol !== 'https:' || !parsedUrl.hostname.endsWith('.rest.marketingcloudapis.com') || parsedUrl.port) throw new Error('REST endpoint must be an HTTPS SFMC tenant endpoint');
    const started = Date.now();
    const params = opts.query
      ? Object.fromEntries(
          Object.entries(opts.query).filter(([, v]) => v !== undefined && v !== null)
        )
      : undefined;

    const label = `SFMC ${opts.method ?? 'GET'} ${opts.path}`;
    const res = await requestWithRetry<T>(
      {
        method: opts.method,
        url,
        params,
        data: opts.body,
        headers: { 'Content-Type': 'application/json', ...(opts.headers ?? {}) },
        maxRedirects: 0,
        maxContentLength: 8 * 1024 * 1024,
        timeout: opts.timeoutMs ?? 30_000
      },
      {
        logger: this.logger,
        label,
        maxRetries: restIsRead(String(opts.method ?? 'GET').toUpperCase(), opts.path) ? 3 : 0,
        onUnauthorized: async () => {
          const auth = this.resolveAuth(opts.accountId);
          auth.invalidate(this.cfg.buAuthMap?.has(opts.accountId ?? '') ? undefined : opts.accountId);
          await auth.getAccessToken(this.cfg.buAuthMap?.has(opts.accountId ?? '') ? undefined : opts.accountId);
        },
        prepareConfig: async (config) => {
          const token = await this.resolveAuth(opts.accountId).getAccessToken(this.cfg.buAuthMap?.has(opts.accountId ?? '') ? undefined : opts.accountId);
          config.headers = { ...(config.headers ?? {}), Authorization: `Bearer ${token}` };
          return config;
        }
      }
    ).catch((error: unknown) => {
      recordApi({ endpoint: url, method: String(opts.method ?? 'GET').toUpperCase(), status: (error as { status?: number }).status ?? 0, durationMs: Date.now() - started });
      throw error;
    });
    recordApi({ endpoint: url, method: String(opts.method ?? 'GET').toUpperCase(), status: res.status, durationMs: Date.now() - started });
    return res.data;
  }

  /** Issue a SOAP envelope and return the raw XML body. */
  async soap(opts: {
    soapAction: string;
    envelope: string;
    timeoutMs?: number;
    accountId?: string;
  }): Promise<string> {
    const auth = this.resolveAuth(opts.accountId);
    await auth.getAccessToken(this.cfg.buAuthMap?.has(opts.accountId ?? '') ? undefined : opts.accountId);
    const url = this.soapEndpoint(auth);
    const parsedUrl = new URL(url);
    if (parsedUrl.protocol !== 'https:' || !parsedUrl.hostname.endsWith('.soap.marketingcloudapis.com') || parsedUrl.port) throw new Error('SOAP endpoint must be an HTTPS SFMC tenant endpoint');
    const started = Date.now();
    const label = `SFMC SOAP ${opts.soapAction}`;
    const res = await requestWithRetry<string>(
      {
        method: 'POST',
        url,
        data: opts.envelope,
        headers: {
          'Content-Type': 'text/xml; charset=utf-8',
          SOAPAction: opts.soapAction
        },
        maxRedirects: 0,
        maxContentLength: 8 * 1024 * 1024,
        timeout: opts.timeoutMs ?? 60_000,
        responseType: 'text',
        transformResponse: [(d) => d]
      },
      {
        logger: this.logger,
        label,
        maxRetries: opts.soapAction.toLowerCase() === 'retrieve' ? 3 : 0,
        onUnauthorized: async () => {
          const auth = this.resolveAuth(opts.accountId);
          auth.invalidate(this.cfg.buAuthMap?.has(opts.accountId ?? '') ? undefined : opts.accountId);
          await auth.getAccessToken(this.cfg.buAuthMap?.has(opts.accountId ?? '') ? undefined : opts.accountId);
        },
        prepareConfig: async (config) => {
          const token = await this.resolveAuth(opts.accountId).getAccessToken(this.cfg.buAuthMap?.has(opts.accountId ?? '') ? undefined : opts.accountId);
          // SFMC SOAP wants the token inside the envelope's <fueloauth>, but
          // it also accepts a Bearer header. We inject both — the header
          // alone works for client_credentials.
          config.headers = { ...(config.headers ?? {}), Authorization: `Bearer ${token}` };
          if (typeof config.data === 'string') {
            const safeToken = token.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            config.data = config.data.replace(/(<fueloauth\b[^>]*>)[\s\S]*?(<\/fueloauth>)/g, (_match, open, close) => `${open}${safeToken}${close}`);
          }
          return config;
        }
      }
    ).catch((error: unknown) => {
      recordApi({ endpoint: url, method: 'POST', soapAction: opts.soapAction, status: (error as { status?: number }).status ?? 0, durationMs: Date.now() - started });
      throw error;
    });
    recordApi({ endpoint: url, method: 'POST', soapAction: opts.soapAction, status: res.status, durationMs: Date.now() - started });
    return res.data;
  }
}
