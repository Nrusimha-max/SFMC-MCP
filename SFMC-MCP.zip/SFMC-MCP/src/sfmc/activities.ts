import {
  CreateQueryDefinitionInput,
  DeleteQueryDefinitionInput,
  ExecuteQueryDefinitionInput,
  GetQueryDefinitionInput,
  ManageDataExtractActivityInput,
  ManageFileTransferActivityInput,
  ManageImportDefinitionInput,
  ManageScriptActivityInput,
  TriggerBulkImportInput,
  UpdateQueryDefinitionInput
} from '../schemas/sfmc.js';
import {
  buildDataExtractActivityEnvelope,
  buildDeleteQueryDefinitionEnvelope,
  buildFileTransferActivityEnvelope,
  buildImportDefinitionEnvelope,
  buildPerformEnvelope,
  buildQueryDefinitionEnvelope,
  buildRetrieveEnvelope,
  buildSssjsActivityEnvelope,
  parseMutateResponse,
  parsePerformResponse,
  parseRetrieveResponse
} from './soap.js';
import type { SfmcToolContext } from './context.js';

// ─── SQL Query Activity (QueryDefinition) ────────────────────────────────────

/**
 * sfmc_create_query_definition
 * Create a SQL Query Activity that writes results to a target Data Extension.
 * Use queryText to query system data views (_Sent, _Open, _Click, _Bounce,
 * _Unsubscribe, _Complaint) or any DE. Call sfmc_execute_query_definition
 * to run it; read results with sfmc_get_data_extension_rows.
 */
export async function createQueryDefinition(
  ctx: SfmcToolContext,
  input: CreateQueryDefinitionInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const envelope = buildQueryDefinitionEnvelope({
    token,
    action: 'Create',
    customerKey: input.customerKey,
    name: input.name,
    description: input.description,
    queryText: input.queryText,
    targetDeKey: input.targetDeKey,
    targetDeName: input.targetDeName,
    targetUpdateType: input.targetUpdateType
  });
  const xml = await ctx.client.soap({ soapAction: 'Create', envelope, accountId: ctx.resolveAccountId(input.bu) });
  const res = parseMutateResponse(xml, 'Create');
  const r = res.results[0];
  if (r?.statusCode !== 'OK' && r?.statusCode !== 'Created') {
    throw new Error(`QueryDefinition Create failed: ${r?.statusMessage ?? res.overallStatus}`);
  }
  return {
    status: res.overallStatus,
    objectId: r?.objectId,
    customerKey: r?.customerKey ?? input.customerKey,
    message: 'QueryDefinition created. Call sfmc_execute_query_definition to run it.'
  };
}

/** sfmc_update_query_definition */
export async function updateQueryDefinition(
  ctx: SfmcToolContext,
  input: UpdateQueryDefinitionInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const envelope = buildQueryDefinitionEnvelope({
    token,
    action: 'Update',
    objectId: input.objectId,
    customerKey: input.customerKey,
    name: input.name,
    description: input.description,
    queryText: input.queryText,
    targetDeKey: input.targetDeKey,
    targetDeName: input.targetDeName,
    targetUpdateType: input.targetUpdateType
  });
  const xml = await ctx.client.soap({ soapAction: 'Update', envelope, accountId: ctx.resolveAccountId(input.bu) });
  parseMutateResponse(xml, 'Update');
  return {
    status: 'OK',
    objectId: input.objectId,
    customerKey: input.customerKey,
    message: 'QueryDefinition updated.'
  };
}

/** sfmc_delete_query_definition */
export async function deleteQueryDefinition(
  ctx: SfmcToolContext,
  input: DeleteQueryDefinitionInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const envelope = buildDeleteQueryDefinitionEnvelope({
    token,
    objectId: input.objectId,
    customerKey: input.customerKey
  });
  const xml = await ctx.client.soap({ soapAction: 'Delete', envelope, accountId: ctx.resolveAccountId(input.bu) });
  parseMutateResponse(xml, 'Delete');
  return { status: 'OK', message: 'QueryDefinition deleted.' };
}

/** sfmc_get_query_definition — retrieve details including Status. */
export async function getQueryDefinition(
  ctx: SfmcToolContext,
  input: GetQueryDefinitionInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const filter = input.objectId
    ? { property: 'ObjectID', simpleOperator: 'equals', value: input.objectId }
    : { property: 'CustomerKey', simpleOperator: 'equals', value: input.customerKey! };
  const envelope = buildRetrieveEnvelope({
    token,
    objectType: 'QueryDefinition',
    properties: [
      'ObjectID',
      'CustomerKey',
      'Name',
      'Description',
      'QueryText',
      'TargetUpdateType',
      'Status',
      'CreatedDate',
      'ModifiedDate'
    ],
    filter
  });
  const xml = await ctx.client.soap({ soapAction: 'Retrieve', envelope, accountId: ctx.resolveAccountId(input.bu) });
  const res = parseRetrieveResponse(xml);
  return { returned: res.results.length, rows: res.results };
}

/**
 * sfmc_execute_query_definition
 * Start a QueryDefinition asynchronously. Results will be written to the
 * configured target Data Extension when the query completes. Use
 * sfmc_get_query_definition to poll Status (Running → Complete/Error).
 */
export async function executeQueryDefinition(
  ctx: SfmcToolContext,
  input: ExecuteQueryDefinitionInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const envelope = buildPerformEnvelope({
    token,
    objectType: 'QueryDefinition',
    objectId: input.objectId,
    customerKey: input.customerKey,
    action: 'start'
  });
  const xml = await ctx.client.soap({ soapAction: 'Perform', envelope, accountId: ctx.resolveAccountId(input.bu) });
  const res = parsePerformResponse(xml);
  return {
    status: res.overallStatus,
    taskId: res.taskId,
    message:
      'Query execution started. Poll sfmc_get_query_definition for Status="Complete", then read results with sfmc_get_data_extension_rows.'
  };
}

// ─── Script Activity (SssjsActivity) ─────────────────────────────────────────

/** sfmc_manage_script_activity — create or update an SSJS/AMPscript Script Activity. */
export async function manageScriptActivity(
  ctx: SfmcToolContext,
  input: ManageScriptActivityInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const soapAction = input.action === 'create' ? 'Create' : 'Update';
  const envelope = buildSssjsActivityEnvelope({
    token,
    action: soapAction,
    objectId: input.objectId,
    customerKey: input.customerKey,
    name: input.name,
    description: input.description,
    script: input.script
  });
  const xml = await ctx.client.soap({ soapAction, envelope, accountId: ctx.resolveAccountId(input.bu) });
  const res = parseMutateResponse(xml, soapAction);
  const r = res.results[0];
  return {
    status: res.overallStatus,
    objectId: r?.objectId,
    customerKey: r?.customerKey ?? input.customerKey,
    message: `Script Activity ${input.action}d.`
  };
}

// ─── Data Extract Activity ───────────────────────────────────────────────────

/** sfmc_manage_data_extract_activity — create or update a Data Extract Activity. */
export async function manageDataExtractActivity(
  ctx: SfmcToolContext,
  input: ManageDataExtractActivityInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const soapAction = input.action === 'create' ? 'Create' : 'Update';
  const envelope = buildDataExtractActivityEnvelope({
    token,
    action: soapAction,
    objectId: input.objectId,
    customerKey: input.customerKey,
    name: input.name,
    description: input.description,
    extractDefinitionTemplateKey: input.extractDefinitionTemplateKey,
    parameters: input.parameters
  });
  const xml = await ctx.client.soap({ soapAction, envelope, accountId: ctx.resolveAccountId(input.bu) });
  const res = parseMutateResponse(xml, soapAction);
  const r = res.results[0];
  return {
    status: res.overallStatus,
    objectId: r?.objectId,
    customerKey: r?.customerKey ?? input.customerKey,
    message: `Data Extract Activity ${input.action}d.`
  };
}

// ─── File Transfer Activity ──────────────────────────────────────────────────

/** sfmc_manage_file_transfer_activity — create or update a File Transfer Activity. */
export async function manageFileTransferActivity(
  ctx: SfmcToolContext,
  input: ManageFileTransferActivityInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const soapAction = input.action === 'create' ? 'Create' : 'Update';
  const envelope = buildFileTransferActivityEnvelope({
    token,
    action: soapAction,
    objectId: input.objectId,
    customerKey: input.customerKey,
    name: input.name,
    description: input.description,
    fileSpec: input.fileSpec,
    fileTransferLocationKey: input.fileTransferLocationKey,
    moveCompleted: input.moveCompleted
  });
  const xml = await ctx.client.soap({ soapAction, envelope, accountId: ctx.resolveAccountId(input.bu) });
  const res = parseMutateResponse(xml, soapAction);
  const r = res.results[0];
  return {
    status: res.overallStatus,
    objectId: r?.objectId,
    customerKey: r?.customerKey ?? input.customerKey,
    message: `File Transfer Activity ${input.action}d.`
  };
}

// ─── Import Definition ───────────────────────────────────────────────────────

/** sfmc_manage_import_definition — create or update an Import Definition for bulk file imports. */
export async function manageImportDefinition(
  ctx: SfmcToolContext,
  input: ManageImportDefinitionInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const soapAction = input.action === 'create' ? 'Create' : 'Update';
  const envelope = buildImportDefinitionEnvelope({
    token,
    action: soapAction,
    objectId: input.objectId,
    customerKey: input.customerKey,
    name: input.name,
    description: input.description,
    targetDeKey: input.targetDeKey,
    fileSpec: input.fileSpec,
    fileType: input.fileType,
    fieldMappingType: input.fieldMappingType,
    updateType: input.updateType,
    maxFileAge: input.maxFileAge,
    ftpLocationKey: input.ftpLocationKey,
    allowErrors: input.allowErrors
  });
  const xml = await ctx.client.soap({ soapAction, envelope, accountId: ctx.resolveAccountId(input.bu) });
  const res = parseMutateResponse(xml, soapAction);
  const r = res.results[0];
  return {
    status: res.overallStatus,
    objectId: r?.objectId,
    customerKey: r?.customerKey ?? input.customerKey,
    message: `Import Definition ${input.action}d.`
  };
}

/**
 * sfmc_trigger_bulk_import
 * Start an existing Import Definition immediately. The import file must
 * already be present on the configured FTP retrieve location.
 */
export async function triggerBulkImport(
  ctx: SfmcToolContext,
  input: TriggerBulkImportInput
): Promise<unknown> {
  const token = await ctx.client.getAccessToken(ctx.resolveAccountId(input.bu));
  const envelope = buildPerformEnvelope({
    token,
    objectType: 'ImportDefinition',
    objectId: input.objectId,
    customerKey: input.customerKey,
    action: 'start'
  });
  const xml = await ctx.client.soap({ soapAction: 'Perform', envelope, accountId: ctx.resolveAccountId(input.bu) });
  const res = parsePerformResponse(xml);
  return {
    status: res.overallStatus,
    taskId: res.taskId,
    message: 'Import started. The CSV/TAB file must already be on the configured FTP location.'
  };
}
