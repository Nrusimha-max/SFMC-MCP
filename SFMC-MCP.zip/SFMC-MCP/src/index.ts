#!/usr/bin/env node
/**
 * MCP server entry point — wires SFMC + Datorama tools onto a stdio
 * transport. stdout is reserved for the MCP protocol stream; all logs
 * go to stderr.
 */
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema
} from '@modelcontextprotocol/sdk/types.js';
import dotenv from 'dotenv';
import { savedAccounts } from './advanced/accounts.js';
import { AdvancedRuntime, type RuntimeTool } from './advanced/runtime.js';
import { READ_TOOLS } from './advanced/policy.js';
import { z, ZodError, type ZodType } from 'zod';
import { zodToJsonSchema } from 'zod-to-json-schema';

import { DatoramaAuth, type DatoramaRegion } from './auth/datorama-auth.js';
import { SfmcAuth } from './auth/sfmc-auth.js';
import { DatoramaClient } from './datorama/client.js';
import * as datoramaTools from './datorama/tools.js';
import { createLogger, rootLogger } from './logger.js';
import {
  CreateCalculatedMeasurementInput,
  CreateDashboardInput,
  CreateWidgetInput,
  DeleteCalculatedMeasurementInput,
  DeleteDashboardInput,
  DeleteWidgetInput,
  ExportDashboardDataInput,
  GetCalculatedMeasurementInput,
  GetDashboardInput,
  GetDataStreamInput,
  GetWidgetInput,
  GetWorkspaceInput,
  ListCalculatedMeasurementsInput,
  ListDashboardsInput,
  ListDataStreamsInput,
  ListDimensionsInput,
  ListMeasurementsInput,
  ListReportsInput,
  ListWidgetsInput,
  ListWorkspacesInput,
  RunQueryInput,
  UpdateCalculatedMeasurementInput,
  UpdateWidgetInput
} from './schemas/datorama.js';
import {
  AlterDataExtensionInput,
  AssignRoleInput,
  AutomationActionInput,
  CloneAssetInput,
  CreateAssetInput,
  CreateAutomationInput,
  CreateDataExtensionInput,
  CreateJourneyInput,
  CreateListInput,
  CreateQueryDefinitionInput,
  CreateUserInput,
  DeleteAssetInput,
  DeleteAutomationInput,
  DeleteContactInput,
  DeleteDataExtensionInput,
  DeleteDeRowsInput,
  ExportDataExtensionInput,
  DeleteQueryDefinitionInput,
  DeleteSubscriberInput,
  ExecuteQueryDefinitionInput,
  FireAutomationInput,
  GetAssetInput,
  DebugSoapAutomationInput,
  GetAutomationByNameInput,
  GetAutomationHistoryInput,
  GetCloudpageUrlInput,
  GetAutomationInput,
  ListAutomationsSoapInput,
  GetContactInput,
  GetDataExtensionRowsInput,
  GetEinsteinStoScoreInput,
  GetEmailSendSummaryInput,
  GetJourneyInput,
  GetJourneyActivityInput,
  GetJourneyGraphInput,
  GetJourneyMetricsInput,
  GetQueryDefinitionInput,
  GetSubscriberInput,
  GetSubscriberSendHistoryInput,
  JourneyActionInput,
  ListAssetsInput,
  ListAutomationsInput,
  ListDataExtensionsInput,
  ListJourneysInput,
  ListListsInput,
  ListSubscribersInput,
  ListUsersInput,
  ManageDataExtractActivityInput,
  ManageFileTransferActivityInput,
  ManageFolderInput,
  ManageImportDefinitionInput,
  ManageCloudpageCollectionInput,
  ManageListSubscriptionInput,
  ManageScriptActivityInput,
  MoveAssetInput,
  PublishCloudpageInput,
  QueryDataViewInput,
  QuerySoapInput,
  RenameDataExtensionInput,
  RevokeRoleInput,
  UnpublishCloudpageInput,
  SendTriggeredEmailInput,
  TriggerBulkImportInput,
  UpdateAssetInput,
  UpdateAutomationInput,
  UpdateJourneyInput,
  UpdateQueryDefinitionInput,
  UpdateUserInput,
  UpsertContactInput,
  UpsertDataExtensionRowsInput,
  UpsertSubscriberInput
} from './schemas/sfmc.js';
import * as activitiesTools from './sfmc/activities.js';
import * as automationTools from './sfmc/automation.js';
import { SfmcClient } from './sfmc/client.js';
import * as contentTools from './sfmc/content.js';
import * as contactTools from './sfmc/contacts.js';
import * as sfmcTools from './sfmc/tools.js';
import * as subscriberTools from './sfmc/subscribers.js';
import { errorToShape, runTool, toMcpResult } from './utils/response.js';

dotenv.config();

interface ToolDef<T extends ZodType> {
  name: string;
  description: string;
  schema: T;
  handler: (input: z.infer<T>) => Promise<unknown>;
}

function defineTool<T extends ZodType>(t: ToolDef<T>): ToolDef<T> {
  return t;
}

function requireEnv(name: string): string {
  const v = process.env[name];
  if (!v || v.trim() === '') {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return v;
}

function parseRegion(v: string | undefined): DatoramaRegion {
  const r = (v ?? 'us').toLowerCase();
  if (r === 'us' || r === 'eu' || r === 'ap') return r;
  throw new Error(`DATORAMA_REGION must be one of us|eu|ap (got: ${v})`);
}

async function main(): Promise<void> {
  const logger = rootLogger;
  logger.info('booting mcp-sfmc-datorama');

  // ------------------------------------------------------------------ SFMC
  const sfmcLogger = createLogger('sfmc');
  const saved = process.env.SFMC_USE_SAVED_CONFIG === '1' ? savedAccounts() : undefined;
  const primary = saved?.[0];
  const sfmcAuth = new SfmcAuth({
    subdomain: primary?.subdomain ?? requireEnv('SFMC_SUBDOMAIN'),
    clientId: primary?.clientId ?? requireEnv('SFMC_CLIENT_ID'),
    clientSecret: primary?.clientSecret ?? requireEnv('SFMC_CLIENT_SECRET'),
    accountId: primary?.accountId ?? requireEnv('SFMC_ACCOUNT_ID'), logger: sfmcLogger,
    refreshTokenPath: primary?.refreshTokenPath
  });
  const production = saved?.find((account, index) => index > 0 && /^(prod|production)$/i.test(account.name));
  const sfmcProdAccountId = saved ? production?.accountId : process.env.SFMC_PROD_ACCOUNT_ID?.trim();
  const sfmcProdClientId = saved ? production?.clientId : process.env.SFMC_PROD_CLIENT_ID?.trim();
  const sfmcProdClientSecret = saved ? production?.clientSecret : process.env.SFMC_PROD_CLIENT_SECRET?.trim();
  const buAuthMap = new Map<string, SfmcAuth>();
  if (sfmcProdAccountId && sfmcProdClientId && sfmcProdClientSecret) {
    buAuthMap.set(sfmcProdAccountId, new SfmcAuth({
      subdomain: production?.subdomain ?? primary?.subdomain ?? requireEnv('SFMC_SUBDOMAIN'),
      clientId: sfmcProdClientId, clientSecret: sfmcProdClientSecret,
      accountId: sfmcProdAccountId, logger: sfmcLogger
    }));
  }
  for (const account of saved ?? []) {
    if (account === primary) continue;
    if (!account.accountId) throw new Error('Additional saved business units need an account ID');
    buAuthMap.set(account.accountId, new SfmcAuth({ ...account, logger: sfmcLogger }));
  }
  const sfmcClient = new SfmcClient({
    auth: sfmcAuth, logger: sfmcLogger,
    subdomain: primary?.subdomain ?? requireEnv('SFMC_SUBDOMAIN'),
    restBaseUrl: saved ? undefined : process.env.SFMC_REST_BASE_URL,
    soapEndpoint: saved ? undefined : process.env.SFMC_SOAP_ENDPOINT, buAuthMap
  });
  const sfmcCtx = {
    client: sfmcClient, logger: sfmcLogger,
    resolveAccountId: (bu: string): string | undefined => {
      if (!bu || bu === 'test' || bu === primary?.name) return undefined;
      const account = saved?.find(a => a.name === bu || a.accountId === bu);
      if (account) return account === primary ? undefined : account.accountId;
      if (bu === 'prod' && sfmcProdAccountId) return sfmcProdAccountId;
      throw new Error('Business unit is not configured; use sfmc_business_units for supported names');
    }
  };
  const accountSummary = saved ? saved.map((a, index) => ({ alias: index === 0 ? 'test' : a === production ? 'prod' : a.name, name: a.name, accountId: a.accountId }))
    : [{ alias: 'test', name: 'Default', accountId: process.env.SFMC_ACCOUNT_ID! }, ...(sfmcProdAccountId ? [{ alias: 'prod', name: 'Production', accountId: sfmcProdAccountId }] : [])];

  // -------------------------------------------------------------- Datorama
  const datoramaLogger = createLogger('datorama');
  const datoramaAuth = new DatoramaAuth({
    apiToken: process.env.DATORAMA_API_TOKEN,
    serviceAccountId: process.env.DATORAMA_SERVICE_ACCOUNT_ID,
    privateKey: process.env.DATORAMA_PRIVATE_KEY,
    discoveryEndpoint: process.env.DATORAMA_DISCOVERY_ENDPOINT,
    region: parseRegion(process.env.DATORAMA_REGION),
    logger: datoramaLogger
  });
  const datoramaClient = new DatoramaClient({ auth: datoramaAuth, logger: datoramaLogger });
  const datoramaCtx = {
    client: datoramaClient,
    defaultWorkspaceId: process.env.DATORAMA_WORKSPACE_ID,
    logger: datoramaLogger
  };

  // ------------------------------------------------------------- Tool table
  const tools: RuntimeTool[] = [
    defineTool({
      name: 'sfmc_list_data_extensions',
      description:
        'List Salesforce Marketing Cloud Data Extensions in the configured account, with row counts (best effort, first 25), created/modified dates, and sendable flag.',
      schema: ListDataExtensionsInput,
      handler: (i) => sfmcTools.listDataExtensions(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_get_data_extension_rows',
      description:
        'Fetch rows from a Data Extension by external key, with $top/$skip pagination and optional OData $filter and $orderby.',
      schema: GetDataExtensionRowsInput,
      handler: (i) => sfmcTools.getDataExtensionRows(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_upsert_data_extension_rows',
      description:
        'Asynchronously upsert rows into a Data Extension via /data/v2/async/dataextensions. Returns a requestId for status polling.',
      schema: UpsertDataExtensionRowsInput,
      handler: (i) => sfmcTools.upsertDataExtensionRows(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_query_soap',
      description:
        'Raw SOAP Retrieve for SFMC objects not covered by REST (Subscriber, BounceEvent, OpenEvent, ClickEvent, Send, List, etc.). Supports SimpleFilterPart and auto-paginates via ContinueRequest.',
      schema: QuerySoapInput,
      handler: (i) => sfmcTools.querySoap(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_list_journeys',
      description:
        'List Journey Builder interactions, optionally filtered by status and name substring.',
      schema: ListJourneysInput,
      handler: (i) => sfmcTools.listJourneys(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_get_journey',
      description: 'Fetch a full journey definition by interaction ID and optional version.',
      schema: GetJourneyInput,
      handler: (i) => sfmcTools.getJourney(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_get_journey_graph',
      description: 'Return every Journey Builder activity as a compact node and edge graph for safe review and change planning.',
      schema: GetJourneyGraphInput,
      handler: (i) => contactTools.getJourneyGraph(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_get_journey_activity',
      description: 'Fetch one complete Journey Builder activity by key, including configuration needed for safe cloning or replacement.',
      schema: GetJourneyActivityInput,
      handler: (i) => contactTools.getJourneyActivity(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_send_triggered_email',
      description:
        'Fire a Triggered Send by external key for one or more subscribers, with optional personalization attributes.',
      schema: SendTriggeredEmailInput,
      handler: (i) => sfmcTools.sendTriggeredEmail(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_get_email_send_summary',
      description:
        'Aggregate email send statistics (sends, delivered, opens, clicks, bounces, unsubs) for a specific SendID or a SendDate range.',
      schema: GetEmailSendSummaryInput,
      handler: (i) => sfmcTools.getEmailSendSummary(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_create_data_extension',
      description:
        'Create a new Data Extension with a defined schema (fields, types, primary keys), optional folder placement, sendable relationship, and retention policy.',
      schema: CreateDataExtensionInput,
      handler: (i) => sfmcTools.createDataExtension(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_alter_data_extension',
      description:
        'Modify an existing Data Extension: add or remove fields, change field length/default/required, and update DE-level properties such as name, folder (categoryId), sendable relationship, or retention policy.',
      schema: AlterDataExtensionInput,
      handler: (i) => sfmcTools.alterDataExtension(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_delete_data_extension',
      description:
        'Permanently delete a Data Extension by its CustomerKey (External Key). This is irreversible — all rows and schema are removed. Confirm the key before calling.',
      schema: DeleteDataExtensionInput,
      handler: (i) => sfmcTools.deleteDataExtension(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_manage_folder',
      description:
        'Create a new Data Extension folder, rename an existing folder, or move a folder to a different parent. Use sfmc_list_data_extensions with categoryId to list DEs inside a folder.',
      schema: ManageFolderInput,
      handler: (i) => sfmcTools.manageFolder(sfmcCtx, i)
    }),

    // ── Automation Studio ──────────────────────────────────────────────────
    defineTool({
      name: 'sfmc_list_automations',
      description: 'List Automation Studio automations with optional name and status filters.',
      schema: ListAutomationsInput,
      handler: (i) => automationTools.listAutomations(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_get_automation',
      description: 'Fetch full automation definition (steps, schedule, activity history) by automation ID.',
      schema: GetAutomationInput,
      handler: (i) => automationTools.getAutomation(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_create_automation',
      description: 'Create a new Automation Studio automation with steps and an optional schedule.',
      schema: CreateAutomationInput,
      handler: (i) => automationTools.createAutomation(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_update_automation',
      description: 'Update an existing automation: rename, change description, or modify its schedule.',
      schema: UpdateAutomationInput,
      handler: (i) => automationTools.updateAutomation(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_delete_automation',
      description: 'Permanently delete an Automation Studio automation by ID.',
      schema: DeleteAutomationInput,
      handler: (i) => automationTools.deleteAutomation(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_automation_action',
      description: 'Start or stop an Automation Studio automation run.',
      schema: AutomationActionInput,
      handler: (i) => automationTools.automationAction(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_fire_automation',
      description:
        'Trigger an immediate one-off run of an automation using the actions/start endpoint. Unlike sfmc_automation_action this does not toggle the schedule — it fires a single run now.',
      schema: FireAutomationInput,
      handler: (i) => automationTools.fireAutomation(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_get_automation_history',
      description: 'List past run records (activity history) for an Automation Studio automation.',
      schema: GetAutomationHistoryInput,
      handler: (i) => automationTools.getAutomationHistory(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_get_automation_soap',
      description:
        'Fetch a single automation by exact name via SOAP, returning all steps and activities. Use this instead of sfmc_get_automation when the REST API returns a 596 error. Returns step names, activity names, types (SQL Query, Email Send, Script, etc.), and CustomerKeys.',
      schema: GetAutomationByNameInput,
      handler: (i) => automationTools.getAutomationByNameSoap(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_list_automations_soap',
      description:
        'List Automation Studio automations via SOAP. Use this instead of sfmc_list_automations when the REST API returns a 596 error. Supports optional name substring filter.',
      schema: ListAutomationsSoapInput,
      handler: (i) => automationTools.listAutomationsSoap(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_debug_soap_automation',
      description:
        'Return the raw SFMC SOAP XML response for an Automation Retrieve (first 3000 characters). Use this to diagnose why sfmc_list_automations_soap returns wrong results or no results.',
      schema: DebugSoapAutomationInput,
      handler: (i) => automationTools.debugSoapAutomation(sfmcCtx, i)
    }),

    // ── Content Builder / Email Studio ────────────────────────────────────
    defineTool({
      name: 'sfmc_list_assets',
      description:
        'List Content Builder assets — emails, templates, content blocks, images, or CloudPages. Supports type filter, name search, and folder (categoryId) filter.',
      schema: ListAssetsInput,
      handler: (i) => contentTools.listAssets(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_get_asset',
      description: 'Fetch full Content Builder asset definition (including HTML content and views) by asset ID.',
      schema: GetAssetInput,
      handler: (i) => contentTools.getAsset(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_create_asset',
      description:
        'Create a Content Builder asset — email (207/209), template (4), HTML content block (196), CloudPage (329), or any other asset type.',
      schema: CreateAssetInput,
      handler: (i) => contentTools.createAsset(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_update_asset',
      description: 'Update an existing Content Builder asset: name, content, views, or metadata.',
      schema: UpdateAssetInput,
      handler: (i) => contentTools.updateAsset(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_delete_asset',
      description: 'Permanently delete a Content Builder asset by ID.',
      schema: DeleteAssetInput,
      handler: (i) => contentTools.deleteAsset(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_clone_asset',
      description:
        'Duplicate an existing Content Builder asset by ID. The clone gets a new name and optionally a different folder. Useful for creating email variants or template copies.',
      schema: CloneAssetInput,
      handler: (i) => contentTools.cloneAsset(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_move_asset',
      description: 'Move a Content Builder asset to a different folder (category) without changing any other property.',
      schema: MoveAssetInput,
      handler: (i) => contentTools.moveAsset(sfmcCtx, i)
    }),

    // ── CloudPage Operations ──────────────────────────────────────────────
    defineTool({
      name: 'sfmc_publish_cloudpage',
      description:
        'Publish a CloudPage asset (type 329) via the Content Builder API. Returns the live publishedURL from fileProperties.',
      schema: PublishCloudpageInput,
      handler: (i) => contentTools.publishCloudpage(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_unpublish_cloudpage',
      description: 'Unpublish a CloudPage, taking it offline without deleting the asset or its content.',
      schema: UnpublishCloudpageInput,
      handler: (i) => contentTools.unpublishCloudpage(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_get_cloudpage_url',
      description:
        'Fetch the live published URL of a CloudPage from its asset definition (fileProperties.publishedURL). Returns null if not yet published.',
      schema: GetCloudpageUrlInput,
      handler: (i) => contentTools.getCloudpageUrl(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_manage_cloudpage_collection',
      description:
        'Create, rename/move, or delete a CloudPage collection (category folder) via the Content Builder API.',
      schema: ManageCloudpageCollectionInput,
      handler: (i) => contentTools.manageCloudpageCollection(sfmcCtx, i)
    }),

    // ── Contact Builder ───────────────────────────────────────────────────
    defineTool({
      name: 'sfmc_get_contact',
      description: 'Retrieve all attribute set values for a contact by contact key.',
      schema: GetContactInput,
      handler: (i) => contactTools.getContact(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_upsert_contact',
      description: 'Create or update a contact record in Contact Builder with attribute set values.',
      schema: UpsertContactInput,
      handler: (i) => contactTools.upsertContact(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_delete_contact',
      description: 'Delete a contact and optionally all associated attributes from Contact Builder.',
      schema: DeleteContactInput,
      handler: (i) => contactTools.deleteContact(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_list_contact_attribute_groups',
      description: 'List all attribute groups and their attributes in the Contact Builder data model.',
      schema: z.object({}).strict(),
      handler: () => contactTools.listContactAttributeGroups(sfmcCtx)
    }),

    // ── Journey Builder Extensions ────────────────────────────────────────
    defineTool({
      name: 'sfmc_create_journey',
      description: 'Create a new Journey Builder interaction (saved as Draft). Provide name, triggers, activities, and goals.',
      schema: CreateJourneyInput,
      handler: (i) => contactTools.createJourney(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_update_journey',
      description: 'Update an existing journey definition — modify activities, triggers, goals, or rename.',
      schema: UpdateJourneyInput,
      handler: (i) => contactTools.updateJourney(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_journey_action',
      description: 'Publish, stop, pause, or resume a Journey Builder interaction.',
      schema: JourneyActionInput,
      handler: (i) => contactTools.journeyAction(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_get_journey_metrics',
      description:
        'Fetch performance metrics for a Journey Builder interaction — population counts, goal conversion rates, and activity-level statistics.',
      schema: GetJourneyMetricsInput,
      handler: (i) => contactTools.getJourneyMetrics(sfmcCtx, i)
    }),

    // ── Subscriber & List Management ──────────────────────────────────────
    defineTool({
      name: 'sfmc_list_subscribers',
      description: 'List All Subscribers via SOAP, with optional email, status, and list ID filters.',
      schema: ListSubscribersInput,
      handler: (i) => subscriberTools.listSubscribers(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_get_subscriber',
      description: 'Look up a single subscriber by email address or subscriber key.',
      schema: GetSubscriberInput,
      handler: (i) => subscriberTools.getSubscriber(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_upsert_subscriber',
      description: 'Create or update a subscriber — set status, list memberships, and profile attributes.',
      schema: UpsertSubscriberInput,
      handler: (i) => subscriberTools.upsertSubscriber(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_delete_subscriber',
      description: 'Delete a subscriber from All Subscribers by email or subscriber key.',
      schema: DeleteSubscriberInput,
      handler: (i) => subscriberTools.deleteSubscriber(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_list_lists',
      description: 'List SFMC publication, suppression, and standard lists.',
      schema: ListListsInput,
      handler: (i) => subscriberTools.listLists(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_create_list',
      description: 'Create a new SFMC subscriber list (standard, publication, or suppression).',
      schema: CreateListInput,
      handler: (i) => subscriberTools.createList(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_manage_list_subscription',
      description: 'Subscribe or unsubscribe one or more email addresses to/from a list.',
      schema: ManageListSubscriptionInput,
      handler: (i) => subscriberTools.manageListSubscription(sfmcCtx, i)
    }),

    // ── User & Account Management ─────────────────────────────────────────
    defineTool({
      name: 'sfmc_list_users',
      description: 'List SFMC account users with optional name, email, and active-status filters.',
      schema: ListUsersInput,
      handler: (i) => subscriberTools.listUsers(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_create_user',
      description: 'Create a new SFMC account user with login credentials.',
      schema: CreateUserInput,
      handler: (i) => subscriberTools.createUser(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_update_user',
      description: 'Update an existing SFMC account user — lock/unlock, reset password flag, or change notification email.',
      schema: UpdateUserInput,
      handler: (i) => subscriberTools.updateUser(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_assign_role',
      description: 'Assign a role to an SFMC account user by roleId or role name.',
      schema: AssignRoleInput,
      handler: (i) => subscriberTools.assignRole(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_revoke_role',
      description: 'Revoke (remove) a role from an SFMC account user by roleId or role name.',
      schema: RevokeRoleInput,
      handler: (i) => subscriberTools.revokeRole(sfmcCtx, i)
    }),

    // ── Reports & Analytics ───────────────────────────────────────────────
    defineTool({
      name: 'sfmc_query_data_view',
      description:
        'Query SFMC system data views via SOAP: _Sent, _Open, _Click, _Bounce, _Unsubscribe, _Complaint, _Job, _Subscriber, _ListSubscribers, _BusinessUnitUnsubscribes.',
      schema: QueryDataViewInput,
      handler: (i) => subscriberTools.queryDataView(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_get_subscriber_send_history',
      description:
        'Retrieve per-send records (email sends, clicks, opens) for a specific subscriber key via the REST data API.',
      schema: GetSubscriberSendHistoryInput,
      handler: (i) => subscriberTools.getSubscriberSendHistory(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_get_einstein_sto_score',
      description:
        'Retrieve Einstein Send Time Optimization scores for a subscriber or account-level defaults. Returns recommended send windows.',
      schema: GetEinsteinStoScoreInput,
      handler: (i) => subscriberTools.getEinsteinStoScore(sfmcCtx, i)
    }),

    // ── SQL Query Activity ────────────────────────────────────────────────
    defineTool({
      name: 'sfmc_create_query_definition',
      description:
        'Create a SQL Query Activity (QueryDefinition) that writes results to a target Data Extension. Use queryText to query system data views (_Sent, _Open, _Click, _Bounce, _Unsubscribe, _Complaint) or any DE. Execute with sfmc_execute_query_definition; read results with sfmc_get_data_extension_rows.',
      schema: CreateQueryDefinitionInput,
      handler: (i) => activitiesTools.createQueryDefinition(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_update_query_definition',
      description: 'Update an existing SQL Query Activity — change queryText, target DE, or updateType.',
      schema: UpdateQueryDefinitionInput,
      handler: (i) => activitiesTools.updateQueryDefinition(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_get_query_definition',
      description: 'Retrieve a SQL Query Activity definition and its current Status (Ready, Running, Complete, Error).',
      schema: GetQueryDefinitionInput,
      handler: (i) => activitiesTools.getQueryDefinition(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_delete_query_definition',
      description: 'Permanently delete a SQL Query Activity by ObjectID or CustomerKey.',
      schema: DeleteQueryDefinitionInput,
      handler: (i) => activitiesTools.deleteQueryDefinition(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_execute_query_definition',
      description:
        'Start a SQL Query Activity asynchronously. Results are written to the configured target DE when complete. Poll sfmc_get_query_definition for Status; read results with sfmc_get_data_extension_rows.',
      schema: ExecuteQueryDefinitionInput,
      handler: (i) => activitiesTools.executeQueryDefinition(sfmcCtx, i)
    }),

    // ── Script / Data Extract / File Transfer / Import Activities ─────────
    defineTool({
      name: 'sfmc_manage_script_activity',
      description: 'Create or update an SSJS / AMPscript Script Activity (SssjsActivity) in Automation Studio.',
      schema: ManageScriptActivityInput,
      handler: (i) => activitiesTools.manageScriptActivity(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_manage_data_extract_activity',
      description: 'Create or update a Data Extract Activity with a template key and parameters (Delimiter, HasColumnHeaders, etc.).',
      schema: ManageDataExtractActivityInput,
      handler: (i) => activitiesTools.manageDataExtractActivity(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_manage_file_transfer_activity',
      description: 'Create or update a File Transfer Activity that moves files to/from an FTP or SFTP location.',
      schema: ManageFileTransferActivityInput,
      handler: (i) => activitiesTools.manageFileTransferActivity(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_manage_import_definition',
      description: 'Create or update an Import Definition that imports a CSV/TAB file from FTP into a Data Extension.',
      schema: ManageImportDefinitionInput,
      handler: (i) => activitiesTools.manageImportDefinition(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_trigger_bulk_import',
      description:
        'Start an Import Definition immediately (bulk subscriber import). The file must already be on the configured FTP retrieve location.',
      schema: TriggerBulkImportInput,
      handler: (i) => activitiesTools.triggerBulkImport(sfmcCtx, i)
    }),

    // ── Additional Data Extension Operations ──────────────────────────────
    defineTool({
      name: 'sfmc_export_data_extension',
      description:
        'Export ALL rows from a Data Extension to a CSV file on disk. Automatically paginates through all records (2 500 per page) and writes to the specified outputPath. Use this instead of sfmc_get_data_extension_rows when you need the complete dataset as a downloadable file.',
      schema: ExportDataExtensionInput,
      handler: (i) => sfmcTools.exportDataExtension(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_delete_data_extension_rows',
      description:
        'Asynchronously delete rows from a Data Extension via the REST async API. Provide an OData $filter to delete matching rows; omit it to delete all rows.',
      schema: DeleteDeRowsInput,
      handler: (i) => sfmcTools.deleteDataExtensionRows(sfmcCtx, i)
    }),
    defineTool({
      name: 'sfmc_rename_data_extension',
      description: 'Rename a Data Extension in-place without changing its schema or rows.',
      schema: RenameDataExtensionInput,
      handler: (i) => sfmcTools.renameDataExtension(sfmcCtx, i)
    }),

    // ── Datorama Workspaces ───────────────────────────────────────────────
    defineTool({
      name: 'datorama_list_workspaces',
      description: 'List all Datorama workspaces accessible by the configured credentials.',
      schema: ListWorkspacesInput,
      handler: (i) => datoramaTools.listWorkspaces(datoramaCtx, i)
    }),
    defineTool({
      name: 'datorama_get_workspace',
      description: 'Fetch full details for a single Datorama workspace — account info, timezone, currency, theme.',
      schema: GetWorkspaceInput,
      handler: (i) => datoramaTools.getWorkspace(datoramaCtx, i)
    }),

    // ── Datorama Measurements & Dimensions ────────────────────────────────
    defineTool({
      name: 'datorama_list_measurements',
      description:
        'List all measurements (metrics) available in a Datorama workspace — system names, display names, aggregation types, and whether they are calculated. Use system names in datorama_run_query.',
      schema: ListMeasurementsInput,
      handler: (i) => datoramaTools.listMeasurements(datoramaCtx, i)
    }),
    defineTool({
      name: 'datorama_list_dimensions',
      description:
        'List all dimensions (grouping fields) available in a Datorama workspace — system names, display names, and filter capability. Use system names in datorama_run_query.',
      schema: ListDimensionsInput,
      handler: (i) => datoramaTools.listDimensions(datoramaCtx, i)
    }),

    // ── Datorama Calculated Measurements ─────────────────────────────────
    defineTool({
      name: 'datorama_list_calculated_measurements',
      description: 'List all calculated measurements in a workspace — id, name, formula expression, format, and audit info.',
      schema: ListCalculatedMeasurementsInput,
      handler: (i) => datoramaTools.listCalculatedMeasurements(datoramaCtx, i)
    }),
    defineTool({
      name: 'datorama_get_calculated_measurement',
      description: 'Fetch a single calculated measurement by its numeric ID — formula expression, format, precision, and audit info.',
      schema: GetCalculatedMeasurementInput,
      handler: (i) => datoramaTools.getCalculatedMeasurement(datoramaCtx, i)
    }),
    defineTool({
      name: 'datorama_create_calculated_measurement',
      description: 'Create a new calculated measurement in a workspace with a formula expression using measurement system names.',
      schema: CreateCalculatedMeasurementInput,
      handler: (i) => datoramaTools.createCalculatedMeasurement(datoramaCtx, i)
    }),
    defineTool({
      name: 'datorama_update_calculated_measurement',
      description: 'Update an existing calculated measurement — change the formula, display name, format, or precision.',
      schema: UpdateCalculatedMeasurementInput,
      handler: (i) => datoramaTools.updateCalculatedMeasurement(datoramaCtx, i)
    }),
    defineTool({
      name: 'datorama_delete_calculated_measurement',
      description: 'Permanently delete a calculated measurement from a workspace by its numeric ID.',
      schema: DeleteCalculatedMeasurementInput,
      handler: (i) => datoramaTools.deleteCalculatedMeasurement(datoramaCtx, i)
    }),

    // ── Datorama Dashboards ───────────────────────────────────────────────
    defineTool({
      name: 'datorama_list_dashboards',
      description: 'List dashboards in a workspace, with owner, created/updated dates, and optional name/owner filters.',
      schema: ListDashboardsInput,
      handler: (i) => datoramaTools.listDashboards(datoramaCtx, i)
    }),
    defineTool({
      name: 'datorama_get_dashboard',
      description: 'Fetch full definition of a single Datorama dashboard by ID — theme, ordinal, audit info.',
      schema: GetDashboardInput,
      handler: (i) => datoramaTools.getDashboard(datoramaCtx, i)
    }),
    defineTool({
      name: 'datorama_create_dashboard',
      description: 'Create a new Datorama dashboard in a workspace with a name, optional description, and color theme.',
      schema: CreateDashboardInput,
      handler: (i) => datoramaTools.createDashboard(datoramaCtx, i)
    }),
    defineTool({
      name: 'datorama_delete_dashboard',
      description: 'Permanently delete a Datorama dashboard by ID. This is irreversible.',
      schema: DeleteDashboardInput,
      handler: (i) => datoramaTools.deleteDashboard(datoramaCtx, i)
    }),
    defineTool({
      name: 'datorama_export_dashboard_data',
      description: 'Pull underlying data for the widgets in a dashboard, optionally overriding the date range.',
      schema: ExportDashboardDataInput,
      handler: (i) => datoramaTools.exportDashboardData(datoramaCtx, i)
    }),

    // ── Datorama Data Streams ─────────────────────────────────────────────
    defineTool({
      name: 'datorama_list_data_streams',
      description: 'List data streams in a workspace — status, data source, channel, last ingestion time, and schedule.',
      schema: ListDataStreamsInput,
      handler: (i) => datoramaTools.listDataStreams(datoramaCtx, i)
    }),
    defineTool({
      name: 'datorama_get_data_stream',
      description: 'Fetch full details for a single Datorama data stream by ID — source, channel, schedule, ingestion timestamps.',
      schema: GetDataStreamInput,
      handler: (i) => datoramaTools.getDataStream(datoramaCtx, i)
    }),

    // ── Datorama Reports ──────────────────────────────────────────────────
    defineTool({
      name: 'datorama_list_reports',
      description: 'List scheduled reports in a Datorama workspace — name, linked dashboard, schedule type, and recipients.',
      schema: ListReportsInput,
      handler: (i) => datoramaTools.listReports(datoramaCtx, i)
    }),

    // ── Datorama Analytics Query ──────────────────────────────────────────
    defineTool({
      name: 'datorama_run_query',
      description:
        'Run a Datorama analytics query against a workspace with measurements, dimensions, date range, filters and ordering. Use datorama_list_measurements and datorama_list_dimensions to discover valid field names. Returns tabular JSON.',
      schema: RunQueryInput,
      handler: (i) => datoramaTools.runQuery(datoramaCtx, i)
    }),

    // ── Datorama Dashboard Widgets ────────────────────────────────────────
    defineTool({
      name: 'datorama_list_widgets',
      description: 'List all widgets (id, title, type, measurements, dimensions) inside a Datorama dashboard.',
      schema: ListWidgetsInput,
      handler: (i) => datoramaTools.listWidgets(datoramaCtx, i)
    }),
    defineTool({
      name: 'datorama_get_widget',
      description: 'Fetch a single Datorama widget definition by dashboardId and widgetId.',
      schema: GetWidgetInput,
      handler: (i) => datoramaTools.getWidget(datoramaCtx, i)
    }),
    defineTool({
      name: 'datorama_create_widget',
      description: 'Create a new widget (chart, table, metric, or filter) inside an existing Datorama dashboard.',
      schema: CreateWidgetInput,
      handler: (i) => datoramaTools.createWidget(datoramaCtx, i)
    }),
    defineTool({
      name: 'datorama_update_widget',
      description: "Update a Datorama widget's title, measurements, dimensions, or date range by dashboardId and widgetId.",
      schema: UpdateWidgetInput,
      handler: (i) => datoramaTools.updateWidget(datoramaCtx, i)
    }),
    defineTool({
      name: 'datorama_delete_widget',
      description: 'Delete a widget from a Datorama dashboard by dashboardId and widgetId.',
      schema: DeleteWidgetInput,
      handler: (i) => datoramaTools.deleteWidget(datoramaCtx, i)
    })
  ];

  const toolsByName = new Map<string, (typeof tools)[number]>();
  for (const t of tools) toolsByName.set(t.name, t);

  const runtime = new AdvancedRuntime(toolsByName, sfmcCtx, accountSummary);
  for (const tool of runtime.definitions()) { tools.push(tool); toolsByName.set(tool.name, tool); }

  // ---------------------------------------------------------- MCP plumbing
  // Using low-level Server for dynamic tool routing with full ZodEffects support.
  const server = new Server(
    { name: 'mcp-sfmc-datorama', version: '2.1.0' },
    { capabilities: { tools: {} } }
  );

  const profile = process.env.MCP_TOOL_PROFILE ?? 'full';
  if (!['full', 'discovery'].includes(profile)) throw new Error('MCP_TOOL_PROFILE must be full or discovery');
  const advancedNames = new Set(runtime.definitions().map(t => t.name));
  const readManagement = new Set(['sfmc_capabilities', 'sfmc_diagnostics', 'sfmc_business_units', 'sfmc_connection_health', 'sfmc_batch_read', 'sfmc_call_tool']);
  const advertisedTools = tools.filter(t => profile === 'full' || advancedNames.has(t.name)).map(t => ({
    name: t.name, description: t.description,
    inputSchema: zodToJsonSchema(t.schema, { target: 'jsonSchema7' }) as Record<string, unknown>,
    annotations: { readOnlyHint: READ_TOOLS.has(t.name) || readManagement.has(t.name), destructiveHint: !READ_TOOLS.has(t.name) && !readManagement.has(t.name) }
  }));
  server.setRequestHandler(ListToolsRequestSchema, async () => ({ tools: advertisedTools }));

  server.setRequestHandler(CallToolRequestSchema, async (req) => {
    const name = req.params.name;
    const tool = toolsByName.get(name);
    if (!tool) {
      return toMcpResult({
        ok: false,
        error: { status: 404, message: `Unknown tool: ${name}` }
      });
    }
    let parsed;
    try {
      parsed = tool.schema.parse(req.params.arguments ?? {});
    } catch (err) {
      if (err instanceof ZodError) {
        return toMcpResult({
          ok: false,
          error: {
            status: 400,
            message: 'Invalid tool arguments',
            details: err.flatten()
          }
        });
      }
      return toMcpResult({ ok: false, error: errorToShape(err) });
    }
    logger.debug(`call ${name}`);
    const result = await runTool(() => runtime.invoke(name, parsed));
    if (!result.ok) {
      logger.warn(`tool ${name} failed: ${result.error.status} ${result.error.message}`);
    }
    return toMcpResult(result);
  });

  const transport = new StdioServerTransport();
  await server.connect(transport);
  logger.info(`ready — ${tools.length} tools registered`);
}

main().catch((err) => {
  rootLogger.error('fatal:', (err as Error).message);
  if (process.env.DEBUG) rootLogger.debug((err as Error).stack);
  process.exit(1);
});
