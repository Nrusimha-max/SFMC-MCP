import { z } from 'zod';

/** datorama_list_workspaces */
export const ListWorkspacesInput = z.object({}).strict();
export type ListWorkspacesInput = z.infer<typeof ListWorkspacesInput>;

/** datorama_get_workspace */
export const GetWorkspaceInput = z
  .object({
    workspaceId: z.string().min(1).optional().describe('Workspace ID. Falls back to DATORAMA_WORKSPACE_ID if omitted.')
  })
  .strict();
export type GetWorkspaceInput = z.infer<typeof GetWorkspaceInput>;

/** datorama_run_query */
export const RunQueryInput = z
  .object({
    workspaceId: z
      .string()
      .min(1)
      .optional()
      .describe('Workspace ID. Falls back to DATORAMA_WORKSPACE_ID if omitted.'),
    measurements: z
      .array(z.object({ name: z.string().min(1) }).strict())
      .min(1)
      .describe('Measurements (metrics) to return. Use datorama_list_measurements to discover available names.'),
    dimensions: z
      .array(z.object({ name: z.string().min(1) }).strict())
      .default([])
      .describe('Dimensions to group by. Use datorama_list_dimensions to discover available names.'),
    dateRange: z
      .object({
        startDate: z.string().describe('YYYY-MM-DD.'),
        endDate: z.string().describe('YYYY-MM-DD.')
      })
      .strict()
      .describe('Inclusive date range.'),
    filters: z
      .array(
        z
          .object({
            field: z.string().min(1),
            operator: z.enum([
              'EQUALS',
              'NOT_EQUALS',
              'IN',
              'NOT_IN',
              'CONTAINS',
              'NOT_CONTAINS',
              'GREATER_THAN',
              'LESS_THAN',
              'GREATER_THAN_OR_EQUALS',
              'LESS_THAN_OR_EQUALS',
              'IS_NULL',
              'IS_NOT_NULL'
            ]),
            values: z.array(z.union([z.string(), z.number(), z.boolean()])).optional()
          })
          .strict()
      )
      .default([]),
    orderBy: z
      .array(
        z
          .object({
            field: z.string().min(1),
            direction: z.enum(['ASC', 'DESC']).default('DESC')
          })
          .strict()
      )
      .optional(),
    limit: z.number().int().min(1).max(10_000).default(500),
    offset: z.number().int().min(0).default(0)
  })
  .strict();
export type RunQueryInput = z.infer<typeof RunQueryInput>;

/** datorama_list_data_streams */
export const ListDataStreamsInput = z
  .object({
    workspaceId: z.string().min(1).optional(),
    status: z.enum(['ACTIVE', 'INACTIVE', 'ERROR', 'ALL']).default('ALL'),
    limit: z.number().int().min(1).max(500).default(100),
    offset: z.number().int().min(0).default(0)
  })
  .strict();
export type ListDataStreamsInput = z.infer<typeof ListDataStreamsInput>;

/** datorama_get_data_stream */
export const GetDataStreamInput = z
  .object({
    workspaceId: z.string().min(1).optional().describe('Workspace ID. Falls back to DATORAMA_WORKSPACE_ID if omitted.'),
    dataStreamId: z.string().min(1).describe('Data stream ID to fetch.')
  })
  .strict();
export type GetDataStreamInput = z.infer<typeof GetDataStreamInput>;

/** datorama_list_calculated_measurements */
export const ListCalculatedMeasurementsInput = z
  .object({
    workspaceId: z.string().min(1).optional().describe('Workspace ID. Falls back to DATORAMA_WORKSPACE_ID if omitted.')
  })
  .strict();
export type ListCalculatedMeasurementsInput = z.infer<typeof ListCalculatedMeasurementsInput>;

/** datorama_get_calculated_measurement */
export const GetCalculatedMeasurementInput = z
  .object({
    workspaceId: z.string().min(1).optional(),
    measurementId: z
      .string()
      .min(1)
      .describe('Calculated measurement ID — numeric ID returned by datorama_list_calculated_measurements.')
  })
  .strict();
export type GetCalculatedMeasurementInput = z.infer<typeof GetCalculatedMeasurementInput>;

/** datorama_create_calculated_measurement */
export const CreateCalculatedMeasurementInput = z
  .object({
    workspaceId: z.string().min(1).optional().describe('Workspace ID. Falls back to DATORAMA_WORKSPACE_ID if omitted.'),
    name: z.string().min(1).describe('Display name for the calculated measurement.'),
    expression: z.string().min(1).describe('Formula expression using measurement system names (e.g. IF(M1 == 0, 0, M2 / M1)).'),
    description: z.string().optional().describe('Optional description of the measurement.'),
    format: z.string().optional().describe('Display format, e.g. "PERCENTAGE", "NUMBER", "CURRENCY".'),
    precision: z.number().int().min(0).max(6).optional().describe('Decimal places to display.')
  })
  .strict();
export type CreateCalculatedMeasurementInput = z.infer<typeof CreateCalculatedMeasurementInput>;

/** datorama_update_calculated_measurement */
export const UpdateCalculatedMeasurementInput = z
  .object({
    workspaceId: z.string().min(1).optional(),
    measurementId: z.string().min(1).describe('ID of the calculated measurement to update.'),
    name: z.string().min(1).optional().describe('New display name.'),
    expression: z.string().min(1).optional().describe('New formula expression.'),
    description: z.string().optional(),
    format: z.string().optional(),
    precision: z.number().int().min(0).max(6).optional()
  })
  .strict()
  .refine(
    (v) => v.name !== undefined || v.expression !== undefined || v.description !== undefined || v.format !== undefined || v.precision !== undefined,
    { message: 'Specify at least one field to update.' }
  );
export type UpdateCalculatedMeasurementInput = z.infer<typeof UpdateCalculatedMeasurementInput>;

/** datorama_delete_calculated_measurement */
export const DeleteCalculatedMeasurementInput = z
  .object({
    workspaceId: z.string().min(1).optional(),
    measurementId: z.string().min(1).describe('ID of the calculated measurement to delete.')
  })
  .strict();
export type DeleteCalculatedMeasurementInput = z.infer<typeof DeleteCalculatedMeasurementInput>;

/** datorama_list_dashboards */
export const ListDashboardsInput = z
  .object({
    workspaceId: z.string().min(1).optional(),
    ownerEmail: z.string().email().optional(),
    nameContains: z.string().optional(),
    limit: z.number().int().min(1).max(500).default(100),
    offset: z.number().int().min(0).default(0)
  })
  .strict();
export type ListDashboardsInput = z.infer<typeof ListDashboardsInput>;

/** datorama_get_dashboard */
export const GetDashboardInput = z
  .object({
    dashboardId: z.string().min(1).describe('Dashboard ID to fetch.')
  })
  .strict();
export type GetDashboardInput = z.infer<typeof GetDashboardInput>;

/** datorama_create_dashboard */
export const CreateDashboardInput = z
  .object({
    workspaceId: z.string().min(1).optional().describe('Workspace ID. Falls back to DATORAMA_WORKSPACE_ID if omitted.'),
    name: z.string().min(1).describe('Dashboard display name.'),
    description: z.string().optional().describe('Optional description.'),
    uiTheme: z.enum(['WHITE_THEME', 'DARK_THEME']).default('WHITE_THEME').describe('Dashboard color theme.'),
    pageName: z.string().optional().describe('Name of the default page created inside the dashboard (used only when jsonConfig is omitted). Defaults to "Page 1".'),
    jsonConfig: z
      .union([z.string(), z.record(z.any())])
      .optional()
      .describe('Full Datorama dashboard layout config (object or JSON string). Datorama requires a non-empty config with at least one page. If omitted, a minimal valid one-page config is generated. To replicate an exact layout, capture jsonConfig from an existing dashboard and pass it here.')
  })
  .strict();
export type CreateDashboardInput = z.infer<typeof CreateDashboardInput>;

/** datorama_delete_dashboard */
export const DeleteDashboardInput = z
  .object({
    dashboardId: z.string().min(1).describe('Dashboard ID to delete.')
  })
  .strict();
export type DeleteDashboardInput = z.infer<typeof DeleteDashboardInput>;

/** datorama_export_dashboard_data */
export const ExportDashboardDataInput = z
  .object({
    workspaceId: z.string().min(1).optional(),
    dashboardId: z.string().min(1).describe('Dashboard ID to export.'),
    format: z.enum(['JSON', 'CSV']).default('JSON'),
    dateRange: z
      .object({
        startDate: z.string(),
        endDate: z.string()
      })
      .strict()
      .optional()
      .describe('Override the dashboard default date range.')
  })
  .strict();
export type ExportDashboardDataInput = z.infer<typeof ExportDashboardDataInput>;

/** datorama_list_measurements */
export const ListMeasurementsInput = z
  .object({
    workspaceId: z.string().min(1).optional().describe('Workspace ID. Falls back to DATORAMA_WORKSPACE_ID if omitted.'),
    nameContains: z.string().optional().describe('Filter by display name substring (case-insensitive).')
  })
  .strict();
export type ListMeasurementsInput = z.infer<typeof ListMeasurementsInput>;

/** datorama_list_dimensions */
export const ListDimensionsInput = z
  .object({
    workspaceId: z.string().min(1).optional().describe('Workspace ID. Falls back to DATORAMA_WORKSPACE_ID if omitted.'),
    nameContains: z.string().optional().describe('Filter by display name substring (case-insensitive).')
  })
  .strict();
export type ListDimensionsInput = z.infer<typeof ListDimensionsInput>;

/** datorama_list_reports */
export const ListReportsInput = z
  .object({
    workspaceId: z.string().min(1).optional().describe('Workspace ID. Falls back to DATORAMA_WORKSPACE_ID if omitted.'),
    limit: z.number().int().min(1).max(200).default(50),
    offset: z.number().int().min(0).default(0)
  })
  .strict();
export type ListReportsInput = z.infer<typeof ListReportsInput>;

// ─── Dashboard Widgets ────────────────────────────────────────────────────────

/** datorama_create_widget */
export const CreateWidgetInput = z
  .object({
    workspaceId: z
      .string()
      .min(1)
      .optional()
      .describe('Workspace ID. Falls back to DATORAMA_WORKSPACE_ID if omitted.'),
    dashboardId: z.string().min(1).describe('Dashboard ID to add the widget to.'),
    widgetType: z
      .enum(['chart', 'table', 'metric', 'filter', 'custom'])
      .describe('Visualization type. Use "custom" for a Custom Widget (HTML/CSS/JS).'),
    title: z.string().min(1).describe('Widget display title.'),
    measurements: z
      .array(z.object({ name: z.string().min(1) }).strict())
      .optional()
      .describe('Measurements (metrics) to display. Optional for custom widgets.'),
    custom: z
      .object({
        html: z.string().optional().describe('Custom widget HTML pane.'),
        css: z.string().optional().describe('Custom widget CSS pane.'),
        javascript: z.string().optional().describe('Custom widget JS pane.')
      })
      .strict()
      .optional()
      .describe('HTML/CSS/JS for a Custom Widget (widgetType="custom").'),
    config: z
      .record(z.any())
      .optional()
      .describe('Raw fields merged verbatim into the widget POST body — pass the exact Datorama widget payload (e.g. a captured custom-widget config) when the typed fields are not enough.'),
    dimensions: z
      .array(z.object({ name: z.string().min(1) }).strict())
      .default([])
      .describe('Dimensions to group the widget data by.'),
    dateRange: z
      .object({
        startDate: z.string().describe('YYYY-MM-DD.'),
        endDate: z.string().describe('YYYY-MM-DD.')
      })
      .strict()
      .optional()
      .describe('Override the dashboard date range for this widget only.')
  })
  .strict();
export type CreateWidgetInput = z.infer<typeof CreateWidgetInput>;

/** datorama_update_widget */
export const UpdateWidgetInput = z
  .object({
    workspaceId: z.string().min(1).optional(),
    dashboardId: z.string().min(1).describe('Dashboard ID that owns the widget.'),
    widgetId: z.string().min(1).describe('Widget ID to update.'),
    title: z.string().min(1).optional().describe('New widget title.'),
    measurements: z
      .array(z.object({ name: z.string().min(1) }).strict())
      .optional()
      .describe('Replacement measurements list.'),
    dimensions: z
      .array(z.object({ name: z.string().min(1) }).strict())
      .optional()
      .describe('Replacement dimensions list.'),
    dateRange: z
      .object({ startDate: z.string(), endDate: z.string() })
      .strict()
      .optional()
      .describe('New date range override for this widget.')
  })
  .strict()
  .refine(
    (v) =>
      v.title !== undefined ||
      v.measurements !== undefined ||
      v.dimensions !== undefined ||
      v.dateRange !== undefined,
    { message: 'Specify at least one field to update: title, measurements, dimensions, or dateRange.' }
  );
export type UpdateWidgetInput = z.infer<typeof UpdateWidgetInput>;

/** datorama_delete_widget */
export const DeleteWidgetInput = z
  .object({
    workspaceId: z.string().min(1).optional(),
    dashboardId: z.string().min(1).describe('Dashboard ID that owns the widget.'),
    widgetId: z.string().min(1).describe('Widget ID to delete.')
  })
  .strict();
export type DeleteWidgetInput = z.infer<typeof DeleteWidgetInput>;

/** datorama_get_widget */
export const GetWidgetInput = z
  .object({
    workspaceId: z.string().min(1).optional(),
    dashboardId: z.string().min(1).describe('Dashboard ID that owns the widget.'),
    widgetId: z.string().min(1).describe('Widget ID to fetch.')
  })
  .strict();
export type GetWidgetInput = z.infer<typeof GetWidgetInput>;

/** datorama_list_widgets */
export const ListWidgetsInput = z
  .object({
    workspaceId: z.string().min(1).optional(),
    dashboardId: z.string().min(1).describe('Dashboard ID whose widgets to list.')
  })
  .strict();
export type ListWidgetsInput = z.infer<typeof ListWidgetsInput>;
