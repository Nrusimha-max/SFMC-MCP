import { z } from 'zod';

export const buParam = {
  bu: z.string().min(1).max(200).default('test').describe('Configured business-unit name or alias. Use sfmc_business_units to discover exact names. Default alias: test; prod is available only when configured.')
};

/** sfmc_list_data_extensions */
export const ListDataExtensionsInput = z
  .object({
    ...buParam,
    nameContains: z
      .string()
      .optional()
      .describe('Optional case-insensitive substring filter against the DE Name.'),
    categoryId: z
      .number()
      .int()
      .optional()
      .describe('Filter by folder CategoryID. Use sfmc_manage_folder to discover folder IDs.'),
    top: z
      .number()
      .int()
      .min(1)
      .max(500)
      .default(50)
      .describe('Max number of DEs to return (1–500, default 50).'),
    skip: z.number().int().min(0).default(0).describe('Offset for pagination.')
  })
  .strict();
export type ListDataExtensionsInput = z.infer<typeof ListDataExtensionsInput>;

/** sfmc_get_data_extension_rows */
export const GetDataExtensionRowsInput = z
  .object({
    ...buParam,
    key: z.string().min(1).describe('External Key (CustomerKey) of the data extension.'),
    top: z.number().int().min(1).max(2500).default(100).describe('$top — page size.'),
    skip: z.number().int().min(0).default(0).describe('$skip — offset for pagination.'),
    filter: z
      .string()
      .optional()
      .describe(
        'OData $filter expression — e.g. "EmailAddress eq \'foo@bar.com\'" or "ModifiedDate ge 2024-01-01T00:00:00Z".'
      ),
    orderBy: z.string().optional().describe('OData $orderby expression.')
  })
  .strict();
export type GetDataExtensionRowsInput = z.infer<typeof GetDataExtensionRowsInput>;

/** sfmc_upsert_data_extension_rows */
export const UpsertDataExtensionRowsInput = z
  .object({
    ...buParam,
    key: z.string().min(1).describe('External Key of the destination data extension.'),
    rows: z
      .array(z.record(z.string(), z.unknown()))
      .min(1)
      .max(2500)
      .describe(
        'Array of row objects keyed by field name. Each row must include the DE primary key(s).'
      )
  })
  .strict();
export type UpsertDataExtensionRowsInput = z.infer<typeof UpsertDataExtensionRowsInput>;

/** sfmc_export_data_extension */
export const ExportDataExtensionInput = z
  .object({
    ...buParam,
    key: z.string().min(1).describe('External Key (CustomerKey) of the data extension to export.'),
    outputPath: z
      .string()
      .min(1)
      .describe(
        'Absolute file path where the CSV will be saved (e.g. /Users/me/Downloads/export.csv). The file will be created or overwritten.'
      ),
    dateField: z
      .string()
      .optional()
      .describe(
        'Name of the date/datetime field to filter on (e.g. "CreatedDate", "AdmitDate", "Timestamp"). Required when using fromDate or toDate.'
      ),
    fromDate: z
      .string()
      .optional()
      .describe(
        'Start of the date range (inclusive). ISO 8601 format: "2025-12-01" or "2025-12-01T00:00:00". Requires dateField.'
      ),
    toDate: z
      .string()
      .optional()
      .describe(
        'End of the date range (inclusive). ISO 8601 format: "2026-06-30" or "2026-06-30T23:59:59". Requires dateField.'
      ),
    maxRows: z
      .number()
      .int()
      .min(1)
      .optional()
      .describe(
        'Hard cap on total rows exported. Omit to export all rows. Use this to avoid timeouts on very large DEs.'
      )
  })
  .strict();
export type ExportDataExtensionInput = z.infer<typeof ExportDataExtensionInput>;

/** sfmc_query_soap */
export const QuerySoapInput = z
  .object({
    ...buParam,
    objectType: z
      .string()
      .min(1)
      .describe(
        'SOAP object name — e.g. "Subscriber", "BounceEvent", "OpenEvent", "Send", "List".'
      ),
    properties: z
      .array(z.string().min(1))
      .min(1)
      .describe('Property names to retrieve (must be valid for the object).'),
    filter: z
      .object({
        property: z.string().min(1),
        simpleOperator: z
          .enum([
            'equals',
            'notEquals',
            'greaterThan',
            'lessThan',
            'greaterThanOrEqual',
            'lessThanOrEqual',
            'isNull',
            'isNotNull',
            'between',
            'IN',
            'like'
          ])
          .describe('SOAP SimpleFilterPart operator.'),
        value: z.union([z.string(), z.number(), z.array(z.union([z.string(), z.number()]))]).optional()
      })
      .optional()
      .describe('Optional SimpleFilterPart. For complex filters use the REST DE query instead.'),
    maxResults: z
      .number()
      .int()
      .min(1)
      .max(2500)
      .default(500)
      .describe('Hard cap on returned rows (the server stops paging once this is hit).')
  })
  .strict();
export type QuerySoapInput = z.infer<typeof QuerySoapInput>;

/** sfmc_list_journeys */
export const ListJourneysInput = z
  .object({
    ...buParam,
    status: z
      .enum(['Draft', 'Published', 'ScheduledToPublish', 'Stopped', 'Unpublished', 'Deleted'])
      .optional()
      .describe('Filter by interaction status.'),
    nameContains: z.string().optional().describe('Case-insensitive substring match against name.'),
    top: z.number().int().min(1).max(500).default(50),
    skip: z.number().int().min(0).default(0)
  })
  .strict();
export type ListJourneysInput = z.infer<typeof ListJourneysInput>;

/** sfmc_get_journey */
export const GetJourneyInput = z
  .object({
    ...buParam,
    id: z.string().min(1).describe('Journey interaction ID (GUID).'),
    versionNumber: z
      .number()
      .int()
      .positive()
      .optional()
      .describe('Optional version number — defaults to the most recent.'),
    extras: z
      .array(z.enum(['activities', 'outcome', 'stats', 'all']))
      .optional()
      .describe('Optional ?extras query parameter values.')
  })
  .strict();
export type GetJourneyInput = z.infer<typeof GetJourneyInput>;

/** sfmc_get_journey_activity */
export const GetJourneyActivityInput = z
  .object({
    ...buParam,
    id: z.string().min(1).describe('Journey interaction ID (GUID).'),
    activityKey: z.string().min(1).describe('Activity key from sfmc_get_journey_graph.'),
    versionNumber: z.number().int().positive().optional()
  })
  .strict();
export type GetJourneyActivityInput = z.infer<typeof GetJourneyActivityInput>;

/** sfmc_get_journey_graph */
export const GetJourneyGraphInput = z
  .object({
    ...buParam,
    id: z.string().min(1).describe('Journey interaction ID (GUID).'),
    versionNumber: z.number().int().positive().optional()
  })
  .strict();
export type GetJourneyGraphInput = z.infer<typeof GetJourneyGraphInput>;

/** sfmc_send_triggered_email */
export const SendTriggeredEmailInput = z
  .object({
    ...buParam,
    externalKey: z
      .string()
      .min(1)
      .describe('External Key of the Triggered Send Definition (must be Active).'),
    subscribers: z
      .array(
        z
          .object({
            EmailAddress: z.string().email(),
            SubscriberKey: z.string().min(1),
            attributes: z
              .record(z.string(), z.union([z.string(), z.number(), z.boolean(), z.null()]))
              .optional()
              .describe('Personalization attributes keyed by AMPscript variable name.')
          })
          .strict()
      )
      .min(1)
      .max(50),
    options: z
      .object({
        requestType: z.enum(['SYNC', 'ASYNC']).default('ASYNC')
      })
      .optional()
  })
  .strict();
export type SendTriggeredEmailInput = z.infer<typeof SendTriggeredEmailInput>;

// ─── Shared building blocks ──────────────────────────────────────────────────

const FieldDefinition = z
  .object({
    name: z.string().min(1).describe('Field name.'),
    fieldType: z
      .enum(['Text', 'Number', 'Date', 'Boolean', 'EmailAddress', 'Phone', 'Decimal', 'Locale'])
      .describe('SFMC field type.'),
    maxLength: z
      .number()
      .int()
      .min(1)
      .max(4000)
      .optional()
      .describe('Required for Text fields (1–4000). Ignored for non-text types.'),
    isPrimaryKey: z.boolean().default(false).describe('Mark this field as a primary key.'),
    isRequired: z.boolean().default(false).describe('Require a value on insert.'),
    defaultValue: z.string().optional().describe('Default value for new rows.')
  })
  .strict();

const SendableConfigSchema = z
  .object({
    deFieldName: z
      .string()
      .min(1)
      .describe('Field in this DE used for subscriber matching (e.g. "EmailAddress").'),
    subscriberFieldName: z
      .string()
      .min(1)
      .describe('Subscriber attribute to match against (e.g. "Email Address").')
  })
  .strict();

const RetentionConfigSchema = z
  .object({
    period: z.number().int().positive().describe('Retention period length.'),
    unit: z.enum(['Days', 'Weeks', 'Months', 'Years']),
    rowBased: z
      .boolean()
      .default(false)
      .describe('Row-based (true) vs. DE-level (false) retention.'),
    deleteAtEnd: z
      .boolean()
      .default(false)
      .describe('Delete rows/DE when the retention period expires.'),
    resetOnImport: z
      .boolean()
      .default(false)
      .describe('Reset the retention clock on each import.')
  })
  .strict();

// ─── New DE management schemas ───────────────────────────────────────────────

/** sfmc_create_data_extension */
export const CreateDataExtensionInput = z
  .object({
    ...buParam,
    name: z.string().min(1).describe('Display name for the new Data Extension.'),
    customerKey: z
      .string()
      .optional()
      .describe('External key (CustomerKey). SFMC auto-generates one if omitted.'),
    description: z.string().optional(),
    categoryId: z
      .number()
      .int()
      .optional()
      .describe('Folder (CategoryID) to place the DE in. Omit for the default root folder.'),
    fields: z
      .array(FieldDefinition)
      .min(1)
      .describe('Field definitions. Include at least one primary-key field.'),
    sendable: SendableConfigSchema.optional().describe(
      'Make this DE sendable. Provide the DE field and the matching subscriber attribute.'
    ),
    retention: RetentionConfigSchema.optional().describe(
      'Retention policy. Omit for no automatic retention.'
    )
  })
  .strict();
export type CreateDataExtensionInput = z.infer<typeof CreateDataExtensionInput>;

/** sfmc_alter_data_extension */
export const AlterDataExtensionInput = z
  .object({
    ...buParam,
    key: z
      .string()
      .min(1)
      .describe('CustomerKey (External Key) of the existing Data Extension.'),
    addFields: z.array(FieldDefinition).optional().describe('New fields to add.'),
    removeFields: z
      .array(z.string().min(1))
      .optional()
      .describe('Names of fields to remove. Primary-key fields cannot be removed.'),
    updateFields: z
      .array(
        z
          .object({
            name: z.string().min(1).describe('Existing field name to modify.'),
            maxLength: z
              .number()
              .int()
              .min(1)
              .max(4000)
              .optional()
              .describe('New max length (Text fields only).'),
            defaultValue: z.string().optional().describe('New default value.'),
            isRequired: z.boolean().optional().describe('Set the required flag.')
          })
          .strict()
      )
      .optional()
      .describe('Modify existing field properties (length, default, required).'),
    properties: z
      .object({
        name: z.string().min(1).optional().describe('Rename the Data Extension.'),
        description: z.string().optional(),
        categoryId: z
          .number()
          .int()
          .optional()
          .describe('Move the DE to this folder (CategoryID).'),
        sendable: SendableConfigSchema.optional().describe(
          'Set or update the sendable relationship.'
        ),
        retention: RetentionConfigSchema.optional().describe('Set or update the retention policy.')
      })
      .strict()
      .optional()
      .describe(
        'DE-level changes: rename, move to folder, set sendable relationship or retention policy.'
      )
  })
  .strict()
  .refine(
    (v) =>
      (v.addFields?.length ?? 0) > 0 ||
      (v.removeFields?.length ?? 0) > 0 ||
      (v.updateFields?.length ?? 0) > 0 ||
      v.properties !== undefined,
    { message: 'Specify at least one of: addFields, removeFields, updateFields, or properties.' }
  );
export type AlterDataExtensionInput = z.infer<typeof AlterDataExtensionInput>;

/** sfmc_manage_folder */
export const ManageFolderInput = z
  .object({
    ...buParam,
    action: z
      .enum(['create', 'rename', 'move'])
      .describe(
        '"create" a new DE folder, "rename" an existing one, or "move" it to a different parent.'
      ),
    name: z
      .string()
      .min(1)
      .optional()
      .describe('Folder name — required for create and rename.'),
    categoryId: z
      .number()
      .int()
      .optional()
      .describe('Existing folder ID — required for rename and move.'),
    parentCategoryId: z
      .number()
      .int()
      .optional()
      .describe(
        'Parent folder ID — required for create; for move this changes the parent.'
      )
  })
  .strict()
  .refine(
    (v) => {
      if (v.action === 'create') return v.name !== undefined && v.parentCategoryId !== undefined;
      if (v.action === 'rename') return v.name !== undefined && v.categoryId !== undefined;
      if (v.action === 'move') return v.categoryId !== undefined && v.parentCategoryId !== undefined;
      return true;
    },
    {
      message:
        'create requires name + parentCategoryId; rename requires name + categoryId; move requires categoryId + parentCategoryId.'
    }
  );
export type ManageFolderInput = z.infer<typeof ManageFolderInput>;

/** sfmc_delete_data_extension */
export const DeleteDataExtensionInput = z
  .object({
    ...buParam,
    key: z.string().min(1).describe('CustomerKey (External Key) of the Data Extension to delete. This is permanent and cannot be undone.')
  })
  .strict();
export type DeleteDataExtensionInput = z.infer<typeof DeleteDataExtensionInput>;

/** sfmc_get_email_send_summary */
export const GetEmailSendSummaryInput = z
  .object({
    ...buParam,
    sendId: z
      .number()
      .int()
      .positive()
      .optional()
      .describe('Specific SendID. Mutually exclusive with date range.'),
    startDate: z
      .string()
      .datetime({ offset: true })
      .optional()
      .describe('ISO-8601 lower bound on SendDate (inclusive). Required if sendId omitted.'),
    endDate: z
      .string()
      .datetime({ offset: true })
      .optional()
      .describe('ISO-8601 upper bound on SendDate (exclusive). Required if sendId omitted.')
  })
  .strict()
  .refine(
    (v) => v.sendId !== undefined || (v.startDate !== undefined && v.endDate !== undefined),
    { message: 'Either sendId or both startDate and endDate must be provided.' }
  );
export type GetEmailSendSummaryInput = z.infer<typeof GetEmailSendSummaryInput>;

// ─── Automation Studio ───────────────────────────────────────────────────────

export const ListAutomationsInput = z
  .object({
    ...buParam,
    nameContains: z.string().optional().describe('Case-insensitive substring filter on automation name.'),
    status: z
      .enum(['Active', 'Inactive', 'Error', 'Paused', 'Building', 'Scheduled', 'Running', 'Stopped'])
      .optional(),
    top: z.number().int().min(1).max(500).default(50),
    page: z.number().int().min(1).default(1)
  })
  .strict();
export type ListAutomationsInput = z.infer<typeof ListAutomationsInput>;

export const GetAutomationInput = z
  .object({
    ...buParam,
    id: z.string().min(1).describe('Automation object ID (GUID) or programmatic name.')
  })
  .strict();
export type GetAutomationInput = z.infer<typeof GetAutomationInput>;

/** sfmc_get_automation_soap — SOAP fallback when REST returns 596 */
export const GetAutomationByNameInput = z
  .object({
    ...buParam,
    name: z
      .string()
      .min(1)
      .describe('Exact automation name as it appears in Automation Studio (e.g. "HCP – Generate PID").')
  })
  .strict();
export type GetAutomationByNameInput = z.infer<typeof GetAutomationByNameInput>;

/** sfmc_list_automations_soap — SOAP fallback when REST returns 596 */
export const ListAutomationsSoapInput = z
  .object({
    ...buParam,
    nameContains: z
      .string()
      .optional()
      .describe('Optional substring filter on automation name. Returns all automations if omitted.')
  })
  .strict();
export type ListAutomationsSoapInput = z.infer<typeof ListAutomationsSoapInput>;

/** sfmc_debug_soap_automation — returns raw SOAP XML for diagnostics */
export const DebugSoapAutomationInput = z
  .object({ ...buParam })
  .strict();
export type DebugSoapAutomationInput = z.infer<typeof DebugSoapAutomationInput>;

const AutomationScheduleSchema = z
  .object({
    startDate: z.string().describe('ISO-8601 start date/time.'),
    rangeTypeId: z.number().int().describe('1=Once, 2=Hourly, 3=Daily, 4=Weekly, 5=Monthly'),
    scheduledTime: z.string().describe('Time of day HH:MM:SS.'),
    timezone: z.string().default('Central Standard Time'),
    timezoneId: z.number().int().default(1)
  })
  .strict();

export const CreateAutomationInput = z
  .object({
    ...buParam,
    name: z.string().min(1),
    key: z.string().optional().describe('External key. Auto-generated if omitted.'),
    description: z.string().optional(),
    schedule: AutomationScheduleSchema.optional().describe('Omit for manually-triggered automations.'),
    steps: z
      .array(
        z
          .object({
            step: z.number().int().positive(),
            activities: z
              .array(
                z
                  .object({
                    activityObjectId: z
                      .string()
                      .min(1)
                      .describe('ObjectID of the existing activity (SQL Query, Data Extract, Import, etc.).'),
                    name: z.string().min(1),
                    activityTypeId: z
                      .number()
                      .int()
                      .describe('1=SQL Query, 2=Email Send, 3=File Transfer, 4=Data Extract, 5=Import, 6=Script')
                  })
                  .strict()
              )
              .min(1)
          })
          .strict()
      )
      .min(1)
  })
  .strict();
export type CreateAutomationInput = z.infer<typeof CreateAutomationInput>;

export const UpdateAutomationInput = z
  .object({
    ...buParam,
    id: z.string().min(1).describe('Automation object ID.'),
    name: z.string().optional(),
    description: z.string().optional(),
    schedule: AutomationScheduleSchema.optional()
  })
  .strict()
  .refine(
    (v) => v.name !== undefined || v.description !== undefined || v.schedule !== undefined,
    { message: 'Specify at least one of: name, description, schedule.' }
  );
export type UpdateAutomationInput = z.infer<typeof UpdateAutomationInput>;

export const DeleteAutomationInput = z
  .object({ ...buParam, id: z.string().min(1).describe('Automation object ID.') })
  .strict();
export type DeleteAutomationInput = z.infer<typeof DeleteAutomationInput>;

export const AutomationActionInput = z
  .object({
    ...buParam,
    id: z.string().min(1).describe('Automation object ID.'),
    action: z
      .enum(['start', 'stop'])
      .describe('"start" triggers an immediate run; "stop" cancels the current run or pauses the schedule.')
  })
  .strict();
export type AutomationActionInput = z.infer<typeof AutomationActionInput>;

// ─── Content Builder / Email Studio ─────────────────────────────────────────
// Asset type IDs: 207=HTML Email  208=Text Email  209=Template Email
//   4=Template  196=HTML Content Block  195=Code Snippet  28=Image  329=CloudPage

export const ListAssetsInput = z
  .object({
    ...buParam,
    type: z
      .enum(['email', 'template', 'content-block', 'image', 'cloudpage', 'all'])
      .default('all')
      .describe('Asset type group filter.'),
    nameContains: z.string().optional(),
    categoryId: z.number().int().optional().describe('Content Builder folder ID.'),
    top: z.number().int().min(1).max(200).default(50),
    page: z.number().int().min(1).default(1)
  })
  .strict();
export type ListAssetsInput = z.infer<typeof ListAssetsInput>;

export const GetAssetInput = z
  .object({ ...buParam, id: z.number().int().positive().describe('Content Builder asset ID.') })
  .strict();
export type GetAssetInput = z.infer<typeof GetAssetInput>;

export const CreateAssetInput = z
  .object({
    ...buParam,
    name: z.string().min(1),
    assetType: z
      .object({ id: z.number().int() })
      .strict()
      .describe('Asset type. Common IDs: 207=HTML Email, 209=Template Email, 196=HTML Block, 4=Template, 329=CloudPage.'),
    description: z.string().optional(),
    category: z.object({ id: z.number().int() }).strict().optional().describe('Content Builder folder.'),
    content: z.string().optional().describe('Raw HTML content.'),
    views: z
      .record(
        z.string(),
        z
          .object({ content: z.string().optional(), meta: z.record(z.string(), z.unknown()).optional() })
          .strict()
      )
      .optional()
      .describe('Email views keyed by name: html, text, subjectline, preheader, etc.'),
    data: z.record(z.string(), z.unknown()).optional(),
    meta: z.record(z.string(), z.unknown()).optional()
  })
  .strict();
export type CreateAssetInput = z.infer<typeof CreateAssetInput>;

export const UpdateAssetInput = z
  .object({
    ...buParam,
    id: z.number().int().positive().describe('Content Builder asset ID.'),
    name: z.string().optional(),
    description: z.string().optional(),
    content: z.string().optional(),
    views: z
      .record(
        z.string(),
        z
          .object({ content: z.string().optional(), meta: z.record(z.string(), z.unknown()).optional() })
          .strict()
      )
      .optional(),
    data: z.record(z.string(), z.unknown()).optional(),
    meta: z.record(z.string(), z.unknown()).optional()
  })
  .strict()
  .refine(
    (v) =>
      v.name !== undefined ||
      v.description !== undefined ||
      v.content !== undefined ||
      v.views !== undefined ||
      v.data !== undefined ||
      v.meta !== undefined,
    { message: 'Specify at least one property to update.' }
  );
export type UpdateAssetInput = z.infer<typeof UpdateAssetInput>;

export const DeleteAssetInput = z
  .object({ ...buParam, id: z.number().int().positive().describe('Content Builder asset ID.') })
  .strict();
export type DeleteAssetInput = z.infer<typeof DeleteAssetInput>;

// ─── Contact Builder ─────────────────────────────────────────────────────────

export const GetContactInput = z
  .object({ ...buParam, contactKey: z.string().min(1).describe('Contact key (subscriber key or custom identifier).') })
  .strict();
export type GetContactInput = z.infer<typeof GetContactInput>;

export const UpsertContactInput = z
  .object({
    ...buParam,
    contactKey: z.string().min(1),
    attributeSets: z
      .array(
        z
          .object({
            name: z.string().min(1).describe('Attribute set name, e.g. "Email Addresses".'),
            items: z
              .array(
                z
                  .object({
                    values: z
                      .array(z.object({ name: z.string().min(1), value: z.unknown() }).strict())
                      .min(1)
                  })
                  .strict()
              )
              .min(1)
          })
          .strict()
      )
      .min(1)
  })
  .strict();
export type UpsertContactInput = z.infer<typeof UpsertContactInput>;

export const DeleteContactInput = z
  .object({
    ...buParam,
    contactKey: z.string().min(1),
    deleteType: z.enum(['ContactAndAttributes', 'ContactOnly']).default('ContactAndAttributes')
  })
  .strict();
export type DeleteContactInput = z.infer<typeof DeleteContactInput>;

// ─── Journey Builder Extensions ──────────────────────────────────────────────

export const CreateJourneyInput = z
  .object({
    ...buParam,
    name: z.string().min(1),
    key: z.string().optional(),
    description: z.string().optional(),
    workflowApiVersion: z.number().default(1.0),
    triggers: z.array(z.record(z.string(), z.unknown())).optional(),
    goals: z.array(z.record(z.string(), z.unknown())).optional(),
    activities: z.array(z.record(z.string(), z.unknown())).optional(),
    exits: z.array(z.record(z.string(), z.unknown())).optional()
  })
  .strict();
export type CreateJourneyInput = z.infer<typeof CreateJourneyInput>;

export const UpdateJourneyInput = z
  .object({
    ...buParam,
    id: z.string().min(1).describe('Journey interaction ID.'),
    versionNumber: z.number().int().optional(),
    name: z.string().optional(),
    description: z.string().optional(),
    activities: z.array(z.record(z.string(), z.unknown())).optional(),
    triggers: z.array(z.record(z.string(), z.unknown())).optional(),
    goals: z.array(z.record(z.string(), z.unknown())).optional()
  })
  .strict()
  .refine(
    (v) =>
      v.name !== undefined ||
      v.description !== undefined ||
      v.activities !== undefined ||
      v.triggers !== undefined ||
      v.goals !== undefined,
    { message: 'Specify at least one of: name, description, activities, triggers, goals.' }
  );
export type UpdateJourneyInput = z.infer<typeof UpdateJourneyInput>;

export const JourneyActionInput = z
  .object({
    ...buParam,
    id: z.string().min(1).describe('Journey interaction ID.'),
    action: z.enum(['publish', 'stop', 'pause', 'resume']),
    versionNumber: z.number().int().optional().describe('Target version. Defaults to latest.')
  })
  .strict();
export type JourneyActionInput = z.infer<typeof JourneyActionInput>;

// ─── Subscriber & List Management ────────────────────────────────────────────

export const ListSubscribersInput = z
  .object({
    ...buParam,
    emailAddress: z.string().optional().describe('Filter by email (like match).'),
    status: z.enum(['Active', 'Bounced', 'Held', 'Unsubscribed', 'Deleted']).optional(),
    listId: z.number().int().optional().describe('Filter to subscribers on a specific list.'),
    maxResults: z.number().int().min(1).max(2500).default(500)
  })
  .strict();
export type ListSubscribersInput = z.infer<typeof ListSubscribersInput>;

export const GetSubscriberInput = z
  .object({
    ...buParam,
    subscriberKey: z.string().optional(),
    emailAddress: z.string().optional()
  })
  .strict()
  .refine((v) => v.subscriberKey !== undefined || v.emailAddress !== undefined, {
    message: 'Provide subscriberKey or emailAddress.'
  });
export type GetSubscriberInput = z.infer<typeof GetSubscriberInput>;

export const UpsertSubscriberInput = z
  .object({
    ...buParam,
    emailAddress: z.string().email(),
    subscriberKey: z.string().optional(),
    status: z.enum(['Active', 'Unsubscribed', 'Held', 'Bounced']).default('Active'),
    lists: z
      .array(
        z.object({ id: z.number().int(), status: z.enum(['Active', 'Unsubscribed']).default('Active') }).strict()
      )
      .optional(),
    attributes: z
      .array(z.object({ name: z.string().min(1), value: z.string() }).strict())
      .optional()
      .describe('Custom profile attributes.')
  })
  .strict();
export type UpsertSubscriberInput = z.infer<typeof UpsertSubscriberInput>;

export const DeleteSubscriberInput = z
  .object({
    ...buParam,
    emailAddress: z.string().optional(),
    subscriberKey: z.string().optional()
  })
  .strict()
  .refine((v) => v.emailAddress !== undefined || v.subscriberKey !== undefined, {
    message: 'Provide emailAddress or subscriberKey.'
  });
export type DeleteSubscriberInput = z.infer<typeof DeleteSubscriberInput>;

export const ListListsInput = z
  .object({
    ...buParam,
    nameContains: z.string().optional(),
    listClassification: z
      .enum(['ExactTargetList', 'PublicationList', 'SuppressionList'])
      .optional(),
    maxResults: z.number().int().min(1).max(500).default(200)
  })
  .strict();
export type ListListsInput = z.infer<typeof ListListsInput>;

export const CreateListInput = z
  .object({
    ...buParam,
    listName: z.string().min(1),
    description: z.string().optional(),
    listClassification: z
      .enum(['ExactTargetList', 'PublicationList', 'SuppressionList'])
      .default('ExactTargetList')
  })
  .strict();
export type CreateListInput = z.infer<typeof CreateListInput>;

export const ManageListSubscriptionInput = z
  .object({
    ...buParam,
    action: z.enum(['subscribe', 'unsubscribe']),
    listId: z.number().int().describe('SFMC List ID.'),
    subscribers: z
      .array(
        z
          .object({ emailAddress: z.string().email(), subscriberKey: z.string().optional() })
          .strict()
      )
      .min(1)
      .max(100)
  })
  .strict();
export type ManageListSubscriptionInput = z.infer<typeof ManageListSubscriptionInput>;

// ─── User & Account Management ───────────────────────────────────────────────

export const ListUsersInput = z
  .object({
    ...buParam,
    nameContains: z.string().optional(),
    email: z.string().optional(),
    isActive: z.boolean().optional(),
    maxResults: z.number().int().min(1).max(500).default(200)
  })
  .strict();
export type ListUsersInput = z.infer<typeof ListUsersInput>;

export const CreateUserInput = z
  .object({
    ...buParam,
    name: z.string().min(1).describe('Full name.'),
    email: z.string().email().describe('Login email / username.'),
    password: z.string().min(8).describe('Initial password.'),
    notificationEmailAddress: z.string().email().optional(),
    mustChangePassword: z.boolean().default(true),
    isLocked: z.boolean().default(false)
  })
  .strict();
export type CreateUserInput = z.infer<typeof CreateUserInput>;

export const UpdateUserInput = z
  .object({
    ...buParam,
    id: z.number().int().describe('AccountUser ID.'),
    name: z.string().optional(),
    notificationEmailAddress: z.string().email().optional(),
    isLocked: z.boolean().optional(),
    mustChangePassword: z.boolean().optional(),
    isActive: z.boolean().optional()
  })
  .strict()
  .refine(
    (v) =>
      v.name !== undefined ||
      v.notificationEmailAddress !== undefined ||
      v.isLocked !== undefined ||
      v.mustChangePassword !== undefined ||
      v.isActive !== undefined,
    { message: 'Specify at least one property to update.' }
  );
export type UpdateUserInput = z.infer<typeof UpdateUserInput>;

// ─── Reports & Analytics / Data Views ────────────────────────────────────────

export const QueryDataViewInput = z
  .object({
    ...buParam,
    view: z
      .enum([
        '_Sent',
        '_Open',
        '_Click',
        '_Bounce',
        '_Unsubscribe',
        '_Complaint',
        '_Job',
        '_Subscriber',
        '_ListSubscribers',
        '_BusinessUnitUnsubscribes'
      ])
      .describe('SFMC system data view to query via SOAP Retrieve.'),
    properties: z.array(z.string().min(1)).min(1),
    filter: z
      .object({
        property: z.string().min(1),
        simpleOperator: z.enum([
          'equals',
          'notEquals',
          'greaterThan',
          'lessThan',
          'greaterThanOrEqual',
          'lessThanOrEqual',
          'between',
          'IN',
          'like'
        ]),
        value: z
          .union([z.string(), z.number(), z.array(z.union([z.string(), z.number()]))])
          .optional()
      })
      .optional(),
    maxResults: z.number().int().min(1).max(2500).default(500)
  })
  .strict();
export type QueryDataViewInput = z.infer<typeof QueryDataViewInput>;

// ─── SQL Query Activity (QueryDefinition) ────────────────────────────────────

export const CreateQueryDefinitionInput = z
  .object({
    ...buParam,
    name: z.string().min(1).describe('Display name for the query activity.'),
    customerKey: z.string().optional().describe('External key. Auto-generated if omitted.'),
    description: z.string().optional(),
    queryText: z
      .string()
      .min(1)
      .describe(
        'Full SQL query. May reference system data views (_Sent, _Open, _Click, _Bounce, _Unsubscribe, _Complaint) or DE names.'
      ),
    targetDeKey: z
      .string()
      .min(1)
      .describe('CustomerKey of the target Data Extension that will receive the query results.'),
    targetDeName: z.string().optional().describe('Display name of the target DE (optional, for clarity).'),
    targetUpdateType: z
      .enum(['Overwrite', 'Update', 'Append'])
      .default('Overwrite')
      .describe('How to write results: Overwrite replaces all rows, Update modifies matching rows, Append adds rows.')
  })
  .strict();
export type CreateQueryDefinitionInput = z.infer<typeof CreateQueryDefinitionInput>;

export const UpdateQueryDefinitionInput = z
  .object({
    ...buParam,
    objectId: z.string().optional().describe('ObjectID of the QueryDefinition.'),
    customerKey: z.string().optional().describe('CustomerKey of the QueryDefinition.'),
    name: z.string().optional(),
    description: z.string().optional(),
    queryText: z.string().optional(),
    targetDeKey: z.string().optional(),
    targetDeName: z.string().optional(),
    targetUpdateType: z.enum(['Overwrite', 'Update', 'Append']).optional()
  })
  .strict()
  .refine((v) => v.objectId !== undefined || v.customerKey !== undefined, {
    message: 'Provide objectId or customerKey to identify the QueryDefinition.'
  })
  .refine(
    (v) =>
      v.name !== undefined ||
      v.description !== undefined ||
      v.queryText !== undefined ||
      v.targetDeKey !== undefined ||
      v.targetUpdateType !== undefined,
    { message: 'Specify at least one property to update.' }
  );
export type UpdateQueryDefinitionInput = z.infer<typeof UpdateQueryDefinitionInput>;

export const GetQueryDefinitionInput = z
  .object({
    ...buParam,
    objectId: z.string().optional().describe('ObjectID of the QueryDefinition.'),
    customerKey: z.string().optional().describe('CustomerKey of the QueryDefinition.')
  })
  .strict()
  .refine((v) => v.objectId !== undefined || v.customerKey !== undefined, {
    message: 'Provide objectId or customerKey.'
  });
export type GetQueryDefinitionInput = z.infer<typeof GetQueryDefinitionInput>;

export const DeleteQueryDefinitionInput = z
  .object({
    ...buParam,
    objectId: z.string().optional(),
    customerKey: z.string().optional()
  })
  .strict()
  .refine((v) => v.objectId !== undefined || v.customerKey !== undefined, {
    message: 'Provide objectId or customerKey.'
  });
export type DeleteQueryDefinitionInput = z.infer<typeof DeleteQueryDefinitionInput>;

export const ExecuteQueryDefinitionInput = z
  .object({
    ...buParam,
    objectId: z.string().optional().describe('ObjectID of the QueryDefinition to execute.'),
    customerKey: z.string().optional().describe('CustomerKey of the QueryDefinition to execute.')
  })
  .strict()
  .refine((v) => v.objectId !== undefined || v.customerKey !== undefined, {
    message: 'Provide objectId or customerKey.'
  });
export type ExecuteQueryDefinitionInput = z.infer<typeof ExecuteQueryDefinitionInput>;

// ─── Script Activity (SssjsActivity) ─────────────────────────────────────────

export const ManageScriptActivityInput = z
  .object({
    ...buParam,
    action: z.enum(['create', 'update']),
    objectId: z.string().optional().describe('ObjectID — required for update.'),
    customerKey: z.string().optional().describe('External key — used to identify for update or set on create.'),
    name: z.string().optional().describe('Activity name — required for create.'),
    description: z.string().optional(),
    script: z.string().optional().describe('SSJS or AMPscript source code — required for create.'),
    scriptType: z.enum(['ssjs', 'ampscript']).default('ssjs').describe('Script language hint (informational; SFMC uses SssjsActivity for both).')
  })
  .strict()
  .refine(
    (v) => {
      if (v.action === 'create') return v.name !== undefined && v.script !== undefined;
      return v.objectId !== undefined || v.customerKey !== undefined;
    },
    { message: 'create requires name + script; update requires objectId or customerKey.' }
  );
export type ManageScriptActivityInput = z.infer<typeof ManageScriptActivityInput>;

// ─── Data Extract Activity ─────────────────────────────────────────────────────

export const ManageDataExtractActivityInput = z
  .object({
    ...buParam,
    action: z.enum(['create', 'update']),
    objectId: z.string().optional().describe('ObjectID — required for update.'),
    customerKey: z.string().optional(),
    name: z.string().optional().describe('Required for create.'),
    description: z.string().optional(),
    extractDefinitionTemplateKey: z
      .string()
      .optional()
      .describe('Template key defining the extract type (e.g. "DataExtension", "Tracking"). Required for create.'),
    parameters: z
      .array(z.object({ name: z.string().min(1), value: z.string() }).strict())
      .optional()
      .describe('Key-value parameters passed to the extract template (Delimiter, HasColumnHeaders, IncludeColumnHeaders, etc.).')
  })
  .strict()
  .refine(
    (v) => {
      if (v.action === 'create')
        return v.name !== undefined && v.extractDefinitionTemplateKey !== undefined;
      return v.objectId !== undefined || v.customerKey !== undefined;
    },
    { message: 'create requires name + extractDefinitionTemplateKey; update requires objectId or customerKey.' }
  );
export type ManageDataExtractActivityInput = z.infer<typeof ManageDataExtractActivityInput>;

// ─── File Transfer Activity ────────────────────────────────────────────────────

export const ManageFileTransferActivityInput = z
  .object({
    ...buParam,
    action: z.enum(['create', 'update']),
    objectId: z.string().optional().describe('ObjectID — required for update.'),
    customerKey: z.string().optional(),
    name: z.string().optional().describe('Required for create.'),
    description: z.string().optional(),
    fileSpec: z
      .string()
      .optional()
      .describe('File pattern to transfer, e.g. "export_%.csv". Required for create.'),
    fileTransferLocationKey: z
      .string()
      .optional()
      .describe('CustomerKey of the FTP/SFTP transfer location. Required for create.'),
    moveCompleted: z.boolean().optional().describe('Move the file after transfer completes.')
  })
  .strict()
  .refine(
    (v) => {
      if (v.action === 'create')
        return v.name !== undefined && v.fileSpec !== undefined && v.fileTransferLocationKey !== undefined;
      return v.objectId !== undefined || v.customerKey !== undefined;
    },
    { message: 'create requires name + fileSpec + fileTransferLocationKey; update requires objectId or customerKey.' }
  );
export type ManageFileTransferActivityInput = z.infer<typeof ManageFileTransferActivityInput>;

// ─── Import Definition ────────────────────────────────────────────────────────

export const ManageImportDefinitionInput = z
  .object({
    ...buParam,
    action: z.enum(['create', 'update']),
    objectId: z.string().optional().describe('ObjectID — required for update.'),
    customerKey: z.string().optional(),
    name: z.string().optional().describe('Required for create.'),
    description: z.string().optional(),
    targetDeKey: z
      .string()
      .optional()
      .describe('CustomerKey of the destination Data Extension. Required for create.'),
    fileSpec: z
      .string()
      .optional()
      .describe('File name pattern on FTP, e.g. "import_%.csv". Required for create.'),
    fileType: z.enum(['CSV', 'TAB', 'OTHER']).default('CSV').optional(),
    fieldMappingType: z
      .enum(['MapByHeaderRow', 'MapByOrdinal', 'MapByFieldName'])
      .default('MapByHeaderRow')
      .optional(),
    updateType: z.enum(['Overwrite', 'AddAndUpdate', 'Add']).default('AddAndUpdate').optional(),
    maxFileAge: z.number().int().default(24).optional().describe('Max file age in hours (default 24).'),
    ftpLocationKey: z
      .string()
      .optional()
      .describe('CustomerKey of the FTP retrieve location. Defaults to the Enhanced FTP site.'),
    allowErrors: z.boolean().default(true).optional().describe('Continue import when non-fatal row errors occur.')
  })
  .strict()
  .refine(
    (v) => {
      if (v.action === 'create')
        return v.name !== undefined && v.targetDeKey !== undefined && v.fileSpec !== undefined;
      return v.objectId !== undefined || v.customerKey !== undefined;
    },
    { message: 'create requires name + targetDeKey + fileSpec; update requires objectId or customerKey.' }
  );
export type ManageImportDefinitionInput = z.infer<typeof ManageImportDefinitionInput>;

export const TriggerBulkImportInput = z
  .object({
    ...buParam,
    objectId: z.string().optional().describe('ObjectID of the ImportDefinition to trigger.'),
    customerKey: z.string().optional().describe('CustomerKey of the ImportDefinition to trigger.')
  })
  .strict()
  .refine((v) => v.objectId !== undefined || v.customerKey !== undefined, {
    message: 'Provide objectId or customerKey of the ImportDefinition.'
  });
export type TriggerBulkImportInput = z.infer<typeof TriggerBulkImportInput>;

// ─── Bulk DE row delete ────────────────────────────────────────────────────────

export const DeleteDeRowsInput = z
  .object({
    ...buParam,
    key: z.string().min(1).describe('CustomerKey (External Key) of the Data Extension.'),
    filter: z
      .string()
      .optional()
      .describe(
        'OData $filter expression to select rows to delete — e.g. "Status eq \'Inactive\'". If omitted, all rows are deleted.'
      )
  })
  .strict();
export type DeleteDeRowsInput = z.infer<typeof DeleteDeRowsInput>;

// ─── Rename Data Extension ─────────────────────────────────────────────────────

export const RenameDataExtensionInput = z
  .object({
    ...buParam,
    key: z.string().min(1).describe('CustomerKey (External Key) of the Data Extension to rename.'),
    newName: z.string().min(1).describe('New display name for the Data Extension.')
  })
  .strict();
export type RenameDataExtensionInput = z.infer<typeof RenameDataExtensionInput>;

// ─── Asset Clone / Move ───────────────────────────────────────────────────────

export const CloneAssetInput = z
  .object({
    ...buParam,
    sourceId: z.number().int().positive().describe('Content Builder asset ID to clone.'),
    newName: z.string().min(1).describe('Name for the cloned asset.'),
    targetCategoryId: z
      .number()
      .int()
      .optional()
      .describe('Content Builder folder ID for the clone. Defaults to the same folder as the source.')
  })
  .strict();
export type CloneAssetInput = z.infer<typeof CloneAssetInput>;

export const MoveAssetInput = z
  .object({
    ...buParam,
    id: z.number().int().positive().describe('Content Builder asset ID to move.'),
    categoryId: z.number().int().describe('Target folder (category.id) to move the asset into.')
  })
  .strict();
export type MoveAssetInput = z.infer<typeof MoveAssetInput>;

// ─── Journey Metrics ──────────────────────────────────────────────────────────

export const GetJourneyMetricsInput = z
  .object({
    ...buParam,
    id: z.string().min(1).describe('Journey interaction ID (GUID).'),
    versionNumber: z.number().int().optional().describe('Journey version number. Defaults to latest.')
  })
  .strict();
export type GetJourneyMetricsInput = z.infer<typeof GetJourneyMetricsInput>;

// ─── Subscriber Send History ─────────────────────────────────────────────────

export const GetSubscriberSendHistoryInput = z
  .object({
    ...buParam,
    subscriberKey: z.string().min(1).describe('Subscriber key to look up send history for.'),
    top: z.number().int().min(1).max(200).default(50).describe('Max records to return.'),
    skip: z.number().int().min(0).default(0).describe('Offset for pagination.')
  })
  .strict();
export type GetSubscriberSendHistoryInput = z.infer<typeof GetSubscriberSendHistoryInput>;

// ─── Automation Run History ───────────────────────────────────────────────────

export const GetAutomationHistoryInput = z
  .object({
    ...buParam,
    id: z.string().min(1).describe('Automation object ID (GUID).'),
    top: z.number().int().min(1).max(200).default(50),
    page: z.number().int().min(1).default(1)
  })
  .strict();
export type GetAutomationHistoryInput = z.infer<typeof GetAutomationHistoryInput>;

// ─── Fire Automation (immediate run) ─────────────────────────────────────────

export const FireAutomationInput = z
  .object({
    ...buParam,
    id: z.string().min(1).describe('Automation object ID (GUID) to trigger for an immediate run.')
  })
  .strict();
export type FireAutomationInput = z.infer<typeof FireAutomationInput>;

// ─── User Role Management ─────────────────────────────────────────────────────

export const AssignRoleInput = z
  .object({
    ...buParam,
    userId: z.number().int().describe('AccountUser ID to assign the role to.'),
    roleId: z.number().int().optional().describe('Role ID. Provide roleId or roleName.'),
    roleName: z.string().optional().describe('Role name. Provide roleId or roleName.')
  })
  .strict()
  .refine((v) => v.roleId !== undefined || v.roleName !== undefined, {
    message: 'Provide roleId or roleName.'
  });
export type AssignRoleInput = z.infer<typeof AssignRoleInput>;

export const RevokeRoleInput = z
  .object({
    ...buParam,
    userId: z.number().int().describe('AccountUser ID to revoke the role from.'),
    roleId: z.number().int().optional(),
    roleName: z.string().optional()
  })
  .strict()
  .refine((v) => v.roleId !== undefined || v.roleName !== undefined, {
    message: 'Provide roleId or roleName.'
  });
export type RevokeRoleInput = z.infer<typeof RevokeRoleInput>;

// ─── Einstein Send Time Optimization ─────────────────────────────────────────

export const GetEinsteinStoScoreInput = z
  .object({
    ...buParam,
    subscriberKey: z
      .string()
      .optional()
      .describe('Subscriber key to retrieve an individual STO score. Omit for account-level defaults.'),
    timezone: z.string().optional().describe('IANA timezone name, e.g. "America/New_York".')
  })
  .strict();
export type GetEinsteinStoScoreInput = z.infer<typeof GetEinsteinStoScoreInput>;

// ─── CloudPage Operations ─────────────────────────────────────────────────────

export const PublishCloudpageInput = z
  .object({
    ...buParam,
    id: z
      .number()
      .int()
      .positive()
      .describe('Content Builder asset ID of the CloudPage (asset type 329) to publish.')
  })
  .strict();
export type PublishCloudpageInput = z.infer<typeof PublishCloudpageInput>;

export const UnpublishCloudpageInput = z
  .object({
    ...buParam,
    id: z
      .number()
      .int()
      .positive()
      .describe('Content Builder asset ID of the CloudPage to take offline without deleting.')
  })
  .strict();
export type UnpublishCloudpageInput = z.infer<typeof UnpublishCloudpageInput>;

export const GetCloudpageUrlInput = z
  .object({
    ...buParam,
    id: z
      .number()
      .int()
      .positive()
      .describe('Content Builder asset ID of the CloudPage whose published URL to fetch.')
  })
  .strict();
export type GetCloudpageUrlInput = z.infer<typeof GetCloudpageUrlInput>;

export const ManageCloudpageCollectionInput = z
  .object({
    ...buParam,
    action: z
      .enum(['create', 'update', 'delete'])
      .describe('Operation: create a new collection, rename/move an existing one, or delete it.'),
    id: z
      .number()
      .int()
      .optional()
      .describe('Collection (category) ID — required for update and delete.'),
    name: z
      .string()
      .min(1)
      .optional()
      .describe('Collection display name — required for create, optional for update.'),
    parentId: z
      .number()
      .int()
      .optional()
      .describe('Parent category ID. Defaults to the root CloudPage collection on create.')
  })
  .strict()
  .refine(
    (v) => {
      if (v.action === 'create') return v.name !== undefined;
      return v.id !== undefined;
    },
    { message: 'create requires name; update and delete require id.' }
  );
export type ManageCloudpageCollectionInput = z.infer<typeof ManageCloudpageCollectionInput>;
