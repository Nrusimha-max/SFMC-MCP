#!/usr/bin/env node
/** Small model-facing tool surface; delegates API work and auth to existing mcp-sfmc. */
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { CallToolRequestSchema, ListToolsRequestSchema, type Tool } from '@modelcontextprotocol/sdk/types.js';
import { z } from 'zod';
import { zodToJsonSchema } from 'zod-to-json-schema';
import { READ_ONLY_TOOLS } from './sfmc/read-only-tools.js';
import { boundedJson, compactPayload } from './utils/efficient-response.js';

const searchSchema = z.object({ query: z.string().max(200).default(''), offset: z.number().int().min(0).default(0), limit: z.number().int().min(1).max(10).default(5) }).strict();
const callSchema = z.object({ tool: z.string(), arguments: z.record(z.unknown()).default({}), maxItems: z.number().int().min(1).max(100).default(10), fields: z.array(z.string()).max(30).optional() }).strict();
const definitions = [
  { name: 'sfmc_find_tools', description: 'Find supported read-only SFMC API tools and their argument schemas. Search by name or capability; paginate with offset.', schema: searchSchema },
  { name: 'sfmc_read', description: 'Call a read-only SFMC REST/SOAP tool found by sfmc_find_tools. Uses existing auth. Compact fresh results; optional fields projects array records. Writes and token retrieval are blocked.', schema: callSchema }
];

async function main(): Promise<void> {
  const command = process.env.SFMC_UPSTREAM_COMMAND || 'mcp-sfmc';
  const upstream = new Client({ name: 'sfmc-efficient-gateway', version: '1.0.0' });
  const transport = new StdioClientTransport({ command, args: [], stderr: 'pipe' });
  // Never forward upstream logs that might contain auth configuration.
  transport.stderr?.on('data', () => {});
  await upstream.connect(transport);
  const all: Tool[] = [];
  let cursor: string | undefined;
  do {
    const page = await upstream.listTools(cursor ? { cursor } : {});
    all.push(...page.tools);
    cursor = page.nextCursor;
  } while (cursor);
  const readable = all.filter(t => READ_ONLY_TOOLS.has(t.name));
  const byName = new Map(readable.map(t => [t.name, t]));
  // Only concurrent identical requests share work. Completed responses are never cached.
  const inFlight = new Map<string, Promise<unknown>>();
  const server = new Server({ name: 'sfmc-efficient-gateway', version: '1.0.0' }, { capabilities: { tools: {} } });
  server.setRequestHandler(ListToolsRequestSchema, async () => ({ tools: definitions.map(d => ({ name: d.name, description: d.description, inputSchema: zodToJsonSchema(d.schema, { target: 'jsonSchema7' }) as Tool['inputSchema'], annotations: { readOnlyHint: true, destructiveHint: false } })) }));
  server.setRequestHandler(CallToolRequestSchema, async req => {
    try {
      if (req.params.name === 'sfmc_find_tools') {
        const input = searchSchema.parse(req.params.arguments ?? {});
        const words = input.query.toLowerCase().split(/\s+/).filter(Boolean);
        const matches = readable.filter(t => words.every(w => `${t.name} ${t.description}`.toLowerCase().includes(w)));
        return { content: [{ type: 'text', text: boundedJson({ upstream: upstream.getServerVersion(), upstreamTools: all.length, readOnlyTools: readable.length, matches: matches.length, tools: matches.slice(input.offset, input.offset + input.limit), nextOffset: input.offset + input.limit < matches.length ? input.offset + input.limit : null }, 24000) }] };
      }
      if (req.params.name !== 'sfmc_read') throw new Error('Unknown gateway tool');
      const input = callSchema.parse(req.params.arguments ?? {});
      if (!byName.has(input.tool)) {
        return { isError: true, content: [{ type: 'text', text: JSON.stringify({ error: 'Tool unavailable or blocked by the read-only allowlist. Writes require explicit user approval and the original server. Token retrieval is never exposed.' }) }] };
      }
      const key = JSON.stringify([input.tool, input.arguments]);
      let pending = inFlight.get(key);
      if (!pending) {
        pending = upstream.callTool({ name: input.tool, arguments: input.arguments }, undefined, { timeout: 30000 });
        inFlight.set(key, pending);
      }
      let raw: unknown;
      try { raw = await pending; } finally { if (inFlight.get(key) === pending) inFlight.delete(key); }
      const result = raw as { isError?: boolean; content?: Array<{ type: string; text?: string }> };
      const data = (result.content ?? []).map(block => {
        if (block.type !== 'text') return { type: block.type, omitted: true };
        try { return JSON.parse(block.text ?? 'null') as unknown; } catch { return block.text ?? ''; }
      });
      return { isError: result.isError, content: [{ type: 'text', text: boundedJson({ tool: input.tool, httpStatus: null, statusNote: 'Upstream returns response bodies without successful HTTP status or endpoint metadata.', data: compactPayload(data.length === 1 ? data[0] : data, input.maxItems, input.fields) }) }] };
    } catch (error) {
      return { isError: true, content: [{ type: 'text', text: JSON.stringify({ error: error instanceof z.ZodError ? 'Invalid arguments; inspect the tool schema.' : 'Upstream request failed or timed out. Authentication details are suppressed.' }) }] };
    }
  });
  const shutdown = async () => { await server.close(); await upstream.close(); process.exit(0); };
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
  await server.connect(new StdioServerTransport());
  server.onclose = () => { void upstream.close(); };
}
main().catch(() => { console.error('SFMC gateway startup failed. Check the upstream command and saved account configuration.'); process.exit(1); });
