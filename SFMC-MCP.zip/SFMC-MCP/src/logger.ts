/**
 * Minimal stderr logger. stdout is reserved for the MCP protocol stream,
 * so EVERYTHING the server emits for humans must go to stderr.
 */

type Level = 'debug' | 'info' | 'warn' | 'error';

const LEVEL_RANK: Record<Level, number> = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40
};

function isDebugEnabled(): boolean {
  const raw = process.env.DEBUG;
  if (!raw) return false;
  const v = raw.toLowerCase();
  return v === '1' || v === 'true' || v === 'yes' || v === 'on';
}

const threshold: number = isDebugEnabled() ? LEVEL_RANK.debug : LEVEL_RANK.info;

function emit(level: Level, prefix: string, args: unknown[]): void {
  if (LEVEL_RANK[level] < threshold) return;
  const ts = new Date().toISOString();
  const line = `${ts} ${level.toUpperCase()} ${prefix} ${args
    .map((a) => (typeof a === 'string' ? a : safeStringify(a)))
    .join(' ')}`;
  // eslint-disable-next-line no-console -- stderr is the only legal log sink.
  console.error(line);
}

function safeStringify(value: unknown): string {
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

export interface Logger {
  debug: (...args: unknown[]) => void;
  info: (...args: unknown[]) => void;
  warn: (...args: unknown[]) => void;
  error: (...args: unknown[]) => void;
  child: (suffix: string) => Logger;
}

export function createLogger(prefix: string): Logger {
  const fullPrefix = `[${prefix}]`;
  return {
    debug: (...a) => emit('debug', fullPrefix, a),
    info: (...a) => emit('info', fullPrefix, a),
    warn: (...a) => emit('warn', fullPrefix, a),
    error: (...a) => emit('error', fullPrefix, a),
    child: (suffix: string) => createLogger(`${prefix}:${suffix}`)
  };
}

export const rootLogger = createLogger('mcp');
