/**
 * Shared types used across the SFMC and Datorama integrations.
 */

export interface ApiErrorShape {
  status: number;
  message: string;
  code?: string | number;
  details?: unknown;
  requests?: unknown[];
}

/**
 * Thrown when an upstream API returns a structured error we want to surface
 * verbatim through MCP (i.e. not retry it, not mask the message).
 */
export class UpstreamApiError extends Error {
  readonly status: number;
  readonly code?: string | number;
  readonly details?: unknown;

  constructor(shape: ApiErrorShape) {
    super(shape.message);
    this.name = 'UpstreamApiError';
    this.status = shape.status;
    this.code = shape.code;
    this.details = shape.details;
  }

  toJSON(): ApiErrorShape {
    return {
      status: this.status,
      message: this.message,
      code: this.code,
      details: this.details
    };
  }
}

/**
 * Discriminated tool-call result returned by every tool handler.
 */
export type ToolHandlerResult =
  | { ok: true; data: unknown }
  | { ok: false; error: ApiErrorShape };
