import axios from 'axios';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { SfmcAuth } from '../src/auth/sfmc-auth.js';
import { SfmcClient } from '../src/sfmc/client.js';
import { traceCall } from '../src/advanced/trace.js';
import { createLogger } from '../src/logger.js';
vi.mock('axios');
const mock = axios as unknown as { post: ReturnType<typeof vi.fn>; request: ReturnType<typeof vi.fn> };
function make() {
  const logger = createLogger('advanced-test');
  const auth = new SfmcAuth({ subdomain: 'primary', clientId: 'id', clientSecret: 'secret', accountId: '1', logger });
  const secondary = new SfmcAuth({ subdomain: 'secondary', clientId: 'other', clientSecret: 'other-secret', accountId: '2', logger });
  return new SfmcClient({ auth, logger, subdomain: 'primary', buAuthMap: new Map([['2', secondary]]) });
}
beforeEach(() => {
  mock.post = vi.fn().mockResolvedValue({ data: { access_token: 'test-token', expires_in: 1080, rest_instance_url: 'https://primary.rest.marketingcloudapis.com', soap_instance_url: 'https://primary.soap.marketingcloudapis.com' } });
  mock.request = vi.fn().mockResolvedValue({ status: 200, data: { ok: true } });
});
describe('advanced transport', () => {
  it('reports the actual endpoint and HTTP status', async () => {
    const result = await traceCall(() => make().rest({ method: 'GET', path: '/example' }));
    expect(result.requests[0]).toMatchObject({ endpoint: 'https://primary.rest.marketingcloudapis.com/example', method: 'GET', status: 200 });
    expect(mock.request.mock.calls[0][0]).toMatchObject({ maxRedirects: 0, timeout: 30000 });
  });
  it('uses the selected account token and tenant endpoint for REST and SOAP', async () => {
    mock.post.mockResolvedValue({ data: { access_token: 'secondary-token', expires_in: 1080, rest_instance_url: 'https://secondary.rest.marketingcloudapis.com', soap_instance_url: 'https://secondary.soap.marketingcloudapis.com' } });
    const client = make();
    await client.rest({ method: 'GET', path: '/example', accountId: '2' });
    await client.soap({ soapAction: 'Retrieve', envelope: '<fueloauth>stale</fueloauth>', accountId: '2' });
    expect(mock.post.mock.calls[0][1]).toMatchObject({ client_id: 'other', account_id: '2' });
    expect(mock.request.mock.calls[0][0].url).toBe('https://secondary.rest.marketingcloudapis.com/example');
    expect(mock.request.mock.calls[1][0].url).toBe('https://secondary.soap.marketingcloudapis.com/Service.asmx');
    expect(mock.request.mock.calls[1][0].data).toContain('<fueloauth>secondary-token</fueloauth>');
  });
  it('does not retry failed writes, and preserves failure status metadata', async () => {
    mock.request.mockRejectedValue({ response: { status: 503, data: { message: 'Unavailable' } } });
    const request = traceCall(() => make().rest({ method: 'POST', path: '/asset/v1/content/assets', body: {} }));
    await expect(request).rejects.toMatchObject({ status: 503, apiRequests: [expect.objectContaining({ status: 503, method: 'POST' })] });
    expect(mock.request).toHaveBeenCalledTimes(1);
  });
  it('refreshes both the SOAP token header and envelope after a 401', async () => {
    mock.post.mockResolvedValueOnce({ data: { access_token: 'old', expires_in: 1080, soap_instance_url: 'https://primary.soap.marketingcloudapis.com' } }).mockResolvedValueOnce({ data: { access_token: 'fresh', expires_in: 1080, soap_instance_url: 'https://primary.soap.marketingcloudapis.com' } });
    mock.request.mockRejectedValueOnce({ response: { status: 401, data: { message: 'Expired' } } }).mockResolvedValueOnce({ status: 200, data: '<Results />' });
    await make().soap({ soapAction: 'Retrieve', envelope: '<fueloauth xmlns="http://exacttarget.com">old</fueloauth>' });
    expect(mock.request.mock.calls[1][0].headers.Authorization).toBe('Bearer fresh');
    expect(mock.request.mock.calls[1][0].data).toContain('>fresh</fueloauth>');
  });
  it('rejects non-SFMC instance hosts before attaching the token to any API request', async () => {
    mock.post.mockResolvedValue({ data: { access_token: 'test-token', expires_in: 1080, rest_instance_url: 'https://outside.example' } });
    await expect(make().rest({ method: 'GET', path: '/example' })).rejects.toThrow('SFMC tenant');
    expect(mock.request).not.toHaveBeenCalled();
  });
});
