import { describe, expect, it } from 'vitest';
import { toMcpResult, toTextContent } from '../src/utils/response.js';

describe('response utils', () => {
  it('serializes a small payload directly', () => {
    const out = toTextContent({ hello: 'world' });
    expect(out).toEqual([{ type: 'text', text: JSON.stringify({ hello: 'world' }, null, 2) }]);
  });

  it('truncates payloads exceeding the byte cap with a marker', () => {
    const oldCap = process.env.MCP_MAX_RESPONSE_BYTES;
    process.env.MCP_MAX_RESPONSE_BYTES = '2048';
    try {
      const big = { rows: Array.from({ length: 1000 }, (_, i) => ({ i, pad: 'x'.repeat(100) })) };
      const out = toTextContent(big);
      expect(out[0].text).toContain('TRUNCATED');
      expect(Buffer.byteLength(out[0].text, 'utf8')).toBeLessThan(3000);
    } finally {
      if (oldCap === undefined) delete process.env.MCP_MAX_RESPONSE_BYTES;
      else process.env.MCP_MAX_RESPONSE_BYTES = oldCap;
    }
  });

  it('toMcpResult sets isError on failures', () => {
    const r = toMcpResult({
      ok: false,
      error: { status: 404, message: 'not found' }
    });
    expect(r.isError).toBe(true);
    expect(r.content[0].text).toContain('not found');
  });
});
