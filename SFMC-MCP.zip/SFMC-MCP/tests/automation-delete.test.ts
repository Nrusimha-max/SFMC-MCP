import axios from 'axios';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { SfmcAuth } from '../src/auth/sfmc-auth.js';
import { createLogger } from '../src/logger.js';
import { SfmcClient } from '../src/sfmc/client.js';
import { deleteAutomation } from '../src/sfmc/automation.js';

vi.mock('axios');
const mockedAxios = axios as unknown as {
  post: ReturnType<typeof vi.fn>;
  request: ReturnType<typeof vi.fn>;
  isAxiosError: ReturnType<typeof vi.fn>;
};

function buildCtx() {
  const logger = createLogger('test');
  const auth = new SfmcAuth({ subdomain: 'mc-test', clientId: 'cid', clientSecret: 'secret', accountId: '1', logger });
  const client = new SfmcClient({ auth, logger, subdomain: 'mc-test' });
  return { client, logger, resolveAccountId: () => undefined };
}

const deleteOk = `<soap:Envelope><soap:Body><DeleteResponse><Results><StatusCode>OK</StatusCode><StatusMessage>Automation deleted</StatusMessage></Results><OverallStatus>OK</OverallStatus></DeleteResponse></soap:Body></soap:Envelope>`;
const deleteFailed = `<soap:Envelope><soap:Body><DeleteResponse><Results><StatusCode>Error</StatusCode><StatusMessage>Automation not found</StatusMessage></Results><OverallStatus>Error</OverallStatus></DeleteResponse></soap:Body></soap:Envelope>`;

function restFailure(status: number) {
  return Object.assign(new Error(`Request failed with status code ${status}`), {
    isAxiosError: true,
    response: { status, data: `<h1>${status} Service Not Found</h1>`, headers: {} }
  });
}

describe('deleteAutomation', () => {
  beforeEach(() => {
    mockedAxios.post = vi.fn().mockResolvedValue({
      data: {
        access_token: 'tok',
        token_type: 'Bearer',
        expires_in: 1080,
        rest_instance_url: 'https://mc-test.rest.marketingcloudapis.com',
        soap_instance_url: 'https://mc-test.soap.marketingcloudapis.com'
      }
    });
    mockedAxios.request = vi.fn();
    mockedAxios.isAxiosError = vi.fn((e: { isAxiosError?: boolean }) => Boolean(e?.isAxiosError));
  });
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('falls back to SOAP Delete when automation v2 returns 596', async () => {
    mockedAxios.request
      .mockRejectedValueOnce(restFailure(596))
      .mockResolvedValueOnce({ status: 200, data: deleteOk });

    const result = await deleteAutomation(buildCtx(), { id: 'auto-1' });

    expect(result).toMatchObject({ id: 'auto-1', status: 'OK' });
    const soapCall = mockedAxios.request.mock.calls[1][0];
    expect(soapCall.headers.SOAPAction).toBe('Delete');
    expect(soapCall.data).toContain('<Objects xsi:type="Automation"><ObjectID>auto-1</ObjectID></Objects>');
  });

  it('reports a SOAP delete failure instead of claiming success', async () => {
    mockedAxios.request
      .mockRejectedValueOnce(restFailure(404))
      .mockResolvedValueOnce({ status: 200, data: deleteFailed });

    await expect(deleteAutomation(buildCtx(), { id: 'missing' })).rejects.toThrow(/Automation not found|Delete Automation failed/);
  });
});
