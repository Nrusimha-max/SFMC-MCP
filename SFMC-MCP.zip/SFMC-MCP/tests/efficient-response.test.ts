import { describe, expect, it } from 'vitest';
import { boundedJson, compactPayload } from '../src/utils/efficient-response.js';
import { READ_ONLY_TOOLS } from '../src/sfmc/read-only-tools.js';

describe('efficient gateway safety and output limits', () => {
  it('blocks tokens, writes and unknown tools', () => {
    for (const tool of ['sfmc_get_token', 'sfmc_journey_publish', 'sfmc_soap_automation_start', 'sfmc_contact_delete', 'sfmc_de_upsert_rows_by_key', 'sfmc_push_send_to_list', 'sfmc_new_tool']) {
      expect(READ_ONLY_TOOLS.has(tool)).toBe(false);
    }
    expect(READ_ONLY_TOOLS.has('sfmc_journey_list')).toBe(true);
  });
  it('preserves counts, projects fields, marks omitted records and redacts secrets', () => {
    expect(compactPayload({ count: 3, access_token: 'sensitive', items: [{ id: 1, html: 'large' }, { id: 2 }, { id: 3 }] }, 1, ['id'])).toEqual({ count: 3, access_token: '[REDACTED]', items: { items: [{ id: 1 }], returned: 1, available: 3, truncated: true } });
  });
  it('keeps oversized unicode payloads valid JSON within the byte cap', () => {
    const result = boundedJson({ text: '\"漢😀'.repeat(10000) }, 2048);
    expect(Buffer.byteLength(result)).toBeLessThanOrEqual(2048);
    expect(JSON.parse(result).truncated).toBe(true);
    expect(JSON.parse(result).originalBytes).toBeGreaterThan(2048);
  });
  it('keeps small responses complete and compact', () => {
    expect(boundedJson({ count: 0, items: [] })).toBe('{"count":0,"items":[]}');
  });
});
