import { describe, expect, it, vi } from 'vitest';
import { getJourneyActivity, getJourneyGraph } from '../src/sfmc/contacts.js';
import type { SfmcToolContext } from '../src/sfmc/context.js';

const journey = {
  id: 'journey-1', key: 'journey-key', name: 'Example', version: 1, status: 'Draft',
  activities: [
    { key: 'DECISION-1', name: 'Locale?', type: 'MULTICRITERIADECISION', outcomes: [{ key: 'yes', next: 'EMAIL-1', metaData: { label: 'French' } }] },
    { key: 'EMAIL-1', name: 'QUE T1', type: 'EMAILV2', outcomes: [] }
  ]
};

function context() {
  return {
    client: { rest: vi.fn(async () => journey) },
    resolveAccountId: vi.fn(() => '123')
  } as unknown as SfmcToolContext;
}

describe('journey graph inspection', () => {
  it('returns a complete compact graph with typed nodes and links', async () => {
    const result = await getJourneyGraph(context(), { bu: 'CAN - MIK', id: 'journey-1' }) as any;
    expect(result.activityCount).toBe(2);
    expect(result.typeCounts).toEqual({ MULTICRITERIADECISION: 1, EMAILV2: 1 });
    expect(result.nodes[0].outcomes).toEqual([{ key: 'yes', label: 'French', next: 'EMAIL-1' }]);
  });

  it('returns one full activity by key and rejects unknown keys', async () => {
    await expect(getJourneyActivity(context(), { bu: 'CAN - MIK', id: 'journey-1', activityKey: 'EMAIL-1' }))
      .resolves.toMatchObject({ activity: { key: 'EMAIL-1', name: 'QUE T1' } });
    await expect(getJourneyActivity(context(), { bu: 'CAN - MIK', id: 'journey-1', activityKey: 'MISSING' }))
      .rejects.toThrow('Activity key not found');
  });
});
