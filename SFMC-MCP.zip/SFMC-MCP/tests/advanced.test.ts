import { afterEach, describe, expect, it, vi } from 'vitest';
import { mkdtemp, readFile, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { z } from 'zod';
import { PlanStore } from '../src/advanced/plans.js';
import { restIsRead, validateRestPath } from '../src/advanced/policy.js';
import { AdvancedRuntime, type RuntimeTool } from '../src/advanced/runtime.js';
import { recordApi } from '../src/advanced/trace.js';
import type { SfmcToolContext } from '../src/sfmc/context.js';

const dirs: string[] = [];
const previous = process.env.SFMC_PLAN_DIRECTORY;
afterEach(async () => {
  if (previous === undefined) delete process.env.SFMC_PLAN_DIRECTORY; else process.env.SFMC_PLAN_DIRECTORY = previous;
  await Promise.all(dirs.splice(0).map(path => rm(path, { recursive: true, force: true })));
});
async function directory() { const dir = await mkdtemp(join(tmpdir(), 'sfmc-plans-')); dirs.push(dir); return dir; }
async function runtime() {
  process.env.SFMC_PLAN_DIRECTORY = await directory();
  const read = vi.fn(async () => { recordApi({ endpoint: 'https://test.rest.marketingcloudapis.com/example', method: 'GET', status: 200, durationMs: 1 }); return { count: 1 }; });
  const write = vi.fn(async () => ({ changed: true }));
  const tools = new Map<string, RuntimeTool>([
    ['sfmc_list_journeys', { name: 'sfmc_list_journeys', description: 'Read', schema: z.object({}).strict(), handler: read }],
    ['sfmc_create_asset', { name: 'sfmc_create_asset', description: 'Write', schema: z.object({ name: z.string() }).strict(), handler: write }]
  ]);
  const ctx = { client: { rest: vi.fn(async () => ({})) }, resolveAccountId: () => undefined } as unknown as SfmcToolContext;
  const instance = new AdvancedRuntime(tools, ctx, []);
  for (const tool of instance.definitions()) tools.set(tool.name, tool);
  return { instance, read, write };
}

describe('advanced API controls', () => {
  it.each(['https://outside.example/x', '//outside/x', '/a/../b', '/a/%252e%252e/b', '/a%2fb/..', '/a?token=x', '/a#x', '/a\\b'])('rejects unsafe REST path %s', path => {
    expect(() => validateRestPath(path)).toThrow();
  });
  it('accepts tenant paths and distinguishes read-only POST queries from writes', () => {
    expect(() => validateRestPath('/data/v1/customobjectdata/key/My%20DE/rowset')).not.toThrow();
    expect(restIsRead('POST', '/asset/v1/content/assets/query')).toBe(true);
    expect(restIsRead('POST', '/interaction/v1/events')).toBe(false);
  });
  it('requires approval and consumes each approval only once across concurrent executions', async () => {
    const store = new PlanStore(await directory());
    const plan = await store.prepare('sfmc_create_asset', { name: 'Example' });
    await expect(store.consume(plan.id)).rejects.toThrow('approval');
    await store.approve(plan.id);
    const results = await Promise.allSettled([store.consume(plan.id), store.consume(plan.id)]);
    expect(results.filter(result => result.status === 'fulfilled')).toHaveLength(1);
    await expect(store.consume(plan.id)).rejects.toThrow();
  });
  it('rejects expired and tampered plans', async () => {
    const dir = await directory(); const store = new PlanStore(dir);
    const plan = await store.prepare('sfmc_create_asset', { name: 'Original' });
    const path = join(dir, `${plan.id}.json`);
    const json = JSON.parse(await readFile(path, 'utf8')); json.arguments.name = 'Changed';
    await writeFile(path, JSON.stringify(json));
    await expect(store.approve(plan.id)).rejects.toThrow('integrity');
    json.arguments.name = 'Original'; json.expiresAt = Date.now() - 1;
    await writeFile(path, JSON.stringify(json));
    await expect(store.approve(plan.id)).rejects.toThrow('expired');
  });
  it('blocks original write tools and generic REST writes before network dispatch', async () => {
    const { instance, write } = await runtime();
    await expect(instance.invoke('sfmc_create_asset', { name: 'Test' })).rejects.toThrow('approval');
    await expect(instance.invoke('sfmc_rest_request', { method: 'DELETE', path: '/asset/v1/content/assets/1' })).rejects.toThrow('approval');
    expect(write).not.toHaveBeenCalled();
  });
  it('prepares without executing, then executes only exact approved arguments once', async () => {
    const { instance, write } = await runtime();
    const prepared = await instance.invoke('sfmc_prepare_change', { tool: 'sfmc_create_asset', arguments: { name: 'Reviewed' } }) as any;
    const id = prepared.data.planId;
    expect(write).not.toHaveBeenCalled();
    await expect(instance.invoke('sfmc_execute_change', { planId: id })).rejects.toThrow('approval');
    await instance.plans.approve(id);
    await instance.invoke('sfmc_execute_change', { planId: id });
    expect(write).toHaveBeenCalledTimes(1);
    expect(write).toHaveBeenCalledWith({ name: 'Reviewed' });
    await expect(instance.invoke('sfmc_execute_change', { planId: id })).rejects.toThrow();
    expect(write).toHaveBeenCalledTimes(1);
  });
  it('keeps transport metadata when projecting a discovered read and rejects nested control calls', async () => {
    const { instance } = await runtime();
    const result = await instance.invoke('sfmc_call_tool', { tool: 'sfmc_list_journeys', fields: ['id'] }) as any;
    expect(result.data.requests[0]).toMatchObject({ method: 'GET', status: 200 });
    await expect(instance.invoke('sfmc_call_tool', { tool: 'sfmc_execute_change', arguments: { planId: '00000000-0000-4000-8000-000000000000' } })).rejects.toThrow('read-only');
  });
  it('validates all batch calls before dispatch and preserves per-call API metadata', async () => {
    const { instance, read } = await runtime();
    await expect(instance.invoke('sfmc_batch_read', { calls: [{ tool: 'sfmc_list_journeys' }, { tool: 'sfmc_create_asset', arguments: { name: 'Blocked' } }] })).rejects.toThrow('read-only');
    expect(read).not.toHaveBeenCalled();
    const result = await instance.invoke('sfmc_batch_read', { calls: [{ tool: 'sfmc_list_journeys' }, { tool: 'sfmc_list_journeys' }], concurrency: 2 }) as any;
    expect(result.data.results).toHaveLength(2);
    for (const call of result.data.results) expect(call.requests).toEqual([{ endpoint: 'https://test.rest.marketingcloudapis.com/example', method: 'GET', status: 200, durationMs: 1 }]);
  });
});
