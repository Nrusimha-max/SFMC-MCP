import { describe, expect, it } from 'vitest';
import { DatoramaAuth } from '../src/auth/datorama-auth.js';
import { createLogger } from '../src/logger.js';

describe('DatoramaAuth', () => {
  it('builds the US region base URL by default', () => {
    const auth = new DatoramaAuth({
      apiToken: 'abc',
      region: 'us',
      logger: createLogger('test')
    });
    expect(auth.baseUrl).toBe('https://api.datorama.com');
  });

  it('builds the EU region base URL', () => {
    const auth = new DatoramaAuth({
      apiToken: 'abc',
      region: 'eu',
      logger: createLogger('test')
    });
    expect(auth.baseUrl).toBe('https://api.eu.datorama.com');
  });

  it('builds the AP region base URL', () => {
    const auth = new DatoramaAuth({
      apiToken: 'abc',
      region: 'ap',
      logger: createLogger('test')
    });
    expect(auth.baseUrl).toBe('https://api.ap.datorama.com');
  });

  it('honors an explicit baseUrl override', () => {
    const auth = new DatoramaAuth({
      apiToken: 'abc',
      region: 'us',
      logger: createLogger('test'),
      baseUrl: 'https://custom.example.com'
    });
    expect(auth.baseUrl).toBe('https://custom.example.com');
  });

  it('produces the correct Authorization header', async () => {
    const auth = new DatoramaAuth({
      apiToken: 'super-secret',
      region: 'us',
      logger: createLogger('test')
    });
    expect(await auth.authHeader()).toEqual({ Authorization: 'Token super-secret' });
  });

  it('handleUnauthorized does not throw (no refresh to perform)', async () => {
    const auth = new DatoramaAuth({
      apiToken: 'abc',
      region: 'us',
      logger: createLogger('test')
    });
    await expect(auth.handleUnauthorized()).resolves.toBeUndefined();
  });
});
