import axios from 'axios';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { SfmcAuth } from '../src/auth/sfmc-auth.js';
import { createLogger } from '../src/logger.js';
import { SfmcClient } from '../src/sfmc/client.js';
import { getDataExtensionRows, upsertDataExtensionRows } from '../src/sfmc/tools.js';

vi.mock('axios');
const mockedAxios = axios as unknown as {
  post: ReturnType<typeof vi.fn>;
  request: ReturnType<typeof vi.fn>;
};

function buildClient(): SfmcClient {
  const logger = createLogger('test');
  const auth = new SfmcAuth({
    subdomain: 'mc-test',
    clientId: 'cid',
    clientSecret: 'secret',
    accountId: '1',
    logger
  });
  return new SfmcClient({ auth, logger, subdomain: 'mc-test' });
}

describe('SFMC tools', () => {
  beforeEach(() => {
    mockedAxios.post = vi.fn().mockResolvedValue({
      data: {
        access_token: 'tok',
        token_type: 'Bearer',
        expires_in: 1080,
        rest_instance_url: 'https://mc-test.rest.marketingcloudapis.com'
      }
    });
    mockedAxios.request = vi.fn();
  });
  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('getDataExtensionRows', () => {
    it('issues a REST GET with $top/$skip/$filter and flattens keys+values', async () => {
      mockedAxios.request.mockResolvedValueOnce({
        status: 200,
        data: {
          count: 2,
          items: [
            { keys: { SubscriberKey: 'a' }, values: { EmailAddress: 'a@x.com' } },
            { keys: { SubscriberKey: 'b' }, values: { EmailAddress: 'b@x.com' } }
          ]
        }
      });

      const client = buildClient();
      const result = (await getDataExtensionRows(
        { client, logger: createLogger('t'), resolveAccountId: () => undefined },
        { key: 'MyDE', top: 10, skip: 5, filter: "Status eq 'Active'" }
      )) as { rows: Array<Record<string, unknown>>; total: number };

      expect(result.total).toBe(2);
      expect(result.rows).toEqual([
        { SubscriberKey: 'a', EmailAddress: 'a@x.com' },
        { SubscriberKey: 'b', EmailAddress: 'b@x.com' }
      ]);
      const call = mockedAxios.request.mock.calls[0][0];
      expect(call.method).toBe('GET');
      expect(call.url).toContain('/data/v1/customobjectdata/key/MyDE/rowset');
      expect(call.params).toMatchObject({
        $top: 10,
        $skip: 5,
        $filter: "Status eq 'Active'",
        $inlinecount: 'allpages'
      });
      expect(call.headers.Authorization).toBe('Bearer tok');
    });

    it('retries once on 401 after refreshing the token', async () => {
      // First call: 401 → triggers refresh. Second call: success.
      mockedAxios.request
        .mockRejectedValueOnce({
          response: { status: 401, data: { message: 'expired' }, headers: {} },
          message: '401'
        })
        .mockResolvedValueOnce({
          status: 200,
          data: { count: 0, items: [] }
        });
      // Also mock the auth refresh call (second axios.post)
      mockedAxios.post.mockResolvedValue({
        data: { access_token: 'tok2', token_type: 'Bearer', expires_in: 1080 }
      });

      const client = buildClient();
      const result = (await getDataExtensionRows(
        { client, logger: createLogger('t'), resolveAccountId: () => undefined },
        { key: 'K', top: 5, skip: 0 }
      )) as { rows: unknown[] };

      expect(result.rows).toEqual([]);
      expect(mockedAxios.request).toHaveBeenCalledTimes(2);
    });
  });

  describe('upsertDataExtensionRows', () => {
    it('POSTs to the async endpoint and returns the requestId', async () => {
      mockedAxios.request.mockResolvedValueOnce({
        status: 202,
        data: { requestId: 'req-123' }
      });

      const client = buildClient();
      const result = (await upsertDataExtensionRows(
        { client, logger: createLogger('t'), resolveAccountId: () => undefined },
        { key: 'Subs', rows: [{ EmailAddress: 'a@x.com', SubscriberKey: 'a' }] }
      )) as { requestId: string; submittedRows: number };

      expect(result.requestId).toBe('req-123');
      expect(result.submittedRows).toBe(1);
      const call = mockedAxios.request.mock.calls[0][0];
      expect(call.method).toBe('POST');
      expect(call.url).toContain('/data/v1/async/dataextensions/key:Subs/rows');
      expect(call.data).toEqual({
        items: [{ EmailAddress: 'a@x.com', SubscriberKey: 'a' }]
      });
    });

    it('surfaces a 400 from the API as an UpstreamApiError with the API message', async () => {
      mockedAxios.request.mockRejectedValueOnce({
        response: {
          status: 400,
          data: {
            errors: [{ message: 'Field FavoriteColor is required', errorcode: 10000 }]
          },
          headers: {}
        },
        message: 'Request failed'
      });

      const client = buildClient();
      await expect(
        upsertDataExtensionRows(
          { client, logger: createLogger('t'), resolveAccountId: () => undefined },
          { key: 'Subs', rows: [{ SubscriberKey: 'a' }] }
        )
      ).rejects.toMatchObject({
        status: 400,
        message: 'Field FavoriteColor is required',
        code: 10000
      });
    });
  });
});
