import axios from 'axios';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { DatoramaAuth } from '../src/auth/datorama-auth.js';
import { DatoramaClient } from '../src/datorama/client.js';
import { listWorkspaces, runQuery } from '../src/datorama/tools.js';
import { createLogger } from '../src/logger.js';

vi.mock('axios');
const mockedAxios = axios as unknown as { request: ReturnType<typeof vi.fn> };

function buildCtx() {
  const logger = createLogger('test');
  const auth = new DatoramaAuth({ apiToken: 'tok', region: 'us', logger });
  const client = new DatoramaClient({ auth, logger });
  return { client, logger, defaultWorkspaceId: 'ws-default' };
}

describe('Datorama tools', () => {
  beforeEach(() => {
    mockedAxios.request = vi.fn();
  });
  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('listWorkspaces', () => {
    it('hits /v1/workspaces with the Token auth header', async () => {
      mockedAxios.request.mockResolvedValueOnce({
        status: 200,
        data: [
          { id: 'w1', name: 'Workspace One', timezone: 'UTC', currency: 'USD' },
          { id: 'w2', name: 'Workspace Two' }
        ]
      });

      const result = (await listWorkspaces(buildCtx(), {})) as {
        count: number;
        items: Array<{ id: string; name: string }>;
      };

      expect(result.count).toBe(2);
      expect(result.items[0]).toMatchObject({ id: 'w1', name: 'Workspace One' });
      const call = mockedAxios.request.mock.calls[0][0];
      expect(call.method).toBe('GET');
      expect(call.url).toBe('https://api.datorama.com/v1/workspaces');
      expect(call.headers.Authorization).toBe('Token tok');
    });
  });

  describe('runQuery', () => {
    it('POSTs to /v2/query/sources/workspace/{id} with the body shape', async () => {
      mockedAxios.request.mockResolvedValueOnce({
        status: 200,
        data: {
          totalRows: 1,
          columns: [{ name: 'channel' }, { name: 'spend' }],
          rows: [{ channel: 'Search', spend: 12345.67 }]
        }
      });

      const ctx = buildCtx();
      const result = (await runQuery(ctx, {
        measurements: [{ name: 'spend' }],
        dimensions: [{ name: 'channel' }],
        dateRange: { startDate: '2026-01-01', endDate: '2026-03-31' },
        filters: [],
        limit: 500,
        offset: 0
      })) as { rows: unknown[]; workspaceId: string };

      expect(result.workspaceId).toBe('ws-default');
      expect(result.rows).toEqual([{ channel: 'Search', spend: 12345.67 }]);
      const call = mockedAxios.request.mock.calls[0][0];
      expect(call.method).toBe('POST');
      expect(call.url).toContain('/v2/query/sources/workspace/ws-default');
      expect(call.data).toMatchObject({
        measurements: [{ name: 'spend' }],
        dimensions: [{ name: 'channel' }],
        dateRange: { startDate: '2026-01-01', endDate: '2026-03-31' }
      });
    });

    it('honors an explicit workspaceId override', async () => {
      mockedAxios.request.mockResolvedValueOnce({
        status: 200,
        data: { totalRows: 0, rows: [], columns: [] }
      });

      const result = (await runQuery(buildCtx(), {
        workspaceId: 'ws-explicit',
        measurements: [{ name: 'impressions' }],
        dimensions: [],
        dateRange: { startDate: '2026-04-01', endDate: '2026-04-30' },
        filters: [],
        limit: 100,
        offset: 0
      })) as { workspaceId: string };

      expect(result.workspaceId).toBe('ws-explicit');
      const call = mockedAxios.request.mock.calls[0][0];
      expect(call.url).toContain('/v2/query/sources/workspace/ws-explicit');
    });

    it('respects Retry-After on 429 and retries', async () => {
      // First call: 429 with Retry-After. Second call: success.
      mockedAxios.request
        .mockRejectedValueOnce({
          response: {
            status: 429,
            headers: { 'retry-after': '0' },
            data: { errorMessage: 'Rate limited' }
          },
          message: '429'
        })
        .mockResolvedValueOnce({
          status: 200,
          data: { totalRows: 0, rows: [], columns: [] }
        });

      const result = await runQuery(buildCtx(), {
        measurements: [{ name: 'spend' }],
        dimensions: [],
        dateRange: { startDate: '2026-01-01', endDate: '2026-01-31' },
        filters: [],
        limit: 10,
        offset: 0
      });

      expect(result).toBeDefined();
      expect(mockedAxios.request).toHaveBeenCalledTimes(2);
    });

    it('throws when no workspace is configured or passed', async () => {
      const logger = createLogger('test');
      const auth = new DatoramaAuth({ apiToken: 'tok', region: 'us', logger });
      const client = new DatoramaClient({ auth, logger });
      await expect(
        runQuery(
          { client, logger, defaultWorkspaceId: undefined },
          {
            measurements: [{ name: 'spend' }],
            dimensions: [],
            dateRange: { startDate: '2026-01-01', endDate: '2026-01-31' },
            filters: [],
            limit: 10,
            offset: 0
          }
        )
      ).rejects.toThrow(/workspaceId is required/);
    });
  });
});
