# SFMC Builder — Send relationship E4

This release preserves the current UI v2 and existing Installed Package configuration. It does **not** add login, roles, access keys or a different credential store.


## Is Testable checkbox

The DE creation form now has **Is Testable**, enabled when **Is Sendable** is selected. Clearing Is Sendable clears Is Testable. The create request carries the checkbox value. If SFMC's Core Add does not persist a requested true value, the handler updates that setting on the newly created DE and verifies it. If the flag cannot be verified, it reports that the DE was already created and tells you to inspect it before retrying.

The DE editor loads current properties directly from SOAP and can turn the flag on or off for a sendable DE. Missing metadata is shown as unavailable, and saving unrelated edits preserves that unknown value. Finder results include a Testable column. Marking a DE testable does not send a message.

The same three approval/audit supporting DEs remain sufficient; no schema migration or additional DE is required.

## SQL activity and automation-step workflows

### Save SQL independently

Open **SQL Activities → Create SQL Query activity**, enter a name, query folder, target DE, action and SQL, then select **Save query activity**. Review the exact create request and confirm. This only saves the reusable query activity; it does not attach it to a draft or saved automation and does not run it.

### Pick a saved query while building an automation

In **Build Automation**, add/select the destination step, select SQL in the activity picker, load saved activities and choose Add. Alternatively, use **SQL Activities → Saved SQL activities → Draft step**, then explicitly choose a draft step. Creating a new automation uses the resulting draft.

### Create SQL during automation building

Use **Create a SQL Query** from the builder. It opens the SQL workspace. Save the query, then choose **Add to draft step** and select the destination step. Saving alone never changes the draft.

### Add activities after the automation is saved

Use **Add activities to a saved automation** in the builder, **More → Add activity to step** in Automation operations, or **Automation step** in the SQL library. Find the exact automation name/external key, load its saved steps, choose an existing step or append a named new step, and select a saved activity. Review the assignment and confirm.

The workflow supports existing SQL, Import, Script, Data Extract and File Transfer activities from the existing picker. New activity creation in this release is SQL only. It does not introduce new Script/Import/Extract/File Transfer authoring forms.

The attachment handler re-reads the saved automation, checks its topology fingerprint, verifies the saved activity, preserves existing activities and instance IDs, then PATCHes only the steps. It checks again for intervening edits immediately before the PATCH and reads the definition back afterward. This is a best-effort conflict check, not an atomic SFMC lock or a guarantee against edits made in the final request window. Duplicate activities in the same step and changes to running automations are blocked.

A saved query and an automation assignment are two separate changes with separate approvals. If assignment is cancelled or fails, the saved query remains available. Neither operation starts an automation or changes its starting source. This release does not add field deletion, arbitrary activity removal, or empty-automation creation.

No new support DEs are required if the three DEs from Enhanced E1 already exist. The source preserves your existing API configuration, without adding login, roles or a different credential store.

## Added functionality

1. **Exact change previews.** Every DE create/update, query/automation creation, Run once, starting-source save and schedule activation opens a review dialog. DE creation also shows effective field definitions after defaults are applied.
2. **Server-stored approvals.** The approved request is stored server-side, expires after ten minutes and is consumed once. Execute accepts only the plan ID, not a replacement payload. Stored payload chunks are checked with SHA-256. Cancelling never invokes the target mutation.
3. **Business-unit consistency.** Before handling requests, the server compares the hosting CloudPage `memberid` to the existing `CONFIG.accountId`. It blocks mismatches rather than mixing native DE calls with another BU's token-authenticated requests.
4. **Activity history.** The header opens this browser session's recorded operations, timestamps, target MID, plan IDs and outcomes. Audit labels identify a browser session, **not a verified person**. There is no login in this release.
5. **Safer uncertain outcomes.** An initial audit record is required before execution. Duplicate approvals and expired or modified plans are rejected. A failed or uncertain execution consumes its plan; it is not automatically retried. If final auditing fails after a successful operation, the UI tells the user to inspect the target rather than retry.

The existing DE functionality, automation search, REST-only Run once trigger, starting-source options and dropdown/layout fixes are retained.

## Files

- `sfmc-builder-send-relationship.html` — complete CloudPage code, with your existing API configuration preserved. Keep this source private.
- `data-extension-schemas.json` — exact non-sendable DataExtension definitions for the three support DEs.
- `check-enhancements.cjs` — offline approval/audit regression tests.
- `check-activities.cjs` — standalone SQL, draft selection and saved-step attachment tests. Both suites use mocked SFMC services and make no network calls.

## Initial setup

The new approval/audit features need these three DEs **in the hosting CloudPage's BU**, with the exact names and external keys:

- `SFMC_Builder_Plans`
- `SFMC_Builder_Payloads`
- `SFMC_Builder_Audit`

Use the field definitions in `data-extension-schemas.json`. They are SOAP-style DataExtension object definitions, not a Postman collection or a directly executable MCP request. Do not add them to send audiences. Restrict their administrative access appropriately, because the payload DE contains exact proposed changes, including SQL or field defaults supplied by the user.

No support DEs have been provisioned remotely. The configured SFMC MCP accounts did not include MID **100010552** when this package was prepared. Connect the intended BU before asking the agent to prepare exact provisioning plans. Live creates/updates still require explicit approval of the reviewed plan.

After provisioning:

1. Verify that the CloudPage's hosting MID equals the existing `CONFIG.accountId`.
2. Replace the complete CloudPage source with `sfmc-builder-send-relationship.html` and publish through your approved process.
3. Open the published HTTPS URL. There is no sign-in screen.
4. Search/browse normally. A write now prepares an exact request and opens **Review change**. Cancel or confirm there.
5. Check **Activity history** after an approved, low-impact test change.

Until the support DEs exist, metadata reads can still work, but write preparation and activity history will report the missing dependency. Writes do not bypass the approval/audit requirement.

## Session and retention behavior

The browser creates a random review-session identifier and keeps it in sessionStorage for that tab. It is sent only in POST bodies and hashed for server-side ownership checks. This identifier binds a preview to its originating browser session; **it is not authentication or access control**. Anyone who can access the published page can still use the existing application. History is not attributed to a verified user.

Each plan's exact encoded payload is capped at 64,000 characters, split into 3,500-character rows so ordinary multi-field DEs and longer SQL fit SFMC field limits. Oversized changes are rejected, never truncated.

Expired plans cannot execute, but stored rows still need a retention policy. Configure appropriate retention for Plans/Payloads, for example two days, and Audit according to your operational needs, for example 90 days. No cleanup automation is installed by this package.

Audit history is an application trace, not an immutable compliance ledger. It returns the latest 100 events for this session after scanning at most 20 SOAP pages and explicitly marks partial results if that limit is reached. Clearing sessionStorage starts a different history scope.

## Validation and remaining limits

Run the offline checks with Node.js:

```sh
node check-enhancements.cjs
node check-activities.cjs
node check-testable.cjs
```

The tests cover syntax, MID mismatch blocking, effective preview values, cancellation/confirmation, exact saved payloads, expiry, session ownership, chunking, tampering, duplicate attempts, audit failures and direct-write rejection. They use mocked SFMC services.

Native MID resolution, SHA256 bridging, support-DE row operations/conditional updates and real API executions must still be validated in your tenant. Existing tenant-dependent starting-source conversion and REST execution paths remain subject to SFMC's actual responses and read-back checks. This update does not make unsupported API operations supported.

Login/roles and credential-storage changes are deliberately deferred as requested. Enterprise SSO, DE record imports/exports, schema templates and a complete automation workflow editor are not added in this release.

## Send relationship

Select Is Sendable to map a compatible DE field to Subscriber Key (default), Subscriber ID, or Email Address. Alternative subscriber identifiers depend on your account settings. The editor retrieves the saved mapping and changes it only when Change send relationship is checked. Missing relationship metadata disables changes and preserves the existing mapping. Requested relationship updates require matching readback before success is reported. These controls configure metadata and do not send email.

Local mocked regression checks passed; deployment and account-specific acceptance have not been verified live.
