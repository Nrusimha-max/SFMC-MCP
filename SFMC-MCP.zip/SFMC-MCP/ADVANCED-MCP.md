# Advanced SFMC MCP server

The native server now exposes 102 tools: the existing 93 SFMC/Datorama tools plus nine orchestration and transport tools. This supersedes the earlier read-only gateway. No new dependencies or browser access are required.

## Registration status

Registered globally in Codex as `sfmc-advanced` and confirmed enabled. The registered command/environment passed a direct MCP cross-check; evidence is in `.sfmc-verification/registered-server-check.json`. Registration does not hot-reload tools into an already-open chat. Restart/reload the Codex MCP connection when the new tools are absent from that chat. No reload API was exposed in the verification session.

## Launch

Build with `npm run build`. The launcher is `start-advanced-mcp.sh`; ready connection settings are in `mcp-advanced.config.json`. Register that entry in the MCP client and restart the connection. Creating this configuration does not register it automatically; existing app settings have not been changed.

The advanced launcher loads credentials internally from the same saved accounts file used by the working installed `mcp-sfmc` server: `SFMC_CONFIG_PATH`, or `$XDG_CONFIG_HOME/sfmc/accounts.json`, or `~/.config/sfmc/accounts.json`. It ignores the workspace launcher's stale SFMC credential exports. Credentials are neither copied into the launcher nor returned by a tool. Datorama retains its separate existing environment configuration and is not covered by the SFMC live verification.

## New tools

| Tool | Capability |
| --- | --- |
| `sfmc_capabilities` | Search registry; return exact argument schemas on demand |
| `sfmc_business_units` | Discover configured names, MIDs and aliases without credentials |
| `sfmc_connection_health` | Read-only REST authentication/connectivity probe |
| `sfmc_rest_request` | Generic authenticated REST GET, HEAD, POST, PUT, PATCH, DELETE |
| `sfmc_call_tool` | Invoke a discovered read operation; project selected array fields |
| `sfmc_get_journey_graph` | Return every Journey activity as a compact node/edge graph for safe planning |
| `sfmc_get_journey_activity` | Return one complete Journey activity by its key without truncating the rest of the journey |
| `sfmc_batch_read` | Up to 20 independent reads, with 1–4 concurrent requests |
| `sfmc_diagnostics` | Local uptime, active calls, totals, errors, and average duration |
| `sfmc_prepare_change` | Validate and persist an exact change for review; no remote write |
| `sfmc_execute_change` | Execute a locally approved change exactly once |

Existing `sfmc_query_soap` retrieves SFMC objects with properties, filters, and continuation support. Existing typed tools cover DEs, automation activities, journeys, content, subscribers, contacts, account users and analytics. Generic REST provides access to tenant endpoints without requiring a new tool for each endpoint; it does not imply every Salesforce operation is supported by REST. Arbitrary SOAP write envelopes are not exposed; SOAP mutations use the existing typed operations and approval path.

## User-context authentication (changes attributed to a named user)

With server-to-server (`client_credentials`) credentials, SFMC records every change as the installed package's app user. To attribute changes to a person, give a business unit a Web App API integration and authorize it once as that person:

1. An SFMC admin adds a **Web App** API integration to an installed package in the target business unit. It needs the same scopes as the server-to-server package, and its redirect URI is a local address such as `http://localhost:8765/callback`.
2. In the saved accounts file, set that business unit's entry to the Web App credentials and add:

   ```json
   "grant_type": "authorization_code",
   "redirect_uri": "http://localhost:8765/callback",
   "refresh_token_path": "~/.config/sfmc/can-mik.refresh-token"
   ```

3. **The user who should appear on changes** runs `node dist/advanced/authorize-user.js "CAN - MIK"`, opens the printed URL, signs in and approves. The refresh token is saved with mode 0600 and is never printed.
4. Restart the MCP connection. Tokens for that business unit now act as that user, so SFMC shows them as creator, modifier and owner. The token is rotated on every refresh. If it expires or is revoked, repeat step 3.

All other behavior, including the approval workflow, is unchanged.

## Account selection

The `bu` argument accepts a configured business-unit name or MID. `test` means the default saved account; it is a compatibility alias and does **not** establish that the account is a sandbox. `prod` is available only for a separately configured account named Prod or Production, or the existing environment-based production configuration. Never infer environment safety from an alias. Discover exact account names first.

## Read examples

```json
{"method":"GET","path":"/interaction/v1/interactions","query":{"$page":1,"$pageSize":1}}
```

```json
{"tool":"sfmc_list_journeys","arguments":{"top":5},"maxItems":5,"fields":["id","name","status"]}
```

```json
{"concurrency":2,"calls":[{"tool":"sfmc_list_journeys","arguments":{"top":1}},{"tool":"sfmc_query_soap","arguments":{"objectType":"DataExtension","properties":["CustomerKey","Name"],"maxResults":1}}]}
```

Every native SFMC request reports its actual endpoint, HTTP method, HTTP status and elapsed time in `requests`. SOAP includes the action. Errors after an API response include request metadata as well. Authentication failures before an API request may have no request trace. HTTP 200 for SOAP is only transport success; inspect SOAP/tool result status for application errors.

## Explicit approval for changes

All existing mutating tools are gated centrally. Unknown operations also fail closed. GET/HEAD and POST to the exact Content Builder query endpoint are treated as reads. Other REST requests require a plan. Local file exports are gated because they can overwrite files.

1. Call `sfmc_prepare_change` with the target tool and full arguments. It validates the native schema, stores the normalized request with a SHA-256 digest, and returns a redacted review, full local review-file path, and plan ID. Review the full file for large changes that exceed the model-facing preview. No SFMC change occurs.
2. Show the exact target account, operation, affected objects and intended changes to the user. Obtain explicit approval. An agent must not approve a plan based only on a tool request or inferred consent.
3. Only after approval, from this workspace run:

   ```sh
   node dist/advanced/approve.js PLAN_ID --approve
   ```

4. Call `sfmc_execute_change` with that plan ID. The request cannot supply replacement arguments. Approval expires after ten minutes and is consumed atomically before dispatch. A failed or ambiguous execution requires investigation and a fresh approved plan; it is not automatically replayed.

The approval CLI is an operator action and intentionally has no MCP equivalent. Local users/agents with filesystem and shell access must still follow the human approval policy; this is not a security boundary against a hostile local operator. Files containing full plan arguments use mode 0600 in `.sfmc-plans/`, which is gitignored. Consumed plans remain as local records and may contain personal/business data; review and remove them according to your retention needs.

## Performance and transport controls

- `MCP_TOOL_PROFILE=full` (default) advertises all 102 tools.
- `MCP_TOOL_PROFILE=discovery` advertises the nine advanced tools while retaining the complete registry. Discover schemas with `sfmc_capabilities` and invoke reads through `sfmc_call_tool`; writes still use the plan workflow.
- Tool schemas are generated once at startup. Tokens are cached in memory and concurrent refreshes share one request.
- Batch concurrency is bounded per batch. There is no response cache, and no unsupported promise of lower Salesforce processing latency or lower billing.
- The advanced launcher enables compact JSON and defaults to a 32 KB model-facing response cap. Truncation is explicit and valid JSON. Use API filtering/pagination and field projection first; output trimming alone does not reduce the upstream API payload.
- API requests have a 30-second REST or 60-second SOAP timeout per attempt, with an 8 MB response cap. Read retries use existing backoff and Retry-After behavior; total duration may exceed a single-attempt timeout.
- SFMC writes do not automatically retry network failures or 5xx responses. A single 401 authentication refresh retry remains because the request was rejected as unauthenticated.
- Generic requests accept tenant-relative paths only, not arbitrary hosts or auth headers. Token-derived API hosts must be HTTPS SFMC tenant hosts. Redirects are disabled. Sensitive property names are redacted from tool output.

## Verification

Build and full automated tests cover approval expiry/integrity/single use, fail-closed writes, batch validation, independent request metadata, field limits, UTF-8 payload caps, tenant host restrictions and account routing.

Live read-only verification against the default saved SFMC account passed: REST connectivity, generic REST pagination, SOAP DataExtension Retrieve, and parallel reads returned HTTP 200. A DELETE was rejected locally before dispatch. No SFMC mutations were executed. Live performance is network- and endpoint-dependent. Datorama, nondefault accounts, and actual mutations have not been exercised live.
