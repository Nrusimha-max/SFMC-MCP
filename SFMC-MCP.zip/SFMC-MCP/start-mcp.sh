#!/bin/bash
# Launches the MCP server. Credentials are NOT stored here:
# copy .env.example to .env (gitignored) and fill in your values.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"   # dotenv reads .env from the working directory

if [ ! -f "$SCRIPT_DIR/.env" ]; then
  echo "Missing $SCRIPT_DIR/.env - copy .env.example to .env and add your credentials." >&2
  exit 1
fi

# Use node from PATH; falls back to a common install location if not found.
NODE_BIN="$(command -v node || echo /usr/local/bin/node)"
exec "$NODE_BIN" "$SCRIPT_DIR/dist/index.js"
