# mcp-sfmc-datorama

Advanced native server setup: [ADVANCED-MCP.md](ADVANCED-MCP.md). The `start-advanced-mcp.sh` launcher reuses saved SFMC authentication and adds generic REST, request metadata, named business units, bounded batch reads, diagnostics and an explicit approval workflow for writes. Full and discovery profiles retain the complete registry. Ready MCP settings: `mcp-advanced.config.json`.

A production-ready [Model Context Protocol](https://modelcontextprotocol.io)
server that exposes **Salesforce Marketing Cloud (SFMC)** and
**Datorama / Marketing Cloud Intelligence** capabilities as tools callable
by Claude.

The server speaks MCP over stdio (the default transport used by Claude
Desktop, Claude Code, and the Anthropic Agent SDK). It is implemented in
TypeScript on top of the official `@modelcontextprotocol/sdk`.

---

## Install

### From source

```bash
git clone <this-repo> mcp-sfmc-datorama
cd mcp-sfmc-datorama
npm install
npm run build
npm link    # optional — exposes `mcp-sfmc-datorama` on $PATH
```

Requires **Node.js 20+**.

### Globally via npm

```bash
npm install -g @pixacore/mcp-sfmc-datorama
```

### Docker

```bash
cp .env.example .env   # fill in credentials
docker compose build
# stdio mode (this is how Claude Desktop should launch it):
docker compose run --rm -i mcp-sfmc-datorama
```

---

## Configure Claude Desktop

Add this snippet to your `claude_desktop_config.json`
(macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`,
Windows: `%APPDATA%\Claude\claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "sfmc-datorama": {
      "command": "mcp-sfmc-datorama",
      "env": {
        "SFMC_SUBDOMAIN": "mc6abcdefghijk",
        "SFMC_CLIENT_ID": "...",
        "SFMC_CLIENT_SECRET": "...",
        "SFMC_ACCOUNT_ID": "1234567",
        "DATORAMA_API_TOKEN": "...",
        "DATORAMA_WORKSPACE_ID": "ws-12345",
        "DATORAMA_REGION": "us"
      }
    }
  }
}
```

If you installed from source without linking, use the absolute path:

```json
"command": "node",
"args": ["/absolute/path/to/mcp-sfmc-datorama/dist/index.js"]
```

To run the Docker image instead:

```json
{
  "mcpServers": {
    "sfmc-datorama": {
      "command": "docker",
      "args": ["compose", "-f", "/abs/path/to/docker-compose.yml", "run", "--rm", "-i", "mcp-sfmc-datorama"]
    }
  }
}
```

Restart Claude Desktop and the tools should appear under the connector menu.

---

## Environment variables

| Variable                  | Required | Purpose                                                                              |
| ------------------------- | -------- | ------------------------------------------------------------------------------------ |
| `SFMC_SUBDOMAIN`          | yes      | Tenant subdomain (the prefix on `*.auth.marketingcloudapis.com`).                    |
| `SFMC_CLIENT_ID`          | yes      | OAuth client_id from an Installed Package with API Integration.                      |
| `SFMC_CLIENT_SECRET`      | yes      | OAuth client_secret.                                                                 |
| `SFMC_ACCOUNT_ID`         | yes      | Business Unit MID this server should act against.                                    |
| `SFMC_PROD_ACCOUNT_ID`    | no       | Production Business Unit MID. When provided, pass `bu: "prod"` to any SFMC tool to operate against the Production BU instead of the default. |
| `SFMC_REST_BASE_URL`      | no       | Override the REST base URL (defaults to the token's `rest_instance_url`).            |
| `SFMC_SOAP_ENDPOINT`      | no       | Override the SOAP endpoint (defaults to the token's `soap_instance_url`).            |
| `DATORAMA_API_TOKEN`      | yes      | Datorama personal/integration API token. Sent as `Authorization: Token {token}`.     |
| `DATORAMA_WORKSPACE_ID`   | no       | Default workspace for tools that need one (can be overridden per call).              |
| `DATORAMA_REGION`         | no       | `us` (default), `eu`, or `ap`. Selects the regional API host.                        |
| `DEBUG`                   | no       | Set to `1` / `true` for verbose stderr logging.                                      |
| `MCP_MAX_RESPONSE_BYTES`  | no       | Cap on bytes returned in a single tool response (default 100000).                    |

`.env` is loaded automatically via `dotenv`, so you can drop credentials in
a `.env` file in the working directory instead of exporting them.

---

## Tools

### SFMC — Data Extensions

| Tool                                  | Description                                                                                              |
| ------------------------------------- | -------------------------------------------------------------------------------------------------------- |
| `sfmc_list_data_extensions`           | List Data Extensions with row counts, name, key, created/modified dates, sendable flag.                  |
| `sfmc_get_data_extension_rows`        | Fetch rows from a DE by external key with `$top`, `$skip`, `$filter`, `$orderby`.                        |
| `sfmc_upsert_data_extension_rows`     | Async upsert via `/data/v1/async/dataextensions`. Returns a `requestId` for status polls.                |
| `sfmc_create_data_extension`          | Create a new DE with fields, primary keys, optional folder, sendable relationship, and retention policy. |
| `sfmc_alter_data_extension`           | Add/remove/update fields and change DE-level properties (name, folder, sendable, retention).             |
| `sfmc_delete_data_extension`          | Permanently delete a DE by CustomerKey.                                                                  |
| `sfmc_rename_data_extension`          | Rename a DE in-place without changing schema or rows.                                                    |
| `sfmc_delete_data_extension_rows`     | Async delete rows matching an OData `$filter`; omit filter to clear all rows.                            |
| `sfmc_manage_folder`                  | Create, rename, or move a Data Extension folder.                                                         |

### SFMC — Automation Studio

| Tool                          | Description                                                                                          |
| ----------------------------- | ---------------------------------------------------------------------------------------------------- |
| `sfmc_list_automations`       | List automations with optional name and status filters.                                              |
| `sfmc_get_automation`         | Full automation definition (steps, schedule) by ID.                                                  |
| `sfmc_create_automation`      | Create an automation with steps and an optional schedule.                                            |
| `sfmc_update_automation`      | Rename, change description, or modify the schedule.                                                  |
| `sfmc_delete_automation`      | Permanently delete an automation.                                                                    |
| `sfmc_automation_action`      | Start or stop an automation run (schedule toggle).                                                   |
| `sfmc_fire_automation`        | Trigger an immediate one-off run via `actions/start` without touching the schedule.                  |
| `sfmc_get_automation_history` | List past run records (activity history) for an automation.                                          |

### SFMC — SQL Query Activity

| Tool                             | Description                                                                                                                                          |
| -------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------- |
| `sfmc_create_query_definition`   | Create a SQL Query Activity targeting a DE. Use `queryText` to query system data views (`_Sent`, `_Open`, `_Click`, `_Bounce`, `_Unsubscribe`, `_Complaint`) or any DE. |
| `sfmc_update_query_definition`   | Change queryText, target DE, or updateType of an existing Query Activity.                                                                            |
| `sfmc_get_query_definition`      | Retrieve definition and Status (Ready / Running / Complete / Error).                                                                                 |
| `sfmc_delete_query_definition`   | Permanently delete a SQL Query Activity.                                                                                                             |
| `sfmc_execute_query_definition`  | Start a Query Activity asynchronously. Poll `sfmc_get_query_definition` for completion, then read results with `sfmc_get_data_extension_rows`.       |

### SFMC — Automation Activities

| Tool                                  | Description                                                                                          |
| ------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| `sfmc_manage_script_activity`         | Create or update an SSJS / AMPscript Script Activity (`SssjsActivity`).                              |
| `sfmc_manage_data_extract_activity`   | Create or update a Data Extract Activity with a template key and parameters.                         |
| `sfmc_manage_file_transfer_activity`  | Create or update a File Transfer Activity for FTP/SFTP operations.                                   |
| `sfmc_manage_import_definition`       | Create or update an Import Definition (CSV/TAB file → Data Extension).                               |
| `sfmc_trigger_bulk_import`            | Start an Import Definition immediately; file must be on the configured FTP location.                 |

### SFMC — Content Builder / Email Studio

| Tool                                  | Description                                                                                                       |
| ------------------------------------- | ----------------------------------------------------------------------------------------------------------------- |
| `sfmc_list_assets`                    | List assets — emails, templates, content blocks, images, or CloudPages. Supports type, name, and folder filters. |
| `sfmc_get_asset`                      | Full asset definition (HTML content and views) by ID.                                                             |
| `sfmc_create_asset`                   | Create an asset — email (207/209), template (4), HTML block (196), CloudPage (329), or any type.                  |
| `sfmc_update_asset`                   | Update name, content, views, or metadata.                                                                         |
| `sfmc_delete_asset`                   | Permanently delete an asset.                                                                                      |
| `sfmc_clone_asset`                    | Duplicate an asset by ID with a new name, optionally in a different folder.                                       |
| `sfmc_move_asset`                     | Move an asset to a different folder (category) without touching other properties.                                 |
| `sfmc_publish_cloudpage`              | Publish a CloudPage (asset type 329) and return its live `publishedURL`.                                          |
| `sfmc_unpublish_cloudpage`            | Take a CloudPage offline without deleting it.                                                                     |
| `sfmc_get_cloudpage_url`              | Fetch the live published URL from `fileProperties.publishedURL`; returns `null` if not published.                 |
| `sfmc_manage_cloudpage_collection`    | Create, rename/move, or delete a CloudPage collection (category folder).                                          |

### SFMC — Contact Builder

| Tool                                    | Description                                                     |
| --------------------------------------- | --------------------------------------------------------------- |
| `sfmc_get_contact`                      | Retrieve all attribute set values for a contact by contact key. |
| `sfmc_upsert_contact`                   | Create or update a contact with attribute set values.           |
| `sfmc_delete_contact`                   | Delete a contact and its associated attributes.                 |
| `sfmc_list_contact_attribute_groups`    | List all attribute groups in the Contact Builder data model.    |

### SFMC — Journey Builder

| Tool                       | Description                                                                                                 |
| -------------------------- | ----------------------------------------------------------------------------------------------------------- |
| `sfmc_list_journeys`       | List journeys, filterable by status and name.                                                               |
| `sfmc_get_journey`         | Full journey definition by ID, with optional `extras` (`activities`, `outcome`, `stats`, `all`).            |
| `sfmc_get_journey_graph`   | Compact complete activity and connection graph for safe Journey Builder review.                             |
| `sfmc_get_journey_activity`| One full activity definition by its Journey activity key.                                                   |
| `sfmc_create_journey`      | Create a new journey (saved as Draft).                                                                      |
| `sfmc_update_journey`      | Modify activities, triggers, goals, or rename.                                                              |
| `sfmc_journey_action`      | Publish, stop, pause, or resume a journey.                                                                  |
| `sfmc_get_journey_metrics` | Performance metrics — population counts, goal conversion rates, and activity-level statistics.              |

### SFMC — Subscriber & List Management

| Tool                            | Description                                                                          |
| ------------------------------- | ------------------------------------------------------------------------------------ |
| `sfmc_list_subscribers`         | List All Subscribers with optional email, status, and list ID filters.               |
| `sfmc_get_subscriber`           | Look up a single subscriber by email or subscriber key.                              |
| `sfmc_upsert_subscriber`        | Create or update a subscriber with status, list memberships, and profile attributes. |
| `sfmc_delete_subscriber`        | Delete a subscriber from All Subscribers.                                            |
| `sfmc_list_lists`               | List publication, suppression, and standard lists.                                   |
| `sfmc_create_list`              | Create a new list (standard, publication, or suppression).                           |
| `sfmc_manage_list_subscription` | Subscribe or unsubscribe email addresses to/from a list.                             |

### SFMC — User & Account Management

| Tool                  | Description                                                                     |
| --------------------- | ------------------------------------------------------------------------------- |
| `sfmc_list_users`     | List account users with optional name, email, and active-status filters.        |
| `sfmc_create_user`    | Create a new account user with login credentials.                               |
| `sfmc_update_user`    | Lock/unlock, reset password flag, or change notification email.                 |
| `sfmc_assign_role`    | Grant a role to a user by roleId or role name.                                  |
| `sfmc_revoke_role`    | Remove a role from a user by roleId or role name.                               |

### SFMC — Reports & Analytics

| Tool                                | Description                                                                                                        |
| ----------------------------------- | ------------------------------------------------------------------------------------------------------------------ |
| `sfmc_query_soap`                   | Raw SOAP `Retrieve` for any SFMC object (`Subscriber`, `BounceEvent`, `OpenEvent`, etc.).                          |
| `sfmc_query_data_view`              | Query system data views via SOAP: `_Sent`, `_Open`, `_Click`, `_Bounce`, `_Unsubscribe`, `_Complaint`, `_Job`, etc. |
| `sfmc_get_email_send_summary`       | Aggregate send stats (sends, delivered, opens, clicks, bounces, unsubs) by SendID or date range.                  |
| `sfmc_get_subscriber_send_history`  | Per-send records for a specific subscriber key via the REST data API.                                              |
| `sfmc_get_einstein_sto_score`       | Einstein Send Time Optimization scores for a subscriber or account-level defaults.                                |

### SFMC — Triggered Sends

| Tool                        | Description                                                                               |
| --------------------------- | ----------------------------------------------------------------------------------------- |
| `sfmc_send_triggered_email` | Fire a Triggered Send by external key for one or more subscribers with personalization.   |

### Datorama (Marketing Cloud Intelligence)

| Tool                                   | Description                                                                                          |
| -------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| `datorama_list_workspaces`             | Workspaces accessible by the configured token.                                                       |
| `datorama_run_query`                   | Run a query against a workspace with measurements, dimensions, date range, filters, ordering.        |
| `datorama_list_data_streams`           | Data streams in a workspace with status and last-ingestion timestamp.                                |
| `datorama_get_calculated_measurement`  | Fetch a calculated measurement's formula and metadata.                                               |
| `datorama_list_dashboards`             | List dashboards in a workspace with owner and last-modified.                                         |
| `datorama_export_dashboard_data`       | Pull the underlying data for a dashboard's widgets, optionally overriding the date range.            |
| `datorama_list_widgets`                | List all widgets (id, title, type, measurements, dimensions) inside a dashboard.                     |
| `datorama_get_widget`                  | Fetch a single widget definition by dashboardId and widgetId.                                        |
| `datorama_create_widget`               | Create a chart, table, metric, or filter widget inside an existing dashboard.                        |
| `datorama_update_widget`               | Update a widget's title, measurements, dimensions, or date range.                                    |
| `datorama_delete_widget`               | Delete a widget from a dashboard by dashboardId and widgetId.                                        |

Every tool input is validated with [zod](https://zod.dev) and exposed to MCP
clients as JSON Schema via `zod-to-json-schema`. Argument errors are
returned as structured MCP errors with the offending fields enumerated.

---

## Example prompts

Once the server is connected, try these in Claude:

1. **Email performance pulse**
   > "Show me the last 7 days of email performance from SFMC — total sends,
   > delivered, open rate, click rate, and bounces. Highlight any sends with
   > delivery rate under 95%."

2. **Cross-channel spend in Datorama**
   > "Run a Datorama query for spend by channel for last quarter. Use the
   > default workspace, include `cost` and `impressions` as measurements and
   > `marketing_channel` as a dimension."

3. **Audience inspection**
   > "Find subscribers in the data extension `NewsletterMaster` who opened
   > the last campaign. Pull up to 100 rows ordered by ModifiedDate desc."

Claude will plan a sequence of tool calls (e.g. resolve the SendID, then
query opens via `sfmc_query_soap` against `OpenEvent`, then join against
`sfmc_get_data_extension_rows`) — no orchestration code on your end.

---

## How it works

- **Auth.** SFMC uses OAuth 2.0 `client_credentials` against
  `https://{subdomain}.auth.marketingcloudapis.com/v2/token`. Tokens are
  cached in memory and proactively refreshed 60s before expiry. Concurrent
  callers share a single in-flight refresh.
- **Retries.** Every upstream call goes through a retry helper that
  retries on network errors, 408/429/5xx with exponential backoff (jittered),
  honors `Retry-After`, and refreshes the token once on a 401 before
  surfacing the error. Non-retryable 4xx are surfaced as structured MCP
  errors with the API's own error message and code.
- **Response shape.** Every tool result is JSON-serialized to a single
  `text` content block. Responses exceeding the byte cap are truncated with
  a clear marker so Claude can re-issue with tighter filters.
- **Logging.** `stdout` is reserved for MCP framing — all logging goes to
  `stderr`, prefixed with `[sfmc]` or `[datorama]`. Secrets and full row
  payloads are never logged at info level.

---

## Development

```bash
npm install
npm run build       # tsc → dist/
npm run dev         # tsc --watch
npm test            # vitest run
npm run test:watch  # vitest in watch mode
```

Tests mock `axios` and cover:
- SFMC OAuth token caching, proactive refresh, concurrent coalescing, error
  surfacing.
- Datorama region resolution and Authorization header shape.
- `sfmc_get_data_extension_rows` and `sfmc_upsert_data_extension_rows` —
  REST shape, 401-then-refresh retry, 400 error surfacing.
- `datorama_list_workspaces` and `datorama_run_query` — endpoint shape,
  workspace resolution, `Retry-After` handling.
- Response truncation and MCP error envelope shape.

---

## License

MIT.
