const {spawnSync}=require('child_process'),path=require('path'),fs=require('fs');
const source=fs.readFileSync(path.join(__dirname,'sfmc-builder-preview-fix.html'),'utf8'),privateValues=[...source.matchAll(/\b(?:clientId|clientSecret)\s*:\s*["']([^"']+)/gi)].map(m=>m[1]);
function safe(text){for(const value of privateValues)text=text.split(value).join('[redacted]');return text;}

const files=['check-structure.cjs','check-enhancements.cjs','check-activities.cjs','check-testable.cjs','check-relationship.cjs','check-bugfixes.cjs','check-read-races.cjs','check-new-features.cjs','check-definition-ui.cjs','check-all-activity-types.cjs','check-retention-duplicate.cjs','check-sql-target.cjs','check-popup-query-ui.cjs','check-review-regressions.cjs','check-preview-startup.cjs'];
for(const file of files){const r=spawnSync(process.execPath,[path.join(__dirname,file)],{encoding:'utf8'});process.stdout.write(safe(r.stdout));process.stderr.write(safe(r.stderr));if(r.status!==0)process.exit(r.status||1);}console.log('All 15 local suites passed. SFMC calls and DOM interactions were mocked; no live mutations were executed.');
