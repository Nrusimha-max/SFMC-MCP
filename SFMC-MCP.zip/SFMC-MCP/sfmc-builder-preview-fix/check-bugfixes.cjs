const fs=require('fs'),vm=require('vm'),assert=require('assert/strict'),path=require('path');
const s=fs.readFileSync(path.join(__dirname,'sfmc-builder-preview-fix.html'),'utf8');const scripts=[...s.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(m=>m[1]);
const elements={};const el=id=>elements[id]||(elements[id]={value:'',checked:false,style:{},innerHTML:'',textContent:'',classList:{contains(){return false},add(){},remove(){}},querySelector(){return null},setAttribute(){},querySelectorAll(){return []},appendChild(){}});
let lastRow;const browser=vm.createContext({URL,URLSearchParams,document:{body:{style:{}},getElementById:el,querySelectorAll(){return []},createElement(){const controls={};lastRow={innerHTML:'',querySelector(selector){return controls[selector]||(controls[selector]={value:'',checked:selector==='.f-pk',setAttribute(){}})}};return lastRow;}},location:{href:'https://test/',protocol:'https:'}});
vm.runInContext(scripts[1].slice(0,scripts[1].indexOf('/* ---------- init ---------- */')),browser);const run=s=>vm.runInContext(s,browser);
run('globalThis.pending=[];api=function(){return new Promise(function(resolve,reject){pending.push({resolve,reject});});};');
(async()=>{
 const first=run("showFields('old','Old')");const second=run("showFields('new','New')");
 browser.pending[1].resolve([{Name:'New field',FieldType:'Text',MaxLength:123}]);await second;const current=el('modal-body').innerHTML;
 browser.pending[0].resolve([{Name:'Old field'}]);await first;assert.equal(el('modal-body').innerHTML,current);
 const late=run("showFields('late','Late')");run('closeModal()');el('modal-body').innerHTML='Closed';browser.pending[2].reject(new Error('late failure'));await late;assert.equal(el('modal-body').innerHTML,'Closed');
 assert.match(run("editSendRelationshipHTML({IsSendable:'true',SendRelationshipAvailable:true,SubscriberField:'Unknown type',SendableDEField:'ID'},[])"),/disabled/);
 run('applyTypeRules=function(){};refreshSendable=function(){};addFieldRow()');const pk=lastRow.querySelector('.f-pk'),req=lastRow.querySelector('.f-req');assert.equal(req.checked,true);assert.equal(req.disabled,true);pk.checked=false;pk.onchange();assert.equal(req.disabled,false);
 console.log('PASS: out-of-order dialog responses and errors ignored; closing invalidates requests; unknown mapping preserved; primary key Required state locked. No live API calls.');
})().catch(e=>{console.error(e.message);process.exitCode=1});
