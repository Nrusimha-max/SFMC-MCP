const fs=require('fs'),vm=require('vm'),assert=require('assert/strict'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'sfmc-builder-automation-editor.html'),'utf8'),script=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)][1][1],blobs=[],links=[],alerts=[],nodes={};
const el=id=>nodes[id]||(nodes[id]={id,value:'',checked:false,disabled:false,hidden:false,innerHTML:'',textContent:'',children:[],style:{},classList:{contains(){return false},add(){},remove(){}},querySelectorAll(){return []},setAttribute(){}});
class TestURL extends URL{static createObjectURL(blob){blobs.push(blob);return 'blob:test/'+blobs.length;}static revokeObjectURL(){}}
const ctx=vm.createContext({URL:TestURL,URLSearchParams,Blob,setTimeout(){},window:{confirm(){return true},alert(message){alerts.push(message)}},document:{body:{appendChild(){}},getElementById:el,querySelectorAll(){return []},createElement(){return {click(){links.push({name:this.download,href:this.href})},remove(){}}}},location:{href:'https://test/',protocol:'https:'}});vm.runInContext(script.slice(0,script.indexOf('/* ---------- init ---------- */')),ctx);const run=s=>vm.runInContext(s,ctx),copy=x=>JSON.parse(JSON.stringify(x));
const fixtures=Object.fromEntries(['de','sql','automation'].map(kind=>[kind,JSON.parse(fs.readFileSync(path.join(__dirname,'examples',kind+'-example.json'),'utf8'))]));
run('globalThis.calls=[];globalThis.rows=[];api=async function(action,data){calls.push({action,data});if(action==="folders")return [];throw new Error("Unexpected API call");};addFieldRow=function(field){rows.push(field)};toggleSendable=function(){};updateSendRelationshipSummary=function(){};updateDEFolderPath=function(){};activateWorkspaceTab=function(id){globalThis.openedTab=id};setDEView=function(){};renderSteps=function(){};');
function file(doc,name){const text=typeof doc==='string'?doc:JSON.stringify(doc);return {name:name||'test.json',size:Buffer.byteLength(text),text:async()=>text};}
(async()=>{
 for(const [kind,doc] of Object.entries(fixtures)){
  ctx.fixture=doc;run('downloadDefinition(fixture.kind,fixture.data)');const exported=JSON.parse(await blobs.at(-1).text());ctx.roundtrip=exported;const clean=run('cleanDefinition(roundtrip)');assert.equal(clean.kind,kind);assert.equal(clean.data.name,doc.data.name);assert.ok(blobs.at(-1).size<=131072);
  await ctx.importDefinitionFile(file(exported,kind+'-example.json'));assert.equal(ctx.openedTab,kind==='de'?'tab-de':kind==='sql'?'tab-sql':'tab-build');assert.match(el('definition-status').textContent,/Nothing was written/);
 }
 assert.equal(ctx.calls.length,0);assert.equal(el('de-name').value,'Demo_Contacts');assert.equal(el('au-desc').value,fixtures.automation.data.description);
 // Saved buttons and stale target selection must never survive importing another draft.
 run('state.lastSavedQuery={id:"old-query"};state.lastCreatedAutomation={ProgramID:"old-auto"};');el('q-saved-actions').hidden=false;el('au-saved-actions').hidden=false;
 await ctx.importDefinitionFile(file(fixtures.sql));assert.equal(run('state.lastSavedQuery'),null);assert.equal(el('q-saved-actions').hidden,true);await ctx.importDefinitionFile(file(fixtures.automation));assert.equal(run('state.lastCreatedAutomation'),null);assert.equal(el('au-saved-actions').hidden,true);
 // Malformed files do not overwrite the existing draft; BOM files are accepted.
 const previous=el('q-name').value;await ctx.importDefinitionFile(file('{broken'));assert.match(el('definition-status').textContent,/not valid JSON/);assert.equal(el('q-name').value,previous);
 await ctx.importDefinitionFile(file('\uFEFF'+JSON.stringify(fixtures.sql)));assert.equal(el('q-name').value,'Demo_Query');
 const bad=copy(fixtures.de);bad.data.isSendable='false';await ctx.importDefinitionFile(file(bad));assert.match(el('definition-status').textContent,/true or false/);assert.equal(el('de-name').value,'Demo_Contacts');
 await ctx.importDefinitionFile({name:'huge.json',size:131073,text:async()=>{throw new Error('Must not read')}});assert.match(el('definition-status').textContent,/128 KB/);
 // Exports are themselves importable and respect the same UTF-8 byte size limit.
 ctx.invalid=copy(fixtures.automation);ctx.invalid.data.steps[0].activities=[];const before=links.length;assert.throws(()=>run('downloadDefinition(invalid.kind,invalid.data)'),/activities/);assert.equal(links.length,before);
 ctx.huge=copy(fixtures.sql);ctx.huge.data.sql='汉'.repeat(59000);assert.throws(()=>run('downloadDefinition(huge.kind,huge.data)'),/exceeds 128 KB/);assert.equal(links.length,before);
 // Only the latest file read may populate a draft.
 let finishOld;const old=file({...fixtures.sql,data:{...fixtures.sql.data,name:'Old file'}},'old.json');old.text=()=>new Promise(resolve=>{finishOld=resolve});const pending=ctx.importDefinitionFile(old);await ctx.importDefinitionFile(file({...fixtures.sql,data:{...fixtures.sql.data,name:'Newest file'}},'new.json'));finishOld(JSON.stringify({...fixtures.sql,data:{...fixtures.sql.data,name:'Old file'}}));await pending;assert.equal(el('q-name').value,'Newest file');assert.match(el('definition-status').textContent,/new\.json/);
 // An old target search cannot refill imported SQL's empty target list.
 run('api=function(action,data){calls.push({action,data});return new Promise(function(resolve){globalThis.resolveSearch=resolve});};');el('q-de-search').value='Old target';const search=run('searchTargetDE()');await ctx.importDefinitionFile(file(fixtures.sql));ctx.resolveSearch({rows:[{Name:'Old target',CustomerKey:'old-target'}],more:false});await search;assert.equal(run('state.targetDEs.length'),0);assert.equal(el('q-target').disabled,false);
 // Pending folder reloads must not restore the previous draft's destination after a DE import.
 run('api=function(action,data){calls.push({action,data});return new Promise(function(resolve){globalThis.resolveFolder=resolve});};');el('de-folder').value='99';const folder=run('loadDEFolderPaths()');await ctx.importDefinitionFile(file(fixtures.de));ctx.resolveFolder([{ID:'404',Name:'Data Extensions','ParentFolder.ID':'0'},{ID:'99',Name:'Old folder','ParentFolder.ID':'404'}]);await folder;assert.equal(el('de-folder').value,'404');
 // Cancelling an overwrite leaves the draft intact.
 run("dirtyBaselines['newq-wrap']='different baseline'");ctx.window.confirm=()=>false;const unchanged=el('q-name').value;await ctx.importDefinitionFile(file({...fixtures.sql,data:{...fixtures.sql.data,name:'Do not import'}}));assert.equal(el('q-name').value,unchanged);assert.match(el('definition-status').textContent,/cancelled/);ctx.window.confirm=()=>true;run("markClean('newq-wrap')");
 // Exporting saved workflow descriptions preserves them; unrelated fields are stripped.
 ctx.extra=copy(fixtures.sql);ctx.extra.data.authentication='dummy-do-not-export';run('downloadDefinition(extra.kind,extra.data)');const sanitized=await blobs.at(-1).text();assert.equal(sanitized.includes('dummy-do-not-export'),false);
 run('flowEditor={name:"Saved",key:"saved",description:"Keep this description",steps:[{name:"Step",activities:[{instanceId:"inst",name:"Query",activityObjectId:"query",objectTypeId:300}]}]};exportFlow()');assert.equal(JSON.parse(await blobs.at(-1).text()).data.description,'Keep this description');
 assert.ok(ctx.calls.every(c=>['listDEs','folders'].includes(c.action)));
 console.log('PASS: DE/SQL/automation export-import round trips; sample files; UTF-8 byte limits and BOM; malformed files/settings preserve drafts; latest file wins; stale searches and saved-action panels reset; export allowlist and workflow descriptions; imports issue no SFMC writes or execution. Mock browser APIs.');
})().catch(e=>{console.error(e.message);process.exitCode=1});
