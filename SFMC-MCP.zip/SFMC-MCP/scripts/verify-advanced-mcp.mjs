import { execFileSync } from 'node:child_process';
import { writeFile } from 'node:fs/promises';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport, getDefaultEnvironment } from '@modelcontextprotocol/sdk/client/stdio.js';

// Read only the registered server; never dump the user's complete config.
const source = `import json,pathlib,tomllib\np=pathlib.Path.home()/'.codex/config.toml'\nd=tomllib.loads(p.read_text())\nprint(json.dumps(d['mcp_servers']['sfmc-advanced']))`;
const config = JSON.parse(execFileSync('python3', ['-c', source], { encoding: 'utf8' }));
if (config.enabled === false) throw new Error('Registered SFMC server is disabled');
const client = new Client({ name: 'registered-sfmc-verifier', version: '1.0.0' });
const report = { checkedAt: new Date().toISOString(), registration: { name: 'sfmc-advanced', command: config.command, args: config.args, enabled: config.enabled !== false }, checks: [] };
function assert(condition, message) { if (!condition) throw new Error(message); }
async function call(name, args) {
  const raw = await client.callTool({ name, arguments: args }, undefined, { timeout: 90000 });
  const parsed = JSON.parse(raw.content[0].text);
  return { raw, parsed };
}
try {
  const transport = new StdioClientTransport({ command: config.command, args: config.args ?? [], cwd: config.cwd ?? process.cwd(), env: { ...getDefaultEnvironment(), ...(config.env ?? {}) }, stderr: 'pipe' });
  transport.stderr?.on('data', () => {});
  await client.connect(transport);
  report.server = client.getServerVersion();
  const inventory = await client.listTools();
  assert(inventory.tools.length === 102, 'Expected all 102 registered tools');
  report.checks.push({ name: 'MCP handshake and tool discovery', passed: true, toolCount: inventory.tools.length });
  const capabilities = await call('sfmc_capabilities', { query: 'sfmc_rest_request', includeSchemas: true });
  assert(!capabilities.raw.isError && capabilities.parsed.data.items.some(t => t.name === 'sfmc_rest_request' && t.inputSchema), 'Capability schema discovery failed');
  report.checks.push({ name: 'Capability schemas', passed: true });
  const units = await call('sfmc_business_units', {});
  assert(!units.raw.isError && units.parsed.data.accounts.length > 0, 'Business unit discovery failed');
  report.checks.push({ name: 'Business unit discovery', passed: true, count: units.parsed.data.accounts.length });
  const health = await call('sfmc_connection_health', {});
  assert(!health.raw.isError && health.parsed.data.connected && health.parsed.requests[0].status === 200, 'Connectivity probe failed');
  report.checks.push({ name: 'REST authentication and connectivity', passed: true, requests: health.parsed.requests });
  const rest = await call('sfmc_rest_request', { path: '/interaction/v1/interactions', query: { $pageSize: 1, $page: 1 } });
  assert(!rest.raw.isError && rest.parsed.requests[0].status === 200 && rest.parsed.data.items.length <= 1, 'REST read or pagination failed');
  report.checks.push({ name: 'Direct REST and pagination', passed: true, requests: rest.parsed.requests, response: { count: rest.parsed.data.count, pageSize: rest.parsed.data.pageSize, returned: rest.parsed.data.items.length } });
  const soap = await call('sfmc_query_soap', { objectType: 'DataExtension', properties: ['CustomerKey', 'Name'], maxResults: 1 });
  assert(!soap.raw.isError && soap.parsed.requests[0].status === 200, 'SOAP Retrieve failed');
  report.checks.push({ name: 'SOAP Retrieve', passed: true, requests: soap.parsed.requests, response: { objectType: soap.parsed.data.objectType, returned: soap.parsed.data.returned } });
  const projected = await call('sfmc_call_tool', { tool: 'sfmc_list_journeys', arguments: { top: 1 }, maxItems: 1, fields: ['id', 'name', 'status'] });
  assert(!projected.raw.isError && projected.parsed.data.requests[0].status === 200, 'Projected tool read lost request metadata');
  report.checks.push({ name: 'Discovered tool invocation and metadata', passed: true });
  const batch = await call('sfmc_batch_read', { concurrency: 2, calls: [{ tool: 'sfmc_list_journeys', arguments: { top: 1 } }, { tool: 'sfmc_list_journeys', arguments: { top: 1 } }] });
  assert(!batch.raw.isError && batch.parsed.data.results.length === 2 && batch.parsed.data.results.every(r => r.ok && r.requests[0].status === 200), 'Parallel reads failed');
  report.checks.push({ name: 'Parallel batch reads', passed: true, completed: 2 });
  const denied = await call('sfmc_rest_request', { method: 'DELETE', path: '/asset/v1/content/assets/0' });
  assert(denied.raw.isError && /approval/.test(denied.parsed.error.message), 'Write approval protection failed');
  const deniedNative = await call('sfmc_delete_asset', { id: 1 });
  assert(deniedNative.raw.isError && /approval/i.test(deniedNative.parsed.error.message), 'Native write approval protection failed');
  report.checks.push({ name: 'Unapproved REST and native writes blocked locally', passed: true });
  const diagnostics = await call('sfmc_diagnostics', {});
  assert(!diagnostics.raw.isError && diagnostics.parsed.data.apiOnly === true, 'Diagnostics failed');
  report.checks.push({ name: 'Runtime diagnostics', passed: true });
  report.passed = true;
} catch (error) {
  report.passed = false;
  report.failure = error instanceof Error ? error.message : 'Verification failed';
  process.exitCode = 1;
} finally {
  await client.close();
  await writeFile('.sfmc-verification/registered-server-check.json', JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report, null, 2));
}
