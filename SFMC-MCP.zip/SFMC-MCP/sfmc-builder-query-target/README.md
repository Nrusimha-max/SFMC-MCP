# SFMC Builder E10 — Popup activity selection and SQL target generation

Publish the entire `sfmc-builder-query-target.html` source to the existing CloudPage. Browser/server build identifiers must both be `SFMC-BUILDER-E10`. This release includes all earlier E7 features and fixes. The existing Installed Package configuration and three review/audit support DEs are unchanged. Login, roles, and credential-store replacement remain deferred.

## Popup activity selection

The draft builder follows the supplied screenshot: two inward-arrow selectors and a **Load activities** button. Results open in a wide, rounded, scrollable dialog over a dimmed/blurred backdrop, with a name/key filter, **Load more**, loaded/total count, and a Name / Key-or-Target table.

**Add** inserts the saved activity into the step captured when the popup opened and closes the popup. Duplicate assignments stay open with a clear message. Close cancels selection. Slow results from closed/replaced dialogs are ignored. Filtering applies to loaded rows; Load more retrieves the next page. All five activity types are supported.

## Also create a new target DE from SQL

The SQL Activities creation form includes the requested checkbox:

**Also create a new Data Extension for this query (fields are generated from the SQL)**

1. Enter the query name, query folder, and SQL. Use `AS` aliases for calculated output columns.
2. Select the checkbox, enter the new DE name/key, and choose a DE destination folder.
3. Fields are generated automatically if SQL was already entered; otherwise click **Generate fields from SQL** after entering it.
4. Review/edit each field's name, type, length/precision, scale, primary key, and required setting. Update requires an explicit primary key.
5. Save the query and approve the combined change review. It creates the target DE first, then saves the SQL activity pointing at that DE. It does not execute SQL or add the query to an automation automatically.

The generator inspects SELECT output names, aliases, readable source DE field metadata, explicit CAST/CONVERT types, literals, COUNT/COUNT_BIG, and supported date/min/max expressions. Named CTE/UNION outputs are supported with conservative type fallback. Unproven result types are marked **Text(4000)** for review. This is a bounded SQL projection inspector, not a full SQL type engine: complex expressions, wide strings, arithmetic, data views without metadata, or promoted UNION types may require corrected types or explicit SQL casts. Wildcards require readable source DE metadata; replace unsupported wildcards with explicit columns. Multiple statements, duplicate output names, and aliases over 50 characters are rejected.

New target fields are optional and have no primary key by default, because joins and expressions can change nullability and uniqueness. Field names must match the actual current SQL output; changing SQL invalidates the old preview. Later generation results do not overwrite manual edits made while loading.

The generated target is non-sendable, not testable, and has retention off. Use Find & manage DEs to edit applicable settings later. SQL draft export/import also preserves the editable proposed target schema, while destination folders must be reselected.

SQL is validated before any target DE creation. Existing query/DE external keys are checked before creation. **The two creates are not transactional:** if the DE is created but saving the query fails or cannot be verified, the error identifies the created DE and asks you to inspect both objects. The DE is not automatically deleted, and no write is retried. You can then select that DE as an existing target when saving a corrected query.

## Activity picker

Choose SQL Query, Import File, Script, Data Extract, or File Transfer, choose the draft step, then click **Load activities** to open the popup. Other saved-step library controls keep their existing loading behavior. All pickers share type-specific ID normalization, including File Transfer ID variants; paged results use API pagination metadata. Missing/invalid IDs are reported instead of silently generating unusable rows. Draft creation, saved-step attachment, and saved-step replacement use the same mapping.

Read-only checks against configured **Primary / MID 518005762** returned HTTP 200 for each request below. Only one record per collection was requested to inspect response keys; no activity was executed or modified.

| Method | Endpoint | Status |
|---|---|---|
| GET | `/automation/v1/queries?$page=1&$pageSize=1` | 200 |
| GET | `/automation/v1/imports?$page=1&$pageSize=1` | 200 |
| GET | `/automation/v1/scripts?$page=1&$pageSize=1` | 200 |
| GET | `/automation/v1/dataextracts?$page=1&$pageSize=1` | 200 |
| GET | `/automation/v1/filetransfers?$page=1&$pageSize=1` | 200 |

`activity-read-verification.json` contains actual request metadata and response-field names, without script bodies, names, record IDs, credentials, or tokens. These reads do not verify the page's intended MID 100010552; that BU is not currently exposed by the configured MCP accounts.

## Data retention

The DE create form includes an optional duration policy:

- Days, Weeks, Months, or Years.
- Delete individual expired records; delete all records while keeping the DE; or delete the DE and all its records.
- Reset the period on import for whole-DE policies.

New drafts default to retention off. Enabling retention creates the DE and its policy together through SOAP DataExtension Create, rather than attempting to change its row-based scope afterward. The policy is read back before success is reported. A failed or ambiguous create is not retried automatically.

The DE editor shows the existing policy. It changes retention only when **Change retention policy** is checked. Unknown metadata disables policy changes and preserves existing settings. Duration, units, reset behavior, whole-DE deletion behavior, and disabling retention are supported within the existing row-based scope. Salesforce documents that `RowBasedRetention` cannot be changed through this API, so the editor does not attempt that change. Duplicate the DE to choose another scope.

Existing fixed-date retention is displayed and preserved. It can be explicitly replaced with a duration within the existing scope, but fixed-date policies are not copied or imported automatically. Duration policies with a derived expiration date are recognized as duration policies.

Expired records or DEs are permanently deleted by SFMC's retention processing. Reviews show the exact requested settings and current/proposed policy. The API account needs the Manage Data Extension Retention permission for policy writes. This task made no live retention changes.

Official references: [DataExtension properties and permission](https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/dataextension.html), [supported retention updates](https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/changing_the_retention_period_for_a_data_extension.html).

## Duplicate DE

Find & manage Data Extensions → Search → **Duplicate**.

1. Enter the new name and external key. The source external key cannot be reused.
2. Optionally copy a readable, supported source duration policy. Otherwise the new draft has retention off.
3. Open the duplicate draft, choose the destination folder, adjust settings if needed, then review **Create Data Extension**.

Fields, types, lengths, decimal scale, defaults, primary/required flags, send relationship, and testable setting populate the draft. **No records are copied.** The source remains unchanged. Missing send/test metadata or an unsupported subscriber mapping blocks exact duplication instead of silently changing those settings. Unavailable or fixed-date retention cannot be automatically copied, but schema-only duplication with retention off remains possible.

## Earlier features retained

- Create/find/edit DEs; explicit send relationships; Is Testable checkbox.
- Independent saved SQL activities; edit SQL, target, folder, and data action with conflict/readback checks.
- Automation step rename/reorder, activity moves/removal/replacement; retained instance IDs and unknown properties preserved.
- Run monitoring, actual activity messages, manual refresh and bounded opt-in polling. History availability depends on tenant SOAP support and permission.
- Current/proposed DE schema/settings comparison in change reviews.
- Unsaved-change guards for reset, editor replacement/close, and leaving the page.
- Versioned JSON export/import into local drafts. Imports do not write or execute anything; no DE rows are exported. Duration retention is included when supported/readable. Destination folders and target references need review in the destination BU.
- Local folder-path filtering.
- Single-use, expiring, session-bound reviewed mutations, MID guard, and audit trail. A browser session is not an authenticated identity.
- REST-only Run once, with no automatic mutation retries.

The support DE schemas remain in `data-extension-schemas.json`. No new support DE or migration is required for E10.

## Verification

Run `node run-checks.cjs` in this directory. Thirteen local suites cover the earlier functionality plus popup selection for every activity type, captured destination-step identity, close/duplicate/stale-read behavior, SQL field inference and literal/comment handling, changed-SQL detection, generated schema export/import, validation before writes, query/DE key checks, Update primary keys, and partial-failure behavior.

SFMC writes and DOM interactions in these tests are mocked. No browser automation, publishing, live writes, sends, or execution occurred. Live read-only collection probes succeeded on Primary; end-to-end write validation in MID 100010552 remains pending. Successful local tests do not guarantee every tenant supports every SOAP property or has the required permissions.
