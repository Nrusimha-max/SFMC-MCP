#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NODE_BIN="$(command -v node)"
exec "$NODE_BIN" "$SCRIPT_DIR/dist/efficient-gateway.js"
