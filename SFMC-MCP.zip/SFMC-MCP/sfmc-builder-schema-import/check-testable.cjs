const fs=require('fs'),vm=require('vm'),assert=require('assert/strict'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'sfmc-builder-schema-import.html'),'utf8');const blocks=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(m=>m[1]);blocks.forEach(s=>new vm.Script(s));
let records={},created=[],updates=[],ignoreCoreFlag=true,ignoreUpdate=false;
const clone=x=>JSON.parse(JSON.stringify(x));
const context=vm.createContext({Stringify:JSON.stringify,Platform:{Load(){},Response:{SetResponseHeader(){}},Request:{GetQueryStringParameter(){return '0'}}},DataExtension:{Retrieve(filter){return Object.values(records).filter(row=>String(row[filter.Property])===String(filter.Value)).map(clone)},Add(payload){created.push(clone(payload));records[payload.CustomerKey]={ObjectID:'de-'+payload.CustomerKey,CustomerKey:payload.CustomerKey,Name:payload.Name,IsSendable:!!payload.SendableInfo,IsTestable:ignoreCoreFlag?false:payload.IsTestable,Description:''}}},Script:{Util:{WSProxy:function(){this.retrieve=(type,props,filter)=>({Status:'OK',Results:type==='DataExtension'?Object.values(records).filter(row=>String(row[filter.Property])===String(filter.Value)).map(clone):[],HasMoreRows:false});this.updateItem=(type,payload)=>{updates.push(clone(payload));const row=records[payload.CustomerKey];if(!ignoreUpdate&&Object.hasOwn(payload,'IsTestable'))row.IsTestable=payload.IsTestable;return {Status:'OK',Results:[{StatusCode:'OK'}]};};}}}});
vm.runInContext(blocks[0].replace(/\}\)\(\);\s*$/,'globalThis.api={h_createDE,h_updateDE,h_getDEProperties};\n})();'),context);const api=context.api;
const fields=[{name:'SubscriberKey',type:'Text',maxLength:'254',pk:true},{name:'EmailAddress',type:'EmailAddress'}];
api.h_createDE({name:'Testable',key:'testable',fields,isSendable:true,sendableField:'SubscriberKey',isTestable:true});assert.equal(created.at(-1).IsTestable,true);assert.equal(records.testable.IsTestable,true);assert.equal(updates.length,1);assert.equal(updates.at(-1).CustomerKey,'testable');
api.h_updateDE({key:'testable',name:'Testable',isTestable:false});assert.equal(updates.at(-1).IsTestable,false);assert.equal(records.testable.IsTestable,false);
api.h_updateDE({key:'testable',name:'Testable',isTestable:true});assert.equal(records.testable.IsTestable,true);assert.equal(api.h_getDEProperties({key:'testable'}).IsTestable,'true');
let count=updates.length;api.h_updateDE({key:'testable',name:'Rename only'});assert.equal(updates.length,count+1);assert.equal(updates.at(-1).IsTestable,undefined);assert.equal(records.testable.IsTestable,true);
let before=created.length;assert.throws(()=>api.h_createDE({name:'Invalid',fields,isSendable:false,isTestable:true}),/Is Sendable/);assert.equal(created.length,before);
api.h_createDE({name:'Ordinary',key:'ordinary',fields,isSendable:false,isTestable:false});assert.equal(created.at(-1).IsTestable,false);
count=updates.length;assert.throws(()=>api.h_updateDE({key:'ordinary',name:'Ordinary',isTestable:true}),/sendable DE/);assert.equal(updates.length,count);
assert.throws(()=>api.h_updateDE({key:'testable',name:'Testable',isTestable:'false'}),/checkbox/);
ignoreCoreFlag=false;before=updates.length;api.h_createDE({name:'Native flag',key:'native-flag',fields,isSendable:true,sendableField:'SubscriberKey',isTestable:true});assert.equal(updates.length,before);
ignoreUpdate=true;assert.throws(()=>api.h_updateDE({key:'testable',name:'Testable',isTestable:false}),/not verified/);ignoreUpdate=false;
// UI sends false explicitly and toggles dependency without sending a message.
const elements={};function element(id){return elements[id]||(elements[id]={value:'',checked:false,disabled:false,hidden:false,style:{},innerHTML:'',textContent:'',querySelectorAll(){return []},setAttribute(){}});}
const browser=vm.createContext({URL,URLSearchParams,document:{getElementById:element,querySelectorAll(){return []}},location:{href:'https://unit.test/page',protocol:'https:'}});
vm.runInContext(blocks[1].slice(0,blocks[1].indexOf('/* ---------- init ---------- */')),browser);const run=s=>vm.runInContext(s,browser);
element('de-sendable').checked=true;run('toggleSendable()');assert.equal(element('de-testable').disabled,false);
element('de-testable').checked=true;element('de-sendable').checked=false;run('toggleSendable()');assert.equal(element('de-testable').checked,false);assert.equal(element('de-testable').disabled,true);
run("globalThis.requests=[];readFields=function(){return [{name:'ID',type:'Text',maxLength:'254'},{name:'Email',type:'EmailAddress'}]};api=async function(action,data){requests.push({action,data});return {key:'created'};};");
element('de-name').value='Checkbox test';element('de-sendable').checked=true;element('de-sendfield').value='ID';element('de-testable').checked=true;
(async()=>{
 await run('createDE()');assert.equal(browser.requests.at(-1).data.isTestable,true);
 element('de-testable').checked=false;await run('createDE()');assert.equal(browser.requests.at(-1).data.isTestable,false);
 run("deEdit={row:{CustomerKey:'testable'},fields:[]};listDEs=async function(){};");element('edit-de-name').value='Testable';element('edit-de-testable').disabled=false;element('edit-de-testable').checked=false;
 await run('saveDEEdit()');assert.equal(browser.requests.at(-1).data.isTestable,false);
 element('edit-de-testable').disabled=true;await run('saveDEEdit()');assert.equal(browser.requests.at(-1).data.isTestable,undefined);
 console.log('PASS: Is Testable create/edit values including false; sendable dependency; Core flag fallback; direct persistence; read-back failures; preserving unknown/omitted values; checkbox toggling; no sends or live SFMC operations.');
})().catch(()=>{console.error('Testable UI checks failed');process.exitCode=1});
