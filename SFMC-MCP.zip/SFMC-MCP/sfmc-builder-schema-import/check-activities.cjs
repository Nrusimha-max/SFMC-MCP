const fs=require('fs'),vm=require('vm'),assert=require('assert/strict'),crypto=require('crypto'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'sfmc-builder-schema-import.html'),'utf8');const blocks=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(m=>m[1]);blocks.forEach(block=>new vm.Script(block));
let vars={},rowStatus='2';
const ctx=vm.createContext({Stringify:JSON.stringify,Platform:{Load(){},Response:{SetResponseHeader(){}},Variable:{SetValue(key,value){vars[key]=value;}},Request:{GetQueryStringParameter(){return '0'}},Function:{TreatAsContent(){return crypto.createHash('sha256').update(vars['@sb_hash_input']).digest('hex');}}}});
const testExports='globalThis.testAPI={h_createQuery,h_createAutomation,h_getAutomationSteps,h_attachActivity,cpAutomationTopology,sbAuthorize,setRest:function(fn){rest=fn;},setVerify:function(fn){cpVerifyAutomation=fn;}};';
vm.runInContext(blocks[0].replace(/\}\)\(\);\s*$/,testExports+'\n})();'),ctx);const api=ctx.testAPI;
api.setVerify(d=>({ProgramID:d.id,Name:d.name,CustomerKey:d.key,Status:rowStatus}));
const clone=x=>JSON.parse(JSON.stringify(x));
const original={id:'auto-A',name:'Automation A',type:'scheduled',startSource:{typeId:1},steps:[{id:'step-A',name:'Prepare',step:1,annotations:['keep'],activities:[{id:'instance-old',name:'Existing query',objectTypeId:300,activityObjectId:'query-old',displayOrder:1,customFlag:'keep'}]},{id:'step-B',name:'Send',step:2,activities:[{id:'instance-unknown',name:'Other activity',objectTypeId:999,activityObjectId:'other-old',displayOrder:1}]}]};
let definition=clone(original),requests=[],patches=[],reads=0,mode='normal',queryIdMode=false;
api.setRest((method,path,payload)=>{
 requests.push({method,path,payload:clone(payload??null)});
 if(path==='automation/v1/queries'&&method==='POST')return queryIdMode?{id:'created-query',name:payload.name,key:payload.key}:{queryDefinitionId:'created-query',name:payload.name,key:payload.key};
 if(path==='automation/v1/automations'&&method==='POST')return {id:'created-auto',name:payload.name,key:payload.key};
 if(path.startsWith('automation/v1/queries/')&&method==='GET')return {queryDefinitionId:path.split('/').at(-1).toLowerCase(),name:'Saved SQL'};
 assert.equal(path,'automation/v1/automations/auto-A');
 if(method==='GET'){reads++;if(mode==='concurrent'&&reads===2)definition.steps[0].name='Changed elsewhere';return clone(definition);}
 assert.equal(method,'PATCH');patches.push(clone(payload));if(mode!=='ignorePatch')definition.steps=clone(payload.steps);return {};
});
const query={name:'Reusable SQL',key:'reusable',sql:'SELECT ID FROM Source',targetKey:'target-key',targetName:'Target',targetId:'target-id',categoryId:'8',updateType:'0'};
const beforeInvalid=requests.length;assert.throws(()=>api.h_createQuery({...query,categoryId:'bad'}),/valid query folder/);assert.throws(()=>api.h_createQuery({...query,updateType:''}),/update action/);assert.equal(requests.length,beforeInvalid);
let result=api.h_createQuery(query);assert.equal(result.id,'created-query');assert.equal(requests.at(-1).path,'automation/v1/queries');assert.equal(requests.at(-1).payload.queryText,query.sql);assert.equal(patches.length,0);
queryIdMode=true;assert.equal(api.h_createQuery(query).id,'created-query');
api.h_createAutomation({name:'New automation',key:'new-auto',steps:[{name:'First',activities:[{type:'query',id:'query-old',name:'Old query'}]},{name:'Second',activities:[{type:'query',id:'query-new',name:'New query'}]}]});
assert.equal(requests.at(-1).payload.steps[0].stepNumber,0);assert.equal(requests.at(-1).payload.steps[1].stepNumber,1);assert.equal(requests.at(-1).payload.steps[0].step,undefined);

const target={id:'auto-A',name:'Automation A',key:'auto-key'};
function plan(extra={}){const snapshot=api.h_getAutomationSteps(target);return {...target,definitionHash:snapshot.definitionHash,stepId:'step-A',stepIndex:0,stepName:'Prepare',activity:{type:'query',id:'query-new',name:'Reusable SQL'},...extra};}
let attach=plan();result=api.h_attachActivity(attach);assert.equal(result.stepName,'Prepare');assert.equal(patches.length,1);assert.deepEqual(Object.keys(patches[0]),['steps']);
assert.equal(definition.steps[0].activities[0].id,'instance-old');assert.equal(definition.steps[0].activities[0].customFlag,'keep');assert.equal(definition.steps[0].activities[1].activityObjectId,'query-new');assert.equal(definition.steps[0].activities[1].objectTypeId,300);assert.equal(definition.steps[1].activities[0].objectTypeId,999);assert.equal(definition.steps[0].stepNumber,0);assert.equal(definition.steps[1].stepNumber,1);assert.equal(definition.steps[0].step,undefined);assert.deepEqual(definition.startSource,{typeId:1});
let count=patches.length;assert.throws(()=>api.h_attachActivity(plan()),/already present/);assert.equal(patches.length,count);
assert.throws(()=>api.h_attachActivity(plan({activity:{type:'query',id:'QUERY-OLD',name:'Existing'}})),/already present/);assert.equal(patches.length,count);
definition=clone(original);attach=plan({addStep:true,stepId:'',stepName:'Enrich'});result=api.h_attachActivity(attach);assert.equal(definition.steps.length,3);assert.equal(definition.steps[2].name,'Enrich');assert.equal(definition.steps[2].stepNumber,2);assert.equal(result.stepName,'Enrich');
definition=clone(original);attach=plan();count=patches.length;rowStatus='3';assert.throws(()=>api.h_attachActivity(attach),/finishes/);assert.equal(patches.length,count);rowStatus='2';
assert.throws(()=>api.h_attachActivity({...attach,definitionHash:'stale'}),/steps changed/);assert.equal(patches.length,count);
assert.throws(()=>api.h_attachActivity({...attach,stepId:'missing-step'}),/no longer exists/);assert.equal(patches.length,count);
reads=0;mode='concurrent';assert.throws(()=>api.h_attachActivity(attach),/Another edit/);assert.equal(patches.length,count);mode='normal';
definition=clone(original);mode='normal';attach=plan();mode='ignorePatch';let beforePatch=patches.length;assert.throws(()=>api.h_attachActivity(attach),/assignment was not verified/);assert.equal(patches.length,beforePatch+1);mode='normal';
assert.equal(requests.filter(request=>request.path.includes('/actions/start')).length,0);

api.sbAuthorize('attachActivity');api.sbAuthorize('getAutomationSteps');
// Test standalone-save and explicit attachment user flows with a minimal browser harness.
const nodes={};let chosenTab='',modal='';const doc={getElementById(id){return nodes[id]||(nodes[id]={value:'',innerHTML:'',textContent:'',className:'',hidden:true,disabled:false,classList:{contains(){return false}},querySelectorAll(){return []},focus(){},setAttribute(){}})},querySelectorAll(){return []}};
const browser=vm.createContext({URL,URLSearchParams,document:doc,location:{href:'https://unit.test/page',protocol:'https:'}});
vm.runInContext(blocks[1].slice(0,blocks[1].indexOf('/* ---------- init ---------- */')),browser);
const run=s=>vm.runInContext(s,browser),node=id=>doc.getElementById(id);
run("globalThis.clientCalls=[];api=async function(action,data){clientCalls.push({action,data});return {id:'saved-query',name:'Independent SQL',key:'saved-key'};}; state.targetDEs=[{CustomerKey:'target-key',Name:'Target',ObjectID:'target-id'}];state.steps=[{name:'Draft step 1',activities:[]},{name:'Draft step 2',activities:[]}];");
node('q-target').value='0';node('q-name').value='Independent SQL';node('q-key').value='saved-key';node('q-sql').value='SELECT ID FROM Source';node('q-folder').value='8';node('q-action').value='0';
(async()=>{
 await run('createQuery()');assert.equal(browser.clientCalls.length,1);assert.equal(browser.clientCalls[0].action,'createQuery');assert.equal(run('state.steps[0].activities.length'),0);assert.equal(run('state.steps[1].activities.length'),0);assert.equal(run('state.lastSavedQuery.id'),'saved-query');assert.equal(node('q-saved-actions').hidden,false);assert.match(node('q-msg').textContent,/saved independently/);
 browser.captureModal=(title,html)=>{modal=html;};browser.captureTab=id=>{chosenTab=id;};run('openModal=captureModal;closeModal=function(){};activateWorkspaceTab=captureTab;');
 run('chooseDraftStep(state.lastSavedQuery)');assert.match(modal,/Choose a step/);assert.match(modal,/Draft step 2/);
 node('draft-query-step').value='';run('confirmDraftStep()');assert.equal(run('state.steps[0].activities.length'),0);
 node('draft-query-step').value='1';run('confirmDraftStep()');assert.equal(run('state.steps[1].activities[0].id'),'saved-query');assert.equal(run('state.steps[0].activities.length'),0);assert.equal(chosenTab,'tab-build');
 run("attachContext={activity:{type:'query',id:'saved-query',name:'Independent SQL'},automations:[{ProgramID:'auto-A',Name:'Automation A',CustomerKey:'auto-key'}],definition:{definitionHash:'version',steps:[{index:0,id:'step-A',name:'Prepare'}]}};api=async function(action,data){clientCalls.push({action,data});return {message:'Verified',activityName:'Independent SQL',automationName:'Automation A',stepName:'Prepare'};};");
 node('attach-automation').value='0';node('attach-step').value='';let calls=browser.clientCalls.length;await run('saveAttachedActivity()');assert.equal(browser.clientCalls.length,calls);
 node('attach-step').value='0';await run('saveAttachedActivity()');assert.equal(browser.clientCalls.at(-1).action,'attachActivity');assert.equal(browser.clientCalls.at(-1).data.stepId,'step-A');assert.equal(browser.clientCalls.at(-1).data.activity.id,'saved-query');assert.equal(node('attach-save').disabled,true);
 console.log('PASS: standalone SQL saves without draft/automation side effects; query ID variants; explicit draft step choice; saved-step attachment; existing instance IDs and unknown types preserved; zero-based create/update step writes; case-insensitive ID checks; ignored-write detection; new-step append; duplicates, running state and intervening edits blocked; read-back verification. All services mocked.');
})().catch(()=>{console.error('SQL client workflow checks failed');process.exitCode=1});
