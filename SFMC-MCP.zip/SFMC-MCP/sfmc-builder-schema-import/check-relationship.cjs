const fs=require('fs'),vm=require('vm'),assert=require('assert/strict'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'sfmc-builder-schema-import.html'),'utf8');
const blocks=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(m=>m[1]);
let records={},created=[],updates=[],ignore=false;
const fields=[{Name:'ID',FieldType:'Text',MaxLength:254},{Name:'Email',FieldType:'EmailAddress'},{Name:'NumericID',FieldType:'Number'}];
const copy=x=>JSON.parse(JSON.stringify(x));
const ctx=vm.createContext({Stringify:JSON.stringify,Platform:{Load(){},Response:{SetResponseHeader(){}},Request:{GetQueryStringParameter(){return '0'}}},DataExtension:{Retrieve(f){return Object.values(records).filter(r=>r[f.Property]===f.Value).map(copy)},Add(o){created.push(copy(o));records[o.CustomerKey]={CustomerKey:o.CustomerKey,Name:o.Name,IsSendable:!!o.SendableInfo,IsTestable:false,SendableDataExtensionField:o.SendableInfo?.Field,SendableSubscriberField:o.SendableInfo?{Name:o.SendableInfo.RelatesOn}:undefined}}},Script:{Util:{WSProxy:function(){this.retrieve=(t,p,f)=>({Status:'OK',Results:t==='DataExtensionField'?copy(fields):Object.values(records).filter(r=>r[f.Property]===f.Value).map(copy)});this.updateItem=(t,o)=>{updates.push(copy(o));if(!ignore)Object.assign(records[o.CustomerKey],copy(o));return {Status:'OK',Results:[{StatusCode:'OK'}]};};}}}});
vm.runInContext(blocks[0].replace(/\}\)\(\);\s*$/,'globalThis.api={h_createDE,h_updateDE,h_getDEProperties,cpSendRelationship};})();'),ctx);
const api=ctx.api, input=fields.map(f=>({name:f.Name,type:f.FieldType,maxLength:f.MaxLength}));
for(const [key,target,field] of [['default',undefined,'ID'],['numeric','Subscriber ID','NumericID'],['email','Email Address','Email']]){
 api.h_createDE({name:key,key,fields:input,isSendable:true,sendableField:field,subscriberField:target});
 assert.equal(created.at(-1).SendableInfo.RelatesOn,target||'Subscriber Key');assert.equal(created.at(-1).SendableInfo.Field.Name,field);
}
assert.throws(()=>api.h_createDE({name:'Bad boolean',key:'bad',fields:input,isSendable:'false'}),/checkbox/);
assert.throws(()=>api.h_updateDE({key:'default',name:'Default',sendRelationship:null}),/valid DE and subscriber/);
assert.throws(()=>api.cpSendRelationship(fields,'ID','Subscriber ID'),/Number/);
assert.throws(()=>api.cpSendRelationship(fields,'ID','Email Address'),/EmailAddress/);
assert.throws(()=>api.cpSendRelationship(fields,'Missing','Subscriber Key'),/existing/);
api.h_updateDE({key:'default',name:'Default',sendRelationship:{deField:'Email',subscriberField:'Email Address'}});
assert.equal(updates.at(-1).SendableDataExtensionField.Name,'Email');assert.equal(api.h_getDEProperties({key:'default'}).SubscriberField,'Email Address');
api.h_updateDE({key:'default',name:'Renamed'});assert.equal(updates.at(-1).SendableDataExtensionField,undefined);assert.equal(records.default.SendableDataExtensionField.Name,'Email');
ignore=true;assert.throws(()=>api.h_updateDE({key:'default',name:'Default',sendRelationship:{deField:'ID',subscriberField:'Subscriber Key'}}),/not verified/);ignore=false;
const elements={};const el=id=>elements[id]||(elements[id]={value:'',checked:false,disabled:false,hidden:false,style:{},innerHTML:'',textContent:'',querySelectorAll(){return []},setAttribute(){}});
const browser=vm.createContext({URL,URLSearchParams,document:{getElementById:el,querySelectorAll(){return []}},location:{href:'https://unit.test/',protocol:'https:'}});
vm.runInContext(blocks[1].slice(0,blocks[1].indexOf('/* ---------- init ---------- */')),browser);
const run=s=>vm.runInContext(s,browser);
assert.equal(run("relationshipFieldAllowed('Number','Subscriber ID')"),true);assert.equal(run("relationshipFieldAllowed('Text','Subscriber ID')"),false);
assert.match(run("editSendRelationshipHTML({IsSendable:'true',SendRelationshipAvailable:false},[])"),/disabled/);
run("deEdit={row:{CustomerKey:'default'},fields:[]};globalThis.requests=[];api=async function(action,data){requests.push({action,data});return {};};listDEs=async function(){};");
el('edit-de-name').value='Default';el('edit-de-testable').disabled=true;
(async()=>{
 await run('saveDEEdit()');assert.equal(browser.requests.at(-1).data.sendRelationship,undefined);
 el('edit-de-change-relationship').checked=true;el('edit-de-sendfield').value='Email';el('edit-de-subscriber-field').value='Email Address';
 await run('saveDEEdit()');assert.equal(browser.requests.at(-1).data.sendRelationship.deField,'Email');
 console.log('PASS: create defaults and three mappings; incompatible fields rejected; SOAP update and readback; unrelated edits preserve mapping; explicit editor opt-in; unavailable metadata disables edit. All SFMC services mocked.');
})().catch(()=>{console.error('Relationship UI checks failed');process.exitCode=1});
