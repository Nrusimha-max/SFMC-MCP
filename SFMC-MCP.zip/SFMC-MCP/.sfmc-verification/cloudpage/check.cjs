const fs=require('fs'),vm=require('vm'),assert=require('assert/strict'),path=require('path');
const source=fs.readFileSync(path.join(__dirname,'../../cloudpage-updated.html'),'utf8');
const blocks=[...source.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(m=>m[1]);
blocks.forEach(block=>new vm.Script(block));
const db=[{ObjectID:'de-1',CustomerKey:'key-1',Name:'Example',CategoryID:2,Description:'Initial',IsSendable:false}];
let reads=[],writes=[],failCreate=false;
const fields=[{ObjectID:'field-1',Name:'ID',FieldType:'Text',MaxLength:254,Ordinal:1,IsPrimaryKey:true,IsRequired:true},{ObjectID:'field-2',Name:'Email',FieldType:'EmailAddress',MaxLength:254,Ordinal:2,IsPrimaryKey:false,IsRequired:false}];
const context=vm.createContext({
 Platform:{Load(){},Request:{GetQueryStringParameter(){return '0';}}},Stringify:JSON.stringify,
 DataExtension:{
  Retrieve(filter){reads.push(filter);return db.filter(row=>String(row[filter.Property])===String(filter.Value));},
  Init(key){assert.ok(db.some(d=>d.CustomerKey===key));return {Fields:{Retrieve(){return fields.map(f=>({...f}));}}};},
  Add(payload){writes.push({op:'create',payload});if(failCreate)throw new Error('invalid length');db.push({...payload,ObjectID:'created-1'});return {Fields:{}};}
 },
 Folder:{Retrieve(filter){return [{ID:filter.Value,Name:filter.Value===2?'Campaigns':'Data Extensions',ParentFolder:{ID:filter.Value===2?1:0}}];}},
 Script:{Util:{WSProxy:function(){
  this.retrieve=(type,props,filter)=>({Status:'OK',Results:type==='DataExtension'?db.filter(r=>!filter||r[filter.Property]===filter.Value):(type==='DataExtensionField'&&filter.Value==='key-1'?fields:[]),HasMoreRows:false});
  this.getNextBatch=()=>({Status:'OK',Results:[],HasMoreRows:false});
  this.updateItem=(type,payload)=>{writes.push({op:'update',payload});return {Status:'OK',Results:[{StatusCode:'OK'}]};};
 }}}
});
const testServer=blocks[0].replace(/\}\)\(\);\s*$/, 'globalThis.__cpTest={normalizeDEFields,h_listDEs,h_deFields,h_createDE,h_updateDE,h_listAutomations,h_runAutomation,h_getAutomation,cpAutomationRunPayload,h_getStartingSource,h_saveStartingSource,cpSourcePlan,cpXmlBlocks,cpXmlText,cpXmlSpan,cpTrim,setAutoSoap:function(fn){cpAutomationSoap=fn;},setRunDefinition:function(fn){rest=fn;},setRunTransport:function(fn){httpCall=fn;getToken=function(){REST_BASE="https://unit.test/";_token="unit-test";};}};\n})();');
context.trim=function(){throw new Error('Global Core trim must not be overridden or called');};
const originalTrim=context.trim;
vm.runInContext(testServer,context);assert.equal(context.trim,originalTrim);
Object.assign(context,context.__cpTest);const run=code=>vm.runInContext(code,context);
for(const type of ['Text','Number','Date','Boolean','EmailAddress','Phone','Decimal','Locale']){
 const f=run(`normalizeDEFields([{name:'Value',type:'${type}',maxLength:18,scale:0}])[0]`);
 if(type==='EmailAddress')assert.equal(f.MaxLength,254);
 if(type==='Phone')assert.equal(f.MaxLength,50);
 if(type==='Locale')assert.equal(f.MaxLength,5);
 if(type==='Decimal')assert.equal(f.Scale,0);
 if(['Number','Date','Boolean'].includes(type))assert.equal(f.MaxLength,undefined);
}
assert.throws(()=>run("normalizeDEFields([{name:'T',type:'Text',maxLength:4001}])"));
assert.throws(()=>run("normalizeDEFields([{name:'D',type:'Decimal',maxLength:2,scale:3}])"));
let found=run("h_listDEs({search:'Example'})");assert.equal(found.rows[0].CustomerKey,'key-1');assert.equal(found.rows[0].folderPath,'Data Extensions / Campaigns');
found=run("h_listDEs({search:'key-1'})");assert.equal(found.rows[0].Name,'Example');
assert.equal(run("h_listDEs({search:'missing'}).rows.length"),0);
assert.equal(run("h_deFields({key:'key-1'})[0].Name"),'ID');
assert.equal(run("h_deFields({key:'Example'}).length"),0);
assert.equal(run("h_deFields({key:'key-1'})[0].MaxLength"),254);
assert.equal(run("h_deFields({key:'key-1'})[1].MaxLength"),254);
let created=run("h_createDE({name:'New',key:'new-key',isSendable:true,sendableField:'ID',fields:[{name:'ID',type:'Text',maxLength:254,pk:true},{name:'Email',type:'EmailAddress'}]})");
assert.equal(created.newObjectId,'created-1');assert.equal(writes.at(-1).payload.SendableInfo.Field.Name,'ID');assert.equal(writes.at(-1).payload.Fields[1].MaxLength,254);assert.equal(writes.at(-1).payload.CategoryID,undefined);
let count=writes.length;assert.throws(()=>run("h_createDE({name:'Duplicate',key:'new-key',fields:[{name:'ID',type:'Text'}]})"),/already exists/);assert.equal(writes.length,count);
failCreate=true;assert.throws(()=>run("h_createDE({name:'Failure',fields:[{name:'ID',type:'Text'}]})"),/SFMC Builder.*Core DataExtension.Add.*invalid length/);failCreate=false;
run("h_updateDE({key:'key-1',name:'Renamed',description:'Updated',categoryId:10,lengths:[{name:'ID',maxLength:300}],addFields:[{name:'Age',type:'Number'}]})");
assert.equal(writes.at(-1).payload.ObjectID,'de-1');assert.equal(writes.at(-1).payload.Fields[0].Name,'ID');assert.equal(writes.at(-1).payload.Fields[0].MaxLength,300);assert.equal(writes.at(-1).payload.Fields[1].Name,'Age');
count=writes.length;
assert.throws(()=>run("h_updateDE({key:'key-1',name:'Test',lengths:[{name:'ID',maxLength:49}]})"));
assert.throws(()=>run("h_updateDE({key:'key-1',name:'Test',addFields:[{name:'ID',type:'Text'}]})"));
assert.equal(writes.length,count);
let autoCalls=[],autoMode='normal',autoState='2';
function retrieveXml(rows,status='OK'){
 return '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><p:RetrieveResponseMsg xmlns:p="http://exacttarget.com/wsdl/partnerAPI"><p:OverallStatus>'+status+'</p:OverallStatus><p:RequestID>request-1</p:RequestID>'+rows.map(row=>'<p:Results xsi:type="p:Automation" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><p:PartnerProperties><p:Name>AutomationType</p:Name><p:Value>scheduled</p:Value></p:PartnerProperties><p:Name>'+row.name+'</p:Name><p:ProgramID>'+row.id+'</p:ProgramID><p:CustomerKey>'+row.key+'</p:CustomerKey><p:Status>'+row.status+'</p:Status><p:Description xsi:nil="true" /></p:Results>').join('')+'</p:RetrieveResponseMsg></s:Body></s:Envelope>';
}
context.setAutoSoap(function(action,body){
 autoCalls.push({action,body});
 if(action==='Perform')return '<PerformResponseMsg><OverallStatus>'+ (autoMode==='executeError'?'Error':'OK')+'</OverallStatus><Results><StatusCode>'+(autoMode==='executeError'?'Error':'OK')+'</StatusCode><StatusMessage>'+(autoMode==='executeError'?'Execute permission missing':'Start accepted')+'</StatusMessage><ErrorCode>'+(autoMode==='executeError'?'7':'0')+'</ErrorCode></Results></PerformResponseMsg>';
 if(autoMode==='error')return '<RetrieveResponseMsg><OverallStatus>Error: Invalid property</OverallStatus></RetrieveResponseMsg>';
 if(autoMode==='empty')return retrieveXml([]);
 if(autoMode==='keyOnly'&&body.includes('<Property>Name</Property>'))return retrieveXml([]);
 return retrieveXml([{id:'auto-1',name:'<![CDATA[test01]]>',key:'test-key',status:autoState}],autoMode==='more'?'MoreDataAvailable':'OK');
});
assert.equal(run("cpXmlText('<a:Name>A &amp; B</a:Name>','Name')"),'A & B');
assert.equal(run("cpXmlText('<Name><![CDATA[A < B]]></Name>','Name')"),'A < B');
// Exercise edge cases with substring disabled to detect any runtime bridge regression.
run("String.prototype.substring=function(){throw new Error('substring must not be used by automation XML parsing');}");
for(const xml of ['', '<', '</Name>', '<Name/>', '<Name></Name>', '<!-- unfinished', '<![CDATA[unfinished', '<Name><']) {
 context.edgeXml=xml;
 run("cpXmlBlocks(edgeXml,'Name'); cpXmlText(edgeXml,'Name')");
}
assert.equal(run("cpXmlSpan('abc',-1,2)"),'ab');
assert.equal(run("cpXmlSpan('abc',2,1)"),'');
assert.equal(run("cpXmlSpan('abc',20,30)"),'');
assert.equal(run("cpXmlText('<Name><![CDATA[]]></Name>','Name')"),'');
let autos=run("h_listAutomations({search:'test01'})");assert.equal(autos.rows[0].ProgramID,'auto-1');assert.equal(autos.rows[0].Name,'test01');assert.equal(autos.rows[0].Status,'2');
assert.match(autoCalls.at(-1).body,/<Property>Name<\/Property>/);assert.match(autoCalls.at(-1).body,/<Value>test01<\/Value>/);
autoMode='keyOnly';autos=run("h_listAutomations({search:'test-key'})");assert.equal(autos.rows[0].CustomerKey,'test-key');assert.match(autoCalls.at(-1).body,/<Property>CustomerKey<\/Property>/);
autoMode='more';autos=run("h_listAutomations({search:'test01'})");assert.equal(autos.requestId,'request-1');assert.equal(autos.more,true);
run("h_listAutomations({requestId:'request-1',soapType:'Automation'})");assert.match(autoCalls.at(-1).body,/<ContinueRequest>request-1<\/ContinueRequest>/);
autoMode='empty';assert.equal(run("h_listAutomations({search:'missing'}).rows.length"),0);
autoMode='error';assert.throws(()=>run("h_listAutomations({search:'test01'})"),/Invalid property/);
autoMode='normal';let triggerCalls=[],triggerStatus=202,definitionMode='normal',definitionReads=[];
const savedDefinition={id:'auto-1',name:'test01',type:'scheduled',status:'Ready',statusId:2,steps:[{activities:[{id:'instance-1',activityObjectId:'query-1'},{id:'instance-2',activityObjectId:'script-1'}]},{activities:[{id:'instance-3',activityObjectId:'query-2'}]}]};
context.setRunDefinition(function(method,path){
 assert.equal(method,'GET');assert.equal(path,'automation/v1/automations/auto-1');definitionReads.push(path);
 if(definitionMode==='missingId')return {id:'auto-1',type:'scheduled',status:'Ready',statusId:2,steps:[{activities:[{activityObjectId:'query-1'}]}]};
 if(definitionMode==='noSteps')return {id:'auto-1',steps:[]};
 if(definitionMode==='error')throw new Error('Definition read failed');
 return savedDefinition;
});
context.setRunTransport(function(method,url,type,body,headers,allowEmpty){triggerCalls.push({method,url,type,body,allowEmpty});return {status:triggerStatus,text:triggerStatus===403?'Denied':''};});
let starts=()=>triggerCalls.length;
assert.throws(()=>run("h_runAutomation({id:'',name:''})"),/valid name and ID/);assert.equal(starts(),0);
assert.throws(()=>run("h_runAutomation({id:'wrong',name:'test01'})"),/could not be verified/);assert.equal(starts(),0);
autoState='3';assert.throws(()=>run("h_runAutomation({id:'auto-1',name:'test01',key:'test-key'})"),/already running/);assert.equal(starts(),0);
autoState='2';
for(const status of [200,202,204]){
 triggerStatus=status;const started=run("h_runAutomation({id:'auto-1',name:'test01',key:'test-key'})");assert.equal(started.httpStatus,status);assert.equal(started.name,'test01');
 assert.equal(triggerCalls.at(-1).method,'POST');assert.equal(triggerCalls.at(-1).url,'https://unit.test/automation/v1/automations/auto-1/actions/start');assert.equal(triggerCalls.at(-1).allowEmpty,true);const payload=JSON.parse(triggerCalls.at(-1).body);assert.equal(payload.type,'scheduled');assert.equal(payload.status,'Ready');assert.equal(payload.statusId,2);assert.equal(payload.id,'auto-1');assert.equal(payload.steps.length,2);assert.equal(payload.steps[0].activities.length,2);assert.equal(payload.steps[0].activities[0].id,'instance-1');assert.equal(payload.steps[0].activities[0].IsIncludedInRun,true);assert.equal(payload.steps[1].activities[0].id,'instance-3');assert.ok(!('activityObjectId' in payload.steps[0].activities[0]));
}
assert.equal(autoCalls.filter(c=>c.action==='Perform').length,0);
for(const mode of ['missingId','noSteps','error']){
 definitionMode=mode;const before=starts();assert.throws(()=>run("h_runAutomation({id:'auto-1',name:'test01',key:'test-key'})"));assert.equal(starts(),before);
}
definitionMode='normal';assert.ok(definitionReads.length>=3);
for(const type of ['unspecified','',undefined]){
 const old=savedDefinition.type;savedDefinition.type=type;const before=starts();assert.throws(()=>run("h_runAutomation({id:'auto-1',name:'test01',key:'test-key'})"),/no usable automation type/);assert.equal(starts(),before);savedDefinition.type=old;
}
for(const state of [{status:'Scheduled',statusId:6},{status:'Building',statusId:1}]){
 savedDefinition.status=state.status;savedDefinition.statusId=state.statusId;const before=starts();assert.throws(()=>run("h_runAutomation({id:'auto-1',name:'test01',key:'test-key'})"),/Ready or Paused/);assert.equal(starts(),before);
}
savedDefinition.status='Paused';savedDefinition.statusId=4;triggerStatus=202;
run("h_runAutomation({id:'auto-1',name:'test01',key:'test-key'})");assert.equal(JSON.parse(triggerCalls.at(-1).body).status,'Paused');
savedDefinition.status='Ready';savedDefinition.statusId=2;


triggerStatus=403;let before=starts();assert.throws(()=>run("h_runAutomation({id:'auto-1',name:'test01',key:'test-key'})"),/HTTP 403.*Denied/);assert.equal(starts(),before+1);
let sourceDefinition={id:'auto-1',name:'test01',type:'unspecified',statusId:2},sourceWrites=[],sourceIgnore=false,sourceMismatch=false;
context.setRunDefinition(function(method,path,payload){
 assert.equal(path,'automation/v1/automations/auto-1');
 if(method==='GET')return JSON.parse(JSON.stringify(sourceDefinition));
 assert.equal(method,'PATCH');sourceWrites.push(payload);
 if(!sourceIgnore){sourceDefinition.type='scheduled';sourceDefinition.startSource=JSON.parse(JSON.stringify(payload.startSource));if(sourceMismatch)sourceDefinition.startSource.schedule.timeZoneId=76;}
 return {ok:true};
});
const sourceArgs="{id:'auto-1',name:'test01',key:'test-key',start:'2026-12-01T10:30:00',timeZoneId:'34',frequency:'DAILY',interval:'2',count:'10'}";
let savedSource=run('h_saveStartingSource('+sourceArgs+')');assert.equal(savedSource.source.type,'scheduled');assert.equal(sourceWrites.length,1);assert.equal(sourceWrites[0].startSource.typeId,1);assert.equal(sourceWrites[0].startSource.schedule.iCalRecur,'FREQ=DAILY;INTERVAL=2;COUNT=10');assert.equal(sourceWrites[0].startSource.schedule.timeZoneId,34);assert.ok(!('steps' in sourceWrites[0]));
assert.equal(run("h_getStartingSource({id:'auto-1',name:'test01',key:'test-key'}).source.schedule.startDate"),'2026-12-01T10:30:00');
let sourceCount=sourceWrites.length;assert.throws(()=>run("cpSourcePlan({frequency:'DAILY',interval:'0',count:'10',timeZoneId:'34',start:'2026-12-01T10:30:00'})"),/Interval/);assert.equal(sourceWrites.length,sourceCount);
autoState='3';assert.throws(()=>run('h_saveStartingSource('+sourceArgs+')'),/finish/);assert.equal(sourceWrites.length,sourceCount);autoState='2';
sourceIgnore=true;sourceDefinition={type:'unspecified',statusId:2};assert.throws(()=>run('h_saveStartingSource('+sourceArgs+')'),/read-back did not confirm/);assert.equal(sourceWrites.length,sourceCount+1);
sourceIgnore=false;sourceMismatch=true;sourceDefinition={type:'unspecified',statusId:2};assert.throws(()=>run('h_saveStartingSource('+sourceArgs+')'),/read-back did not confirm/);assert.equal(sourceWrites.length,sourceCount+2);
assert.equal(autoCalls.filter(c=>c.action==='Perform'||c.action==='Schedule').length,0);
sourceIgnore=false;sourceMismatch=false;sourceDefinition={id:'auto-1',type:'unspecified',statusId:2};
const manualArgs="{id:'auto-1',name:'test01',key:'test-key',mode:'manual'}";
let manualSource=run('h_saveStartingSource('+manualArgs+')');assert.match(manualSource.message,/Run once only/);
const manualPatch=sourceWrites.at(-1);assert.equal(manualPatch.type,'scheduled');assert.equal(manualPatch.startSource.typeId,1);assert.equal(manualPatch.startSource.schedule,undefined);assert.ok(!JSON.stringify(manualPatch).includes('startDate'));assert.ok(!JSON.stringify(manualPatch).includes('iCalRecur'));
sourceDefinition.startSource.schedule={startDate:'2026-12-01T10:30:00',iCalRecur:'FREQ=DAILY'};sourceCount=sourceWrites.length;
assert.throws(()=>run('h_saveStartingSource('+manualArgs+')'),/already has a timed schedule/);assert.equal(sourceWrites.length,sourceCount);
sourceIgnore=true;sourceDefinition={type:'unspecified',statusId:2};assert.throws(()=>run('h_saveStartingSource('+manualArgs+')'),/did not confirm Schedule source/);sourceIgnore=false;
const elements={};const element=id=>elements[id]||(elements[id]={value:'',textContent:'',innerHTML:'',className:''});
const browser=vm.createContext({URL,URLSearchParams,location:{href:'https://example.test/page?old=1&api=0',protocol:'https:'},document:{getElementById:element,querySelectorAll(){return [];}},confirm(){return true;}});
vm.runInContext(blocks[1].slice(0,blocks[1].indexOf('/* ---------- init ---------- */')),browser);
vm.runInContext('api = async function(action,data){return {rows:[{Name:"Example",CustomerKey:"key-1",IsSendable:"false",folderPath:"Data Extensions / Campaigns"}],more:false};}',browser);
element('de-search').value='Example';
(async()=>{
 await vm.runInContext('listDEs()',browser);
 assert.match(element('de-list').innerHTML,/editDE\(0\)/);
 assert.match(element('de-list').innerHTML,/key-1/);
 assert.match(element('de-list').innerHTML,/Data Extensions \/ Campaigns/);
 assert.match(element('de-list-msg').textContent,/exact matches/);
 vm.runInContext("sourceEditorTarget={id:'auto-1',name:'test01',key:'test-key'}; listAutomations=async function(){}; api=async function(action,payload){globalThis.savedManualPayload=payload;return {message:'Verified'};};",browser);
 element('source-mode').value='manual';
 await vm.runInContext('saveStartingSource()',browser);
 assert.equal(browser.savedManualPayload.mode,'manual');assert.equal(browser.savedManualPayload.start,undefined);assert.equal(browser.savedManualPayload.frequency,undefined);

 assert.equal(new URL(vm.runInContext('API_URL',browser)).searchParams.getAll('api').length,1);
 // Run the real browser api() against the full dispatcher with mocked SFMC services.
 vm.runInContext(blocks[1].slice(0,blocks[1].indexOf('/* ---------- init ---------- */')),browser);
 let requestForm=null;
 browser.fetch=async(url,options)=>{
  assert.match(options.headers['Content-Type'],/application\/x-www-form-urlencoded/);
  requestForm=new URLSearchParams(options.body);
  assert.equal(requestForm.has('payload'),false);
  let output='';
  const backend=vm.createContext({...context,Platform:{Load(){},Function:{ParseJSON(){throw new Error('Incoming ParseJSON must never run');}},Variable:{SetValue(){}},Request:{GetQueryStringParameter(){return '1';},GetFormField(name){return requestForm.get(name);},GetPostData(){throw new Error('Raw body path must not be called');}}},Write(value){output+=value;}});
  vm.runInContext(blocks[0],backend);
  return {text:async()=>output};
 };
 const result=await vm.runInContext("api('listDEs',{search:'key-1'})",browser);
 assert.equal(result.rows[0].CustomerKey,'key-1');
 const made=await vm.runInContext("api('createDE',{name:'Transport Test',key:'transport-test',description:'A & B + 50% = café',fields:[{name:'ID',type:'Text',maxLength:'254',pk:true},{name:'Email',type:'EmailAddress'}]})",browser);
 assert.equal(made.key,'transport-test');
 assert.ok([...requestForm.values()].includes('A & B + 50% = café'));
 assert.equal(writes.at(-1).payload.Description,'A & B + 50% = café');
 await assert.rejects(()=>vm.runInContext("api('unknownAction',{})",browser),/SFMC Builder/);
 console.log('PASS: syntax; isolated helpers; exact finder and Edit; field rules; native create and update guards; full browser-to-dispatcher form transport including nested arrays, maxLength, ampersands, plus, percent and Unicode, with ParseJSON disabled; explicit SOAP field lengths; SOAP XML fixtures with namespaces, CDATA, escaped names and nil fields; exact name/key search; continuation; mismatched target blocking; running guard; REST-only trigger endpoint; saved type/status included; Ready/Paused accepted; Scheduled/Building and unspecified-type blocked without writes; saved multi-step definition, activity instance IDs and inclusion flags; missing-ID/empty-step/read-failure blocks; 200/202/204 responses, empty bodies and single-attempt 403 failure; no SOAP Perform; XML edge cases with substring disabled; SFMC Builder error branding; source GET/PATCH/GET, recurrence/time zone, running-state guard, silent-ignore and mismatched-readback rejection; no start or schedule activation during source saves; manual source mode omits dates and recurrence end-to-end; existing timed schedules are preserved. All SFMC calls mocked.');
})().catch(()=>{console.error('Browser contract check failed');process.exitCode=1;});
