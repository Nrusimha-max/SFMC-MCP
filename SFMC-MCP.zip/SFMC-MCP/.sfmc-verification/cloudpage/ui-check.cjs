const fs=require('fs'),vm=require('vm'),assert=require('assert/strict'),path=require('path');
const root=path.resolve(__dirname,'../..');
const html=fs.readFileSync(path.join(root,'sfmc-builder-ui.html'),'utf8');
const prior=fs.readFileSync(path.join(root,'sfmc-builder-r18.html'),'utf8');
const server=s=>s.match(/<script runat="server">([\s\S]*?)<\/script>/)[1];
assert.equal(server(html),server(prior),'UI release must preserve the server implementation');
const blocks=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(m=>m[1]);blocks.forEach(s=>new vm.Script(s));
let doc;const nodes={};
function node(id){
 if(nodes[id])return nodes[id];
 const classes=new Set(),events={};
 return nodes[id]={id,dataset:{},style:{},attrs:{},events,innerHTML:'',textContent:'',value:'',disabled:false,tabIndex:0,isConnected:true,
  classList:{add(c){classes.add(c)},remove(c){classes.delete(c)},contains(c){return classes.has(c)},toggle(c,on){if(on)classes.add(c);else classes.delete(c)}},
  setAttribute(k,v){this.attrs[k]=v},addEventListener(k,fn){events[k]=fn},focus(){doc.activeElement=this},getClientRects(){return [{}]},querySelector(){return null},querySelectorAll(){return []}
 };
}
const nav=['tab-de','tab-build','tab-run'].map((id,i)=>{const n=node('nav-'+id);n.dataset.tab=id;return n;});
const sections=['tab-de','tab-build','tab-run'].map(node);const listeners={};
const close=node('modal-close'),last=node('last-dialog-control'),menus=[];
node('modal-bg').querySelector=()=>close;node('modal-bg').querySelectorAll=()=>[close,last];
doc={body:{style:{overflow:'auto'}},activeElement:node('opener'),getElementById:node,
 querySelectorAll(selector){if(selector==='nav button[data-tab]')return nav;if(selector==='main > section.tab')return sections;if(selector==='.action-menu[open]')return menus.filter(m=>m.open);return [];},
 addEventListener(name,fn){(listeners[name]||(listeners[name]=[])).push(fn)}
};
const storage=new Map();const window={innerWidth:900,innerHeight:700,sessionStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)}};
const ctx=vm.createContext({document:doc,window,URL,URLSearchParams,location:{href:'https://unit.test/page',protocol:'https:'},confirm(){return false;}});
vm.runInContext(blocks[1].slice(0,blocks[1].indexOf('/* ---------- init ---------- */')),ctx);
const run=s=>vm.runInContext(s,ctx);
run("activateWorkspaceTab('tab-run')");assert.equal(node('workspace-title').textContent,'Automation operations');assert.equal(nav[2].attrs['aria-selected'],'true');assert.ok(sections[2].classList.contains('active'));assert.equal(storage.get('sfmc-workspace-tab'),'tab-run');
nav[2].events.keydown({key:'ArrowRight',preventDefault(){}});assert.equal(nav[0].attrs['aria-selected'],'true');assert.equal(doc.activeElement,nav[0]);
run("setDEView('find')");assert.ok(node('de-find-panel').classList.contains('de-view-active'));assert.ok(!node('de-create-panel').classList.contains('de-view-active'));assert.equal(node('de-find-view-tab').attrs['aria-selected'],'true');
run("setSearchLoading('run-search-btn',true)");assert.equal(node('run-search-btn').disabled,true);assert.match(node('run-search-btn').innerHTML,/Searching/);run("setSearchLoading('run-search-btn',false)");assert.equal(node('run-search-btn').innerHTML,'Search');
const opener=doc.activeElement;run("openModal('Example','<p>Content</p>')");assert.equal(doc.body.style.overflow,'hidden');assert.equal(doc.activeElement,close);assert.ok(node('modal-bg').classList.contains('open'));
doc.activeElement=last;let prevented=false;listeners.keydown.forEach(fn=>fn({key:'Tab',shiftKey:false,preventDefault(){prevented=true}}));assert.equal(prevented,true);assert.equal(doc.activeElement,close);
listeners.keydown.forEach(fn=>fn({key:'Escape'}));assert.equal(doc.body.style.overflow,'auto');assert.equal(doc.activeElement,opener);assert.ok(!node('modal-bg').classList.contains('open'));
run("api=async function(){return {rows:[{Name:'test02',ProgramID:'auto-1',CustomerKey:'key',Status:'2'}],more:false};}");
(async()=>{
 await run('listAutomations()');
 const rendered=node('run-list').innerHTML;
 assert.match(rendered,/class="table-actions"/);assert.match(rendered,/class="action-menu"/);assert.match(rendered,/Configure starting source/);assert.match(rendered,/Activate schedule/);assert.equal(node('run-msg').textContent,'1 automation loaded.');assert.equal(node('run-search-btn').disabled,false);
 assert.match(html,/\.fields-table\{min-width:1120px;table-layout:fixed/);assert.match(html,/\.fields-table th:nth-child\(1\)\{width:230px/);assert.match(html,/\.fields-table th:nth-child\(2\)\{width:175px/);
 assert.match(html,/prefers-reduced-motion/);assert.match(html,/role="dialog" aria-modal="true"/);
 console.log('PASS: server unchanged; workspace and DE view navigation; keyboard tabs; loading feedback; modal focus trap/Escape/return focus; grouped automation actions; singular count; field width rules; responsive and reduced-motion styles. No network or SFMC execution.');
})().catch(()=>{console.error('UI interaction checks failed');process.exitCode=1});
