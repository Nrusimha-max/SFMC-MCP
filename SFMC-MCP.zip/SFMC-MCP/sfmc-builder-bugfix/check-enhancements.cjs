const fs=require('fs'),vm=require('vm'),crypto=require('crypto'),assert=require('assert/strict'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'sfmc-builder-bugfix.html'),'utf8');
const scripts=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(m=>m[1]);scripts.forEach(s=>new vm.Script(s));
const names={plans:'SFMC_Builder_Plans',payloads:'SFMC_Builder_Payloads',audit:'SFMC_Builder_Audit'},tables={};Object.values(names).forEach(name=>tables[name]=[]);
let guid=0,auditFails=false,finalAuditFails=false,hostingMid='100010552',operations=[];
const now=Math.floor(Date.now()/1000),form={builderSession:'a'.repeat(64)},vars={};
const guidValue=()=>`00000000-0000-4000-8000-${String(++guid).padStart(12,'0')}`;
function extension(name){if(!tables[name])throw new Error('Missing support DE');return {Rows:{Retrieve(filter){return tables[name].filter(row=>String(row[filter.Property])===String(filter.Value)).map(row=>({...row}));},Add(row){if(name===names.audit&&(auditFails||(finalAuditFails&&row.State==='completed')))return 0;tables[name].push({...row});return 1;},Update(values,keys,match){let count=0;for(const row of tables[name])if(keys.every((key,i)=>String(row[key])===String(match[i]))){Object.assign(row,values);count++;}return count;}}};}
const env={Stringify:JSON.stringify,DataExtension:{Init:extension},Platform:{Load(){},Response:{SetResponseHeader(){}},Variable:{SetValue(name,value){vars[name]=value;}},Request:{GetQueryStringParameter(){return '0'},GetFormField(name){return form[name]??null;}},Function:{GUID:guidValue,TreatAsContent(source){if(source==='%%memberid%%')return hostingMid;if(source.includes('SHA256'))return crypto.createHash('sha256').update(vars['@sb_hash_input']).digest('hex');throw new Error('Unexpected AMPscript');}}}};
env.Script={Util:{WSProxy:function(){this.retrieve=(type,props,filter)=>({Status:'OK',HasMoreRows:false,Results:tables[names.audit].filter(row=>String(row[filter.Property])===String(filter.Value)).map(row=>({Properties:props.map(name=>({Name:name,Value:row[name]}))}))});}}};
const exposed='globalThis.helpers={sbBindSession,sbPrepare,sbExecute,sbAuditHistory,bindTarget:function(fn){cpVerifyAutomation=fn;}};';
const context=vm.createContext(env);vm.runInContext(scripts[0].replace(/\}\)\(\);\s*$/,exposed+'\n})();'),context);const api=context.helpers;
api.bindTarget(data=>({ProgramID:data.id,Name:data.name}));
form.builderSession='invalid';assert.throws(()=>api.sbBindSession(),/Reload/);form.builderSession='a'.repeat(64);
hostingMid='100010553';assert.throws(()=>api.sbBindSession(),/mismatch/);hostingMid='100010552';api.sbBindSession();
const routes={createDE(data){operations.push(data);return {key:data.key||data.name};},runAutomation(data){operations.push(data);return {name:data.name};}};
const payload={name:'Example',key:'example',description:'A & B + 50% = café',fields:[{name:'ID',type:'Text',maxLength:'254',pk:true}]};
let plan=api.sbPrepare({action:'createDE',payload});assert.equal(operations.length,0);assert.equal(plan.effectiveFields[0].MaxLength,254);api.sbExecute({planId:plan.planId,payload:{name:'Tampered'}},routes);assert.equal(operations.at(-1).name,'Example');assert.equal(operations.at(-1).description,payload.description);assert.equal(tables[names.audit].at(-1).State,'completed');assert.match(tables[names.audit].at(-1).ActorLabel,/Browser session/);assert.equal(tables[names.audit].at(-1).ActorName,undefined);
let count=operations.length;assert.throws(()=>api.sbExecute({planId:plan.planId},routes),/already used/);assert.equal(operations.length,count);
plan=api.sbPrepare({action:'createDE',payload});tables[names.plans].at(-1).ExpiresEpoch=String(now-1);assert.throws(()=>api.sbExecute({planId:plan.planId},routes),/expired/);
plan=api.sbPrepare({action:'createDE',payload});form.builderSession='b'.repeat(64);api.sbBindSession();assert.throws(()=>api.sbExecute({planId:plan.planId},routes),/different browser session/);assert.equal(api.sbAuditHistory().events.length,0);form.builderSession='a'.repeat(64);api.sbBindSession();assert.ok(api.sbAuditHistory().events.length>0);
plan=api.sbPrepare({action:'createDE',payload});tables[names.payloads].find(row=>row.PlanId===plan.planId).PayloadText+='x';assert.throws(()=>api.sbExecute({planId:plan.planId},routes),/modified/);
plan=api.sbPrepare({action:'createDE',payload});auditFails=true;count=operations.length;assert.throws(()=>api.sbExecute({planId:plan.planId},routes),/Audit logging/);assert.equal(operations.length,count);auditFails=false;
plan=api.sbPrepare({action:'createDE',payload});finalAuditFails=true;assert.throws(()=>api.sbExecute({planId:plan.planId},routes),/Do not retry/);assert.equal(operations.length,count+1);finalAuditFails=false;assert.throws(()=>api.sbExecute({planId:plan.planId},routes),/already used/);
plan=api.sbPrepare({action:'createDE',payload:{...payload,description:'x'.repeat(5000)}});assert.ok(Number(tables[names.plans].at(-1).ChunkCount)>1);api.sbExecute({planId:plan.planId},routes);assert.equal(operations.at(-1).description.length,5000);
assert.throws(()=>api.sbPrepare({action:'createDE',payload:{...payload,description:'x'.repeat(65000)}}),/approval limit/);
assert.ok(!html.includes('builder-login'));assert.ok(!html.includes('builderAccessKey'));assert.ok(!html.includes('DecryptSymmetric'));assert.ok(!html.includes('SFMC_Builder_Users'));assert.ok(!html.includes('sbAuthenticate'));
function dispatch(session,action,data={}){
 const post=new URLSearchParams();post.set('builderSession',session);
 function flatten(prefix,value){if(value==null){post.set(prefix+'.type','null');return;}const type=Array.isArray(value)?'array':typeof value;post.set(prefix+'.type',type);if(type==='array'||type==='object'){const keys=Object.keys(value);post.set(prefix+'.count',keys.length);keys.forEach((key,i)=>{if(type==='object')post.set(prefix+'.key'+i,key);flatten(prefix+'.item'+i,value[key]);});}else post.set(prefix+'.value',String(value));}
 flatten('request',{build:'SFMC-BUILDER-E5',action,data});let output='';
 const backend={...env,Platform:{...env.Platform,Request:{GetQueryStringParameter(){return '1'},GetFormField(name){return post.get(name)}}},Write(value){output+=value;}};
 vm.runInNewContext(scripts[0],backend);return JSON.parse(output);
}
assert.match(dispatch('a'.repeat(64),'createDE',payload).error,/Review and approve/);
assert.equal(dispatch('invalid','createDE',payload).ok,false);

// Check browser confirmations using the actual central approval gateway.
const elements={};function element(id){return elements[id]||(elements[id]={value:'',innerHTML:'',textContent:'',disabled:false,events:{},addEventListener(k,fn){this.events[k]=fn},removeEventListener(k){delete this.events[k]},showModal(){this.open=true},close(){this.open=false}});}
const storage=new Map(),browser=vm.createContext({URL,URLSearchParams,Uint8Array,document:{getElementById:element,querySelectorAll(){return [];}},window:{crypto:crypto.webcrypto,sessionStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)}},location:{href:'https://unit.test/page',protocol:'https:'}});
vm.runInContext(scripts[1].slice(0,scripts[1].indexOf('/* ---------- init ---------- */')),browser);
vm.runInContext("globalThis.calls=[];globalThis.originalRequest=builderRequest;builderRequest=async function(action,data){calls.push({action,data});return action==='builderPrepare'?{planId:'review-plan',action:data.action,payload:data.payload,mid:'100010552',actor:'Browser session'}:{key:'done'};};",browser);
(async()=>{
 const cancelled=vm.runInContext("api('createDE',{name:'Example'})",browser);await Promise.resolve();element('builder-review-cancel').onclick();await assert.rejects(()=>cancelled,/cancelled/);assert.equal(browser.calls.filter(c=>c.action==='builderExecute').length,0);
 const approved=vm.runInContext("api('createDE',{name:'Example'})",browser);await Promise.resolve();element('builder-review-confirm').onclick();await approved;assert.equal(browser.calls.at(-1).data.planId,'review-plan');assert.equal(browser.calls.at(-1).data.payload,undefined);
 const pending=vm.runInContext("api('createDE',{name:'Example'})",browser);await Promise.resolve();await assert.rejects(()=>vm.runInContext("api('createDE',{name:'Second'})",browser),/Finish the current/);element('builder-review-cancel').onclick();await assert.rejects(()=>pending,/cancelled/);
 browser.fetch=async(url,options)=>{const encoded=new URLSearchParams(options.body);assert.match(encoded.get('builderSession'),/^[a-f0-9]{64}$/);assert.equal(encoded.has('builderKey'),false);assert.ok(!url.includes(encoded.get('builderSession')));return {text:async()=>JSON.stringify({ok:true,build:'SFMC-BUILDER-E5',data:{mid:'100010552'}})};};
 await vm.runInContext("originalRequest('ping',{})",browser);
 console.log('PASS: no login or credential-provider replacement; syntax; MID guard; exact previews; session ownership; single-use/expiry; payload chunking/integrity; audit-before-write and audit failure behavior; cancellation; final confirmation; concurrent review blocking; POST-only session transport. All SFMC services mocked.');
})().catch(()=>{console.error('Client approval checks failed');process.exitCode=1;});
